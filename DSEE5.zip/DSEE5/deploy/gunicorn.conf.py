"""Gunicorn settings for production.  From backend/:

    gunicorn -c ../deploy/gunicorn.conf.py wsgi:app

Why ONE worker:
  * Socket.IO keeps the chat rooms and online counts in memory, so every browser must
    talk to the same process.
  * The background jobs (backups, DSE reminders, clean-up) start inside the worker and
    must run exactly once.
  * Rate limits are shared through Redis, so they are correct either way.

The worker uses threads: each open chat connection holds one thread, so THREADS is the
number of people who can be connected at the same time. To grow beyond a few hundred
users at once, move Socket.IO to a message queue (Redis) with several workers and
sticky sessions in nginx - see the Flask-SocketIO "Deployment" documentation.
"""
import os

bind = os.getenv("GUNICORN_BIND", "0.0.0.0:8000")    # nginx connects here (Docker network)
workers = 1                                          # do not change - see above
worker_class = "gthread"
threads = int(os.getenv("GUNICORN_THREADS", "200"))
timeout = 60                 # a stuck request is restarted after 60 s
graceful_timeout = 30        # time to finish requests on restart
keepalive = 5                # matches nginx keepalive to the app

# The app is loaded in the worker (not the master), so the scheduler starts once there.
preload_app = False

# Refuse oversized request lines and headers early.
limit_request_line = 8190
limit_request_fields = 100
limit_request_field_size = 8190

# Logs go to stdout/stderr; Docker or systemd collects them.
accesslog = "-"
errorlog = "-"
loglevel = os.getenv("GUNICORN_LOG_LEVEL", "info")
# No query strings in the access log: they can contain search words.
access_log_format = '%(h)s "%(m)s %(U)s %(H)s" %(s)s %(B)s %(L)ss "%(a)s"'

# The real visitor IP comes from nginx's X-Forwarded-For header and is read by
# werkzeug's ProxyFix inside the app (BEHIND_PROXY = True), not by Gunicorn.
proc_name = "dsee5"
