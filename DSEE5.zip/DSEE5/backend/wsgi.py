"""Production entry point. From backend/:  gunicorn -c ../deploy/gunicorn.conf.py wsgi:app

Database commands do not use this file: they use `flask --app app ...`, which calls
create_app() without starting the background jobs.
"""
from app import create_app
from app.tasks.scheduler import start_scheduler

app = create_app("production")
start_scheduler(app)   # safe: Gunicorn runs exactly one worker (see deploy/gunicorn.conf.py)
