"""Real-time chat. Each subject code (e.g. "MATH") is one Socket.IO room in the /chat
namespace.

Events (browser -> server): join {subject}, leave, send_message {subject, text, image_id,
captcha_token}. Events (server -> room): message_new, message_deleted, message_hidden,
message_restored, message_pinned, online_count.

The online list lives in memory, which is right for one server process. To run several
processes, move it to Redis and add a Socket.IO message queue.
"""
import threading
from collections import Counter

from flask import current_app, request
from flask_socketio import ConnectionRefusedError, emit, join_room, leave_room

from .. import constants as C
from ..extensions import db
from ..models.user import User
from ..security import ip_tracker
from ..security.sessions import load_user_from_token
from ..services import chat_service

NAMESPACE = "/chat"
_lock = threading.Lock()
_online: dict[str, int] = {}          # socket id -> user id
_room_of: dict[str, str] = {}         # socket id -> subject code


def online_counts() -> dict[str, int]:
    """Number of different people currently in each room."""
    with _lock:
        pairs = {(room, _online.get(sid)) for sid, room in _room_of.items()}
    return dict(Counter(room for room, uid in pairs if uid is not None))


def _current_user() -> User | None:
    with _lock:
        user_id = _online.get(request.sid)
    user = db.session.get(User, user_id) if user_id else None
    if user is None or user.is_blocked or user.is_deleted:
        return None
    return user


def _broadcast_count(socketio, room: str) -> None:
    socketio.emit("online_count", {"subject": room, "count": online_counts().get(room, 0)},
                  to=room, namespace=NAMESPACE)


def register(socketio):
    @socketio.on("connect", namespace=NAMESPACE)
    def on_connect(_auth=None):
        if ip_tracker.is_ip_blocked(request.remote_addr or ""):
            raise ConnectionRefusedError("ip_blocked")
        token = request.cookies.get(current_app.config["AUTH_COOKIE_NAME"])
        user = load_user_from_token(token)
        if user is None:
            raise ConnectionRefusedError("login_required")
        with _lock:
            _online[request.sid] = user.id

    @socketio.on("disconnect", namespace=NAMESPACE)
    def on_disconnect(*_args):
        with _lock:
            _online.pop(request.sid, None)
            room = _room_of.pop(request.sid, None)
        if room:
            _broadcast_count(socketio, room)

    @socketio.on("join", namespace=NAMESPACE)
    def on_join(data):
        subject = str((data or {}).get("subject", "")).upper()
        if subject not in C.SUBJECT_CODES:
            return {"ok": False, "error": "unknown_subject"}
        if _current_user() is None:
            return {"ok": False, "error": "login_required"}
        with _lock:
            previous = _room_of.get(request.sid)
            _room_of[request.sid] = subject
        if previous and previous != subject:
            leave_room(previous)
            _broadcast_count(socketio, previous)
        join_room(subject)
        _broadcast_count(socketio, subject)
        return {"ok": True, "online": online_counts().get(subject, 0)}

    @socketio.on("leave", namespace=NAMESPACE)
    def on_leave(_data=None):
        with _lock:
            room = _room_of.pop(request.sid, None)
        if room:
            leave_room(room)
            _broadcast_count(socketio, room)
        return {"ok": True}

    @socketio.on("send_message", namespace=NAMESPACE)
    def on_send(data):
        user = _current_user()
        if user is None:
            return {"ok": False, "error": "login_required"}
        data = data if isinstance(data, dict) else {}
        subject = str(data.get("subject", "")).upper()
        with _lock:
            in_room = _room_of.get(request.sid) == subject
        if not in_room:
            return {"ok": False, "error": "join_room_first"}
        try:
            msg = chat_service.send_message(
                user, subject, str(data.get("text", ""))[:C.MAX_MESSAGE_LENGTH + 1],
                data.get("image_id"), data.get("captcha_token"))
        except chat_service.ChatError as e:
            return {"ok": False, "error": e.code}
        payload = msg.to_dict()
        if user.is_shadow_banned:
            emit("message_new", payload)                       # only the sender sees it
        else:
            emit("message_new", payload, to=msg.subject_code)
        return {"ok": True, "score": user.score, "message": payload}
