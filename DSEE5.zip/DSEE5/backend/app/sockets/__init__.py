"""Socket.IO event handlers (real-time chat)."""
from . import chat_events

_registered = False


def register_socket_events(socketio) -> None:
    global _registered
    if not _registered:              # handlers live on the shared socketio object
        chat_events.register(socketio)
        _registered = True
