"""The HTTP side of chat: room list, history, pinned messages, search and image upload.
Sending messages happens live over Socket.IO in sockets/chat_events.py."""
from flask import Blueprint, abort, g, request

from .. import constants as C
from ..extensions import db, limiter
from ..models.chat import ChatImage
from ..security import ip_tracker, rate_limits
from ..security.decorators import login_required
from ..services import chat_service, upload_service
from ..services.upload_service import UploadError
from ..sockets.chat_events import online_counts
from ..utils.responses import error, ok
from ..utils.time_utils import iso_utc

bp = Blueprint("chat", __name__, url_prefix="/api/chat")


def _subject(code: str) -> str:
    code = (code or "").upper()
    if code not in C.SUBJECT_CODES:
        abort(404)
    return code


@bp.get("/rooms")
@login_required
def rooms():
    last = chat_service.last_message_times()
    online = online_counts()
    return ok({"rooms": [
        {"code": s["code"], "name_en": s["name_en"], "name_zh": s["name_zh"],
         "category": s["category"], "online": online.get(s["code"], 0),
         "last_message_at": iso_utc(last.get(s["code"]))}
        for s in C.SUBJECTS],
        "costs": {"text": C.MESSAGE_COST_TEXT, "image": C.MESSAGE_COST_IMAGE},
        "captcha_needed": chat_service.needs_captcha(g.user)})


@bp.get("/<code>/messages")
@login_required
def messages(code: str):
    subject = _subject(code)
    before = request.args.get("before", "")
    rows, has_more = chat_service.history(subject, g.user,
                                          int(before) if before.isdigit() else None)
    return ok({"messages": [m.to_dict(g.user.id) for m in rows], "has_more": has_more})


@bp.get("/<code>/pinned")
@login_required
def pinned(code: str):
    rows = chat_service.pinned(_subject(code))
    return ok({"messages": [m.to_dict(g.user.id) for m in rows]})


@bp.get("/<code>/search")
@login_required
@limiter.limit(rate_limits.SEARCH, key_func=rate_limits.user_key)
def search(code: str):
    subject = _subject(code)
    q = (request.args.get("q") or "").strip()
    if len(q) < 2:
        return error("search_too_short", 400)
    rows = chat_service.search(subject, g.user, q)
    return ok({"messages": [m.to_dict(g.user.id) for m in rows]})


@bp.post("/images")
@login_required
@limiter.limit(rate_limits.CHAT_IMAGE, key_func=rate_limits.user_key)
def upload_image():
    if g.user.is_muted:
        return error("muted", 403)
    try:
        saved = upload_service.save_image(request.files.get("image"), "chat_images", 1600)
    except UploadError as e:
        return error(e.code, 400)
    image = ChatImage(owner_id=g.user.id, file_name=saved.name, width=saved.width,
                      height=saved.height)
    db.session.add(image)
    db.session.commit()
    ip_tracker.log_activity("upload.image", user_id=g.user.id, meta={"image_id": image.id})
    return ok({"image_id": image.id, "url": f"/api/chat/images/{image.file_name}"}, 201)


@bp.get("/images/<name>")
@login_required
def image_file(name: str):
    if not upload_service.valid_name(name):
        abort(404)
    image = db.session.execute(
        db.select(ChatImage).where(ChatImage.file_name == name)).scalar_one_or_none()
    if image is None:
        abort(404)
    is_owner = image.owner_id == g.user.id
    msg = image.message
    if not is_owner and (msg is None or not msg.visible or
                         (msg.user.is_shadow_banned and msg.user_id != g.user.id)):
        abort(404)
    return upload_service.send_stored("chat_images", name, max_age=3600)
