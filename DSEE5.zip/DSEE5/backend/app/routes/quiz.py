"""Starting, saving and submitting quizzes, tests and mock exams: /api/quizzes, /api/attempts"""
from flask import Blueprint, abort, g, request

from .. import constants as C
from ..extensions import db
from ..models.quiz import Assessment, Question
from ..security.decorators import login_required
from ..services import quiz_service, upload_service
from ..services.quiz_service import QuizError
from ..utils.responses import error, json_body, ok
from ..utils.time_utils import iso_utc, utcnow

bp = Blueprint("quiz", __name__, url_prefix="/api")


def _quiz_error(e: QuizError):
    return error(e.code, e.status, **e.extra)


@bp.get("/quizzes")
@login_required
def list_assessments():
    stmt = db.select(Assessment).where(Assessment.is_published.is_(True))
    subject = (request.args.get("subject") or "").upper()
    if subject in C.SUBJECT_CODES:
        stmt = stmt.where(Assessment.subject_code == subject)
    if request.args.get("level") in C.QUIZ_LEVELS:
        stmt = stmt.where(Assessment.level == request.args["level"])
    if request.args.get("kind") in C.ASSESSMENT_KINDS:
        stmt = stmt.where(Assessment.kind == request.args["kind"])
    rows = db.session.execute(
        stmt.order_by(Assessment.subject_code, Assessment.kind, Assessment.level,
                      Assessment.title)).scalars().all()
    best = quiz_service.best_scores(g.user.id)
    items = []
    for a in rows:
        stats = best.get(a.id, {"best_percent": None, "attempts": 0})
        items.append({**a.to_dict(), **stats})
    current = quiz_service.current_attempt(g.user.id)
    return ok({"items": items, "current_attempt": current.summary_dict() if current else None})


@bp.post("/quizzes/<int:assessment_id>/start")
@login_required
def start(assessment_id: int):
    try:
        attempt = quiz_service.start_attempt(g.user, db.session.get(Assessment, assessment_id))
    except QuizError as e:
        return _quiz_error(e)
    return ok({"attempt": quiz_service.attempt_payload(attempt)}, 201)


@bp.get("/attempts/current")
@login_required
def current():
    quiz_service.expire_overdue(user_id=g.user.id)
    attempt = quiz_service.current_attempt(g.user.id)
    return ok({"attempt": attempt.summary_dict() if attempt else None})


@bp.get("/attempts/history")
@login_required
def history():
    return ok({"items": quiz_service.history(g.user.id)})


@bp.get("/attempts/<int:attempt_id>")
@login_required
def get_attempt(attempt_id: int):
    try:
        attempt = quiz_service.get_owned_attempt(g.user.id, attempt_id)
    except QuizError as e:
        return _quiz_error(e)
    quiz_service.expire_overdue(user_id=g.user.id)
    if attempt.status != "in_progress":
        return ok({"attempt": attempt.summary_dict()})
    return ok({"attempt": quiz_service.attempt_payload(attempt)})


@bp.patch("/attempts/<int:attempt_id>/answers")
@login_required
def save_answers(attempt_id: int):
    try:
        attempt = quiz_service.get_owned_attempt(g.user.id, attempt_id)
        saved = quiz_service.save_answers(attempt, json_body().get("answers") or {})
    except QuizError as e:
        return _quiz_error(e)
    return ok({"saved": saved, "server_now": iso_utc(utcnow())})


@bp.post("/attempts/<int:attempt_id>/submit")
@login_required
def submit(attempt_id: int):
    try:
        attempt = quiz_service.get_owned_attempt(g.user.id, attempt_id)
        attempt = quiz_service.submit(attempt, json_body().get("answers") or None)
    except QuizError as e:
        return _quiz_error(e)
    db.session.refresh(g.user)
    return ok({"attempt": attempt.summary_dict(), "score": g.user.score})


@bp.get("/attempts/<int:attempt_id>/result")
@login_required
def result(attempt_id: int):
    try:
        attempt = quiz_service.get_owned_attempt(g.user.id, attempt_id)
        return ok({"result": quiz_service.result_payload(attempt)})
    except QuizError as e:
        return _quiz_error(e)


@bp.get("/files/question/<name>")
@login_required
def question_image(name: str):
    if not upload_service.valid_name(name):
        abort(404)
    exists = db.session.execute(
        db.select(Question.id).where(Question.image_file == name)).first()
    if not exists:
        abort(404)
    return upload_service.send_stored("questions", name, max_age=86400)
