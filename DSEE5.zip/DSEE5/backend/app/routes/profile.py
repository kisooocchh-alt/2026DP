"""Subjects, public profiles, editing your own profile, avatars, tutor certificates,
privacy settings, and your data (export / delete): /api/..."""
import json

from flask import Blueprint, Response, g, request

from .. import constants as C
from ..extensions import db, limiter
from ..models.subject import Subject
from ..models.user import User
from ..security import ip_tracker, rate_limits
from ..security import validators as V
from ..security.decorators import login_required, role_required
from ..security.sessions import end_session
from ..services import auth_service, moderation_service, privacy_service, upload_service
from ..services.upload_service import UploadError
from ..utils.responses import error, json_body, ok
from ..utils.time_utils import utcnow

bp = Blueprint("profile", __name__, url_prefix="/api")


@bp.get("/subjects")
def subjects():
    rows = db.session.execute(
        db.select(Subject).where(Subject.is_active.is_(True)).order_by(Subject.sort_order)
    ).scalars().all()
    data = [s.to_dict() for s in rows] or [
        {"code": s["code"], "name_en": s["name_en"], "name_zh": s["name_zh"],
         "category": s["category"]} for s in C.SUBJECTS]
    response = ok({"subjects": data})
    response.headers["Cache-Control"] = "public, max-age=3600"
    return response


@bp.get("/users/<username>")
def public_profile(username: str):
    user = auth_service.find_user(username)
    if user is None or user.is_deleted or user.is_blocked:
        return error("not_found", 404)
    return ok({"profile": privacy_service.public_profile(user, g.user)})


@bp.get("/profile")
@login_required
def my_profile():
    return ok({"user": g.user.to_private_dict()})


def _no_bad_words(form: V.Form, *fields: str) -> None:
    for name in fields:
        value = form.data.get(name)
        if isinstance(value, str) and moderation_service.contains_banned_words(value):
            form.errors[name] = "blocked_words"


@bp.put("/profile")
@login_required
def update_profile():
    user: User = g.user
    data = json_body()
    form = V.Form(data)
    updates: dict = {}
    if form.has("display_name"):
        updates["display_name"] = form.field("display_name", V.text, max_len=C.DISPLAY_NAME_MAX,
                                             required=True, code="display_name_required")
    if form.has("gender"):
        updates["gender"] = form.field("gender", V.choice, C.GENDERS, code="gender_invalid",
                                       required=False)
    if form.has("bio"):
        updates["bio"] = form.field("bio", V.text, max_len=C.BIO_MAX, multiline=True)
    if form.has("contact"):
        updates["contact"] = form.field("contact", V.text, max_len=C.CONTACT_MAX)
    subjects = None
    if form.has("subjects"):
        subjects = form.field("subjects", V.subject_list,
                              min_count=1 if user.role == "tutor" else 0)
    _no_bad_words(form, "display_name", "bio", "contact")

    student = tutor = None
    if user.role == "student" and isinstance(data.get("student"), dict):
        sf = V.Form(data["student"])
        student = {
            "dse_goal": sf.field("dse_goal", V.text, max_len=C.DSE_GOAL_MAX, required=True,
                                 code="dse_goal_required"),
            "school": sf.field("school", V.text, max_len=C.SCHOOL_MAX, required=True,
                               code="school_required"),
            "exam_year": sf.field("exam_year", V.integer, min_value=2000, max_value=2100,
                                  code="exam_year_invalid", required=False),
        }
        _no_bad_words(sf, "dse_goal", "school")
        form.errors.update(sf.errors)
    if user.role == "tutor" and isinstance(data.get("tutor"), dict):
        tf = V.Form(data["tutor"])
        tutor = {
            "hourly_wage": tf.field("hourly_wage", V.wage),
            "short_description": tf.field("short_description", V.text,
                                          max_len=C.SHORT_DESCRIPTION_MAX),
            "dse_results": tf.field("dse_results", V.dse_results, required=True),
        }
        _no_bad_words(tf, "short_description")
        form.errors.update(tf.errors)
    if form.errors:
        return error("validation_failed", 400, fields=form.errors)

    for key, value in updates.items():
        setattr(user, key, value)
    if subjects is not None:
        user.subjects = list(db.session.execute(
            db.select(Subject).where(Subject.code.in_(subjects))).scalars())
    if student and user.student_profile:
        for key, value in student.items():
            setattr(user.student_profile, key, value)
    if tutor and user.tutor_profile:
        tp = user.tutor_profile
        if tutor["dse_results"] != (tp.dse_results or []) and tp.is_verified:
            tp.is_verified = False                    # results changed: needs a new check
            tp.verified_at = None
        for key, value in tutor.items():
            setattr(tp, key, value)
    db.session.commit()
    return ok({"user": user.to_private_dict()})


@bp.put("/profile/language")
@login_required
def set_language():
    lang = json_body().get("language")
    if lang not in C.LANGUAGES:
        return error("choice_invalid", 400)
    g.user.language = lang
    db.session.commit()
    return ok()


@bp.post("/profile/avatar")
@login_required
@limiter.limit(rate_limits.AVATAR_UPLOAD, key_func=rate_limits.user_key)
def upload_avatar():
    try:
        saved = upload_service.save_image(request.files.get("avatar"), "avatars", max_side=512)
    except UploadError as e:
        return error(e.code, 400)
    upload_service.delete_file("avatars", g.user.avatar_file)
    g.user.avatar_file = saved.name
    db.session.commit()
    ip_tracker.log_activity("upload.avatar", user_id=g.user.id)
    return ok({"avatar_url": g.user.avatar_url})


@bp.delete("/profile/avatar")
@login_required
def remove_avatar():
    upload_service.delete_file("avatars", g.user.avatar_file)
    g.user.avatar_file = None
    db.session.commit()
    return ok({"avatar_url": g.user.avatar_url})


@bp.post("/profile/certificate")
@role_required("tutor")
@limiter.limit(rate_limits.AVATAR_UPLOAD, key_func=rate_limits.user_key)
def upload_certificate():
    try:
        saved = upload_service.save_image_or_pdf(request.files.get("certificate"),
                                                 "certificates", max_pdf_mb=10)
    except UploadError as e:
        return error(e.code, 400)
    tp = g.user.tutor_profile
    upload_service.delete_file("certificates", tp.certificate_file)
    tp.certificate_file = saved.name
    tp.certificate_uploaded_at = utcnow()
    tp.is_verified = False                    # a new certificate needs a new check
    tp.verified_at = None
    db.session.commit()
    ip_tracker.log_activity("upload.certificate", user_id=g.user.id)
    return ok({"certificate_status": tp.certificate_status})


@bp.put("/profile/privacy")
@login_required
def update_privacy():
    user: User = g.user
    form = V.Form(json_body())
    values = {
        "age": form.field("show_age", V.visibility),
        "school": form.field("show_school", V.visibility),
        "contact": form.field("show_contact", V.visibility),
    }
    guardian = form.field("guardian_email", V.email) if form.has("guardian_email") else None
    if form.errors:
        return error("validation_failed", 400, fields=form.errors)
    user.show_age = privacy_service.allowed_visibility(user, "age", values["age"])
    user.show_school = values["school"]
    user.show_contact = privacy_service.allowed_visibility(user, "contact", values["contact"])
    if form.has("guardian_email"):
        user.guardian_email = guardian
    db.session.commit()
    return ok({"user": user.to_private_dict()})


@bp.get("/profile/export")
@login_required
def export_data():
    data = auth_service.export_user_data(g.user)
    ip_tracker.log_activity("privacy.export", user_id=g.user.id)
    body = json.dumps(data, ensure_ascii=False, indent=2)
    return Response(body, mimetype="application/json", headers={
        "Content-Disposition": f'attachment; filename="dsee5-{g.user.username}-data.json"',
        "Cache-Control": "no-store"})


@bp.post("/profile/delete")
@login_required
def delete_account():
    try:
        auth_service.delete_account(g.user, str(json_body().get("password", "")))
    except auth_service.AuthError as e:
        return error(e.code, e.status)
    return end_session(ok())


@bp.get("/files/avatar/<name>")
def avatar_file(name: str):
    return upload_service.send_stored("avatars", name, max_age=86400, private=False)
