"""Learning materials and textbooks for users: /api/materials...
The admin adds, edits and removes them in routes/admin.py."""
from flask import Blueprint, g, request

from .. import constants as C
from ..extensions import db
from ..models.material import Material
from ..security import validators as V
from ..security.decorators import login_required
from ..security.headers import FRAMEABLE_CSP, talisman
from ..services import upload_service
from ..utils.pagination import paginate
from ..utils.responses import error, ok
from .papers import bookmark_map

bp = Blueprint("materials", __name__, url_prefix="/api/materials")


def _published(material_id: int) -> Material | None:
    m = db.session.get(Material, material_id)
    return m if m is not None and m.is_published else None


@bp.get("")
@login_required
def list_materials():
    stmt = db.select(Material).where(Material.is_published.is_(True))
    subject = (request.args.get("subject") or "").upper()
    if subject in C.SUBJECT_CODES:
        stmt = stmt.where(Material.subject_code == subject)
    topic = V.clean_text(request.args.get("topic"), 80)
    if topic:
        stmt = stmt.where(Material.topic == topic)
    if request.args.get("kind") in C.MATERIAL_KINDS:
        stmt = stmt.where(Material.kind == request.args["kind"])
    q = V.clean_text(request.args.get("q"), 80)
    if q:
        stmt = stmt.where(Material.title.contains(q, autoescape=True)
                          | Material.description.contains(q, autoescape=True))
    topics_stmt = db.select(Material.topic).where(Material.is_published.is_(True)).distinct() \
        .order_by(Material.topic)
    if subject in C.SUBJECT_CODES:
        topics_stmt = topics_stmt.where(Material.subject_code == subject)
    marks = bookmark_map(g.user, "material")
    data = paginate(stmt.order_by(Material.subject_code, Material.topic, Material.title),
                    lambda m: {**m.to_dict(), "bookmark_id": marks.get(m.id)}, per_page=24)
    data["topics"] = list(db.session.execute(topics_stmt).scalars())
    return ok(data)


@bp.get("/<int:material_id>")
@login_required
def detail(material_id: int):
    m = _published(material_id)
    if m is None:
        return error("not_found", 404)
    marks = bookmark_map(g.user, "material")
    return ok({"material": {**m.to_dict(full=True), "bookmark_id": marks.get(m.id)}})


@bp.get("/<int:material_id>/file")
@login_required
@talisman(frame_options="SAMEORIGIN", content_security_policy=FRAMEABLE_CSP)
def material_file(material_id: int):
    m = _published(material_id)
    if m is None or not m.has_file:
        return error("not_found", 404)
    download = request.args.get("download") == "1"
    if download and not m.allow_download:
        return error("download_not_allowed", 403)
    extension = ".pdf" if m.kind == "pdf" else ".webp"
    safe_title = "".join(ch for ch in m.title if ch.isalnum() or ch in " -_")[:60].strip() \
        or f"material-{m.id}"
    return upload_service.send_stored("materials", m.file_name, as_attachment=download,
                                      download_name=f"{safe_title}{extension}", max_age=3600)
