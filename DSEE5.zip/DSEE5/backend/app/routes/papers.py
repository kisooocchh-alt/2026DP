"""Browsing and downloading past papers: /api/papers...
Upload and delete are admin-only (routes/admin.py)."""
from flask import Blueprint, g, request

from .. import constants as C
from ..extensions import db, limiter
from ..models.bookmark import Bookmark
from ..models.past_paper import PastPaper
from ..security import ip_tracker, rate_limits
from ..security.decorators import login_required
from ..services import upload_service
from ..utils.responses import error, ok

bp = Blueprint("papers", __name__, url_prefix="/api/papers")


def bookmark_map(user, item_type: str) -> dict[int, int]:
    if user is None:
        return {}
    rows = db.session.execute(
        db.select(Bookmark.item_id, Bookmark.id)
        .where(Bookmark.user_id == user.id, Bookmark.item_type == item_type)).all()
    return dict(rows)


@bp.get("")
def list_papers():
    stmt = db.select(PastPaper)
    subject = (request.args.get("subject") or "").upper()
    if subject in C.SUBJECT_CODES:
        stmt = stmt.where(PastPaper.subject_code == subject)
    if (request.args.get("year") or "").isdigit():
        stmt = stmt.where(PastPaper.year == int(request.args["year"]))
    if request.args.get("language") in C.CONTENT_LANGUAGES:
        stmt = stmt.where(PastPaper.language == request.args["language"])
    papers = db.session.execute(
        stmt.order_by(PastPaper.year.desc(), PastPaper.subject_code, PastPaper.paper,
                      PastPaper.language).limit(500)).scalars().all()
    years_stmt = db.select(PastPaper.year).distinct().order_by(PastPaper.year.desc())
    if subject in C.SUBJECT_CODES:
        years_stmt = years_stmt.where(PastPaper.subject_code == subject)
    marks = bookmark_map(g.user, "paper")
    return ok({"papers": [{**p.to_dict(), "bookmark_id": marks.get(p.id)} for p in papers],
               "years": list(db.session.execute(years_stmt).scalars())})


@bp.get("/<int:paper_id>/download")
@login_required
@limiter.limit(rate_limits.PAPER_DOWNLOAD, key_func=rate_limits.user_key)
def download(paper_id: int):
    paper = db.session.get(PastPaper, paper_id)
    if paper is None:
        return error("not_found", 404)
    which = request.args.get("file", "paper")
    if which == "marking":
        if not paper.marking_file:
            return error("not_found", 404)
        name, download_name = paper.marking_file, paper.download_name.replace(".pdf", "-MS.pdf")
    else:
        name, download_name = paper.file_name, paper.download_name
    paper.download_count += 1
    db.session.commit()
    ip_tracker.log_activity("paper.download", user_id=g.user.id,
                            meta={"paper_id": paper.id, "file": which}, commit=True)
    return upload_service.send_stored("papers", name, download_name=download_name,
                                      as_attachment=True)
