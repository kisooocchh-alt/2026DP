"""Hidden admin panel: pages (Jinja templates) and admin API.

Registered under the secret ADMIN_URL_PREFIX from .env. A before_request check returns
a normal 404 to anyone who is not a logged-in admin, so the panel looks like it does
not exist. Every admin action is written to the activity log.
"""
import csv
import io
import ipaddress
from datetime import datetime

from flask import Blueprint, abort, g, render_template, request, url_for

from .. import constants as C
from ..extensions import db, socketio
from ..models.chat import Message
from ..models.dse_event import DseEvent
from ..models.material import Material
from ..models.past_paper import PastPaper
from ..models.quiz import Assessment, Attempt, AttemptQuestion, Question, QuestionBank
from ..models.report import Report
from ..models.score import ScoreTransaction
from ..models.security_log import ActivityLog, BlockedIP
from ..models.user import TutorProfile, User
from ..security import abuse_detector, ip_tracker
from ..security import validators as V
from ..security.decorators import admin_required
from ..security.sessions import list_user_sessions, revoke_all_user_sessions
from ..services import (analytics_service, chat_service, moderation_service,
                        notification_service, score_service, upload_service)
from ..services.upload_service import UploadError
from ..utils.responses import error, json_body, ok
from ..utils.time_utils import HK, hk_today, iso_hk, to_hk, utcnow

bp = Blueprint("admin", __name__,
               template_folder="../admin_ui/templates",
               static_folder="../admin_ui/static", static_url_path="/assets")

PAGE_SIZE = 50


# ====================================================================== plumbing
@bp.before_request
@admin_required                  # protects every route in this blueprint, including /assets
def protect():
    return None


@bp.after_request
def no_store(response):
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Robots-Tag"] = "noindex, nofollow"
    return response


@bp.app_template_filter("hk")
def hk_filter(value, fmt: str = "%Y-%m-%d %H:%M") -> str:
    return to_hk(value).strftime(fmt) if value else "-"


@bp.app_template_filter("hk_iso")
def hk_iso_filter(value: str | None) -> str:
    """'2026-10-15T02:30:00+00:00' (UTC, from to_dict) -> '2026-10-15 10:30' (Hong Kong)."""
    if not value:
        return "-"
    return datetime.fromisoformat(value).astimezone(HK).strftime("%Y-%m-%d %H:%M")


@bp.app_template_filter("hk_input")
def hk_input_filter(value) -> str:
    return to_hk(value).strftime("%Y-%m-%dT%H:%M") if value else ""


@bp.app_template_filter("filesize")
def filesize_filter(value) -> str:
    if not value:
        return "-"
    size = float(value)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024:
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"


@bp.context_processor
def inject_globals():
    open_reports = db.session.execute(
        db.select(db.func.count(Report.id)).where(Report.status == "open")).scalar_one()
    return {"subjects": C.SUBJECTS, "subject_by_code": C.SUBJECT_BY_CODE, "C": C,
            "admin": g.get("admin"), "open_reports_count": open_reports,
            "now_hk": to_hk(utcnow()), "now_utc": utcnow()}


def audit(event: str, **meta) -> None:
    ip_tracker.log_activity(f"admin.{event}", admin_id=g.admin.id, meta=meta or None)


def form_or_json() -> dict:
    return request.form.to_dict() if request.form else json_body()


def validation_error(errors: dict):
    return error("validation_failed", 400, fields=errors)


def get_or_404(model, object_id):
    obj = db.session.get(model, object_id)
    if obj is None:
        abort(404)
    return obj


# ====================================================================== pages
@bp.get("/")
def dashboard():
    return render_template("admin_dashboard.html", stats=analytics_service.summary(),
                           active="dashboard")


@bp.get("/users")
def users():
    stmt = db.select(User).where(User.is_deleted.is_(False))
    q = V.clean_text(request.args.get("q"), 40)
    if q:
        stmt = stmt.where(User.username.contains(q, autoescape=True)
                          | User.display_name.contains(q, autoescape=True))
    role = request.args.get("role")
    if role in C.ROLES:
        stmt = stmt.where(User.role == role)
    flag = request.args.get("flag")
    if flag == "blocked":
        stmt = stmt.where(User.is_blocked.is_(True))
    elif flag == "shadow":
        stmt = stmt.where(User.is_shadow_banned.is_(True))
    elif flag == "muted":
        stmt = stmt.where(User.muted_until > utcnow())
    elif flag == "unverified":
        stmt = stmt.join(TutorProfile, TutorProfile.user_id == User.id).where(
            TutorProfile.certificate_file.is_not(None), TutorProfile.is_verified.is_(False))
    elif flag == "minor":
        stmt = stmt.where(User.birth_year > hk_today().year - C.MINOR_AGE)
    page = db.paginate(stmt.order_by(User.id.desc()), per_page=PAGE_SIZE, error_out=False)
    return render_template("admin_users.html", page=page, active="users", q=q, role=role,
                           flag=flag, detail=None)


@bp.get("/users/<int:user_id>")
def user_detail(user_id: int):
    user = get_or_404(User, user_id)
    activity = db.session.execute(
        db.select(ActivityLog).where(ActivityLog.user_id == user.id)
        .order_by(ActivityLog.id.desc()).limit(40)).scalars().all()
    reports = db.session.execute(
        db.select(Report).where(
            ((Report.target_type == "user") & (Report.target_id == user.id))
            | ((Report.target_type == "message") & Report.target_id.in_(
                db.select(Message.id).where(Message.user_id == user.id))))
        .order_by(Report.id.desc()).limit(30)).scalars().all()
    transactions = db.session.execute(
        db.select(ScoreTransaction).where(ScoreTransaction.user_id == user.id)
        .order_by(ScoreTransaction.id.desc()).limit(20)).scalars().all()
    messages = db.session.execute(
        db.select(Message).where(Message.user_id == user.id)
        .order_by(Message.id.desc()).limit(20)).scalars().all()
    return render_template(
        "admin_users.html", active="users", detail=user, activity=activity, reports=reports,
        transactions=transactions, messages=messages, sessions=list_user_sessions(user.id),
        related=analytics_service.related_accounts(user), page=None, q="", role=None,
        flag=None)


@bp.get("/users/<int:user_id>/certificate")
def user_certificate(user_id: int):
    user = get_or_404(User, user_id)
    if not user.tutor_profile or not user.tutor_profile.certificate_file:
        abort(404)
    audit("view_certificate", user_id=user.id)
    return upload_service.send_stored("certificates", user.tutor_profile.certificate_file)


@bp.get("/papers")
def papers():
    stmt = db.select(PastPaper)
    subject = (request.args.get("subject") or "").upper()
    if subject in C.SUBJECT_CODES:
        stmt = stmt.where(PastPaper.subject_code == subject)
    rows = db.session.execute(stmt.order_by(PastPaper.year.desc(), PastPaper.subject_code,
                                            PastPaper.paper)).scalars().all()
    return render_template("admin_papers.html", papers=rows, active="papers",
                           subject=subject, this_year=hk_today().year)


@bp.get("/materials")
def materials():
    stmt = db.select(Material)
    subject = (request.args.get("subject") or "").upper()
    if subject in C.SUBJECT_CODES:
        stmt = stmt.where(Material.subject_code == subject)
    status = request.args.get("status")
    if status == "published":
        stmt = stmt.where(Material.is_published.is_(True))
    elif status == "draft":
        stmt = stmt.where(Material.is_published.is_(False))
    rows = db.session.execute(stmt.order_by(Material.updated_at.desc())).scalars().all()
    edit = db.session.get(Material, int(request.args["edit"])) \
        if (request.args.get("edit") or "").isdigit() else None
    return render_template("admin_materials.html", materials=rows, edit=edit,
                           active="materials", subject=subject, status=status)


@bp.get("/quiz-bank")
def quiz_bank():
    banks = db.session.execute(
        db.select(QuestionBank).order_by(QuestionBank.subject_code, QuestionBank.level)
    ).scalars().all()
    counts = dict(db.session.execute(
        db.select(Question.bank_id, db.func.count(Question.id))
        .where(Question.is_active.is_(True)).group_by(Question.bank_id)).all())
    assessments = db.session.execute(
        db.select(Assessment).order_by(Assessment.subject_code, Assessment.kind)
    ).scalars().all()
    attempts = dict(db.session.execute(
        db.select(Attempt.assessment_id, db.func.count(Attempt.id))
        .group_by(Attempt.assessment_id)).all())
    return render_template("admin_quiz_bank.html", banks=banks, counts=counts,
                           assessments=assessments, attempts=attempts, bank=None,
                           active="quiz", rules=C.ASSESSMENT_RULES)


@bp.get("/quiz-bank/<int:bank_id>")
def quiz_bank_detail(bank_id: int):
    bank = get_or_404(QuestionBank, bank_id)
    questions = db.session.execute(
        db.select(Question).where(Question.bank_id == bank.id)
        .order_by(Question.is_active.desc(), Question.topic, Question.id)).scalars().all()
    edit = db.session.get(Question, int(request.args["edit"])) \
        if (request.args.get("edit") or "").isdigit() else None
    if edit is not None and edit.bank_id != bank.id:
        edit = None
    return render_template("admin_quiz_bank.html", bank=bank, questions=questions, edit=edit,
                           active="quiz", banks=None, rules=C.ASSESSMENT_RULES)


@bp.get("/chat")
def chat():
    subject = (request.args.get("subject") or "MATH").upper()
    if subject not in C.SUBJECT_CODES:
        subject = "MATH"
    return render_template("admin_chat.html", subject=subject, active="chat")


@bp.get("/reports")
def reports():
    status = request.args.get("status", "open")
    if status not in ("open", "actioned", "dismissed"):
        status = "open"
    rows = db.session.execute(
        db.select(Report).where(Report.status == status).order_by(Report.id.desc()).limit(300)
    ).scalars().all()
    groups: dict = {}
    for r in rows:
        key = (r.target_type, r.target_id)
        if key not in groups:
            target = db.session.get(Message if r.target_type == "message" else User, r.target_id)
            groups[key] = {"type": r.target_type, "id": r.target_id, "target": target,
                           "reports": [], "first": r}
        groups[key]["reports"].append(r)
    return render_template("admin_reports.html", groups=list(groups.values()), status=status,
                           active="reports")


@bp.get("/security")
def security():
    return render_template("admin_security.html", data=analytics_service.security_overview(),
                           active="security")


@bp.get("/dse-dates")
def dse_dates():
    events = db.session.execute(db.select(DseEvent).order_by(DseEvent.starts_at)).scalars().all()
    edit = db.session.get(DseEvent, int(request.args["edit"])) \
        if (request.args.get("edit") or "").isdigit() else None
    return render_template("admin_dse_dates.html", events=events, edit=edit, active="dates")


@bp.get("/chat-images/<name>")
def chat_image(name: str):
    return upload_service.send_stored("chat_images", name)


@bp.get("/files/<folder>/<name>")
def stored_file(folder: str, name: str):
    if folder not in ("papers", "materials", "questions"):
        abort(404)
    return upload_service.send_stored(folder, name)


# ====================================================================== users API
def _target_user(user_id: int) -> User:
    user = get_or_404(User, user_id)
    if user.is_deleted:
        abort(404)
    return user


@bp.post("/api/users/<int:user_id>/block")
def block_user(user_id: int):
    user = _target_user(user_id)
    reason = V.clean_text(json_body().get("reason"), 200) or "Broke the community rules"
    moderation_service.block_user(user, reason)
    audit("block_user", user_id=user.id, reason=reason)
    return ok()


@bp.post("/api/users/<int:user_id>/unblock")
def unblock_user(user_id: int):
    user = _target_user(user_id)
    moderation_service.unblock_user(user)
    audit("unblock_user", user_id=user.id)
    return ok()


@bp.post("/api/users/<int:user_id>/shadow-ban")
def shadow_ban(user_id: int):
    user = _target_user(user_id)
    user.is_shadow_banned = V.boolean(json_body().get("on", True))
    db.session.commit()
    audit("shadow_ban", user_id=user.id, on=user.is_shadow_banned)
    return ok({"on": user.is_shadow_banned})


@bp.post("/api/users/<int:user_id>/mute")
def mute(user_id: int):
    user = _target_user(user_id)
    data = json_body()
    try:
        minutes = V.integer(data.get("minutes", 60), min_value=1, max_value=60 * 24 * 30)
    except V.FieldError as e:
        return validation_error({"minutes": e.code})
    reason = V.clean_text(data.get("reason"), 200) or "Broke the chat rules"
    moderation_service.mute_user(user, minutes, reason)
    audit("mute", user_id=user.id, minutes=minutes, reason=reason)
    return ok()


@bp.post("/api/users/<int:user_id>/unmute")
def unmute(user_id: int):
    user = _target_user(user_id)
    user.muted_until = None
    db.session.commit()
    audit("unmute", user_id=user.id)
    return ok()


@bp.post("/api/users/<int:user_id>/warn")
def warn(user_id: int):
    user = _target_user(user_id)
    reason = V.clean_text(json_body().get("reason"), 200) or "Please follow the community rules"
    moderation_service.warn_user(user, reason)
    audit("warn", user_id=user.id, reason=reason)
    return ok()


@bp.post("/api/users/<int:user_id>/points")
def adjust_points(user_id: int):
    user = _target_user(user_id)
    data = json_body()
    try:
        amount = V.integer(data.get("amount"), min_value=-100_000, max_value=100_000)
    except V.FieldError as e:
        return validation_error({"amount": e.code})
    reason = V.clean_text(data.get("reason"), 200)
    if not reason or amount == 0:
        return validation_error({"reason": "required"} if not reason else
                                {"amount": "number_invalid"})
    change = score_service.admin_adjust(user.id, amount, reason)
    db.session.commit()
    audit("adjust_points", user_id=user.id, amount=change, reason=reason)
    return ok({"change": change})


@bp.post("/api/users/<int:user_id>/verify")
def verify_tutor(user_id: int):
    user = _target_user(user_id)
    if user.role != "tutor" or user.tutor_profile is None:
        return error("not_a_tutor", 400)
    verified = V.boolean(json_body().get("verified", True))
    if verified and not user.tutor_profile.certificate_file:
        return error("no_certificate", 400)
    user.tutor_profile.is_verified = verified
    user.tutor_profile.verified_at = utcnow() if verified else None
    db.session.commit()
    audit("verify_tutor", user_id=user.id, verified=verified)
    if verified:
        notification_service.notify(
            user.id, "system", {"en": "Your tutor profile is verified",
                                "zh-HK": "你的導師檔案已通過認證"},
            {"en": "Students now see the Verified badge on your profile.",
             "zh-HK": "學生現在會在你的檔案看到「已認證」標記。"}, "/profile")
    return ok({"verified": verified})


@bp.post("/api/users/<int:user_id>/logout-all")
def logout_all(user_id: int):
    user = _target_user(user_id)
    count = revoke_all_user_sessions(user.id)
    audit("logout_all", user_id=user.id, sessions=count)
    return ok({"ended": count})


# ====================================================================== papers API
def _paper_fields(form: V.Form):
    return {
        "subject_code": form.field("subject", V.subject_code),
        "year": form.field("year", V.integer, min_value=1990, max_value=hk_today().year + 1,
                           code="year_invalid"),
        "paper": form.field("paper", V.text, max_len=30, required=True, code="paper_required"),
        "language": form.field("language", V.choice, C.CONTENT_LANGUAGES,
                               code="language_invalid"),
    }


@bp.post("/api/papers")
def create_paper():
    form = V.Form(request.form.to_dict())
    fields = _paper_fields(form)
    if form.errors:
        return validation_error(form.errors)
    exists = db.session.execute(db.select(PastPaper.id).where(
        PastPaper.subject_code == fields["subject_code"], PastPaper.year == fields["year"],
        PastPaper.paper == fields["paper"], PastPaper.language == fields["language"])).first()
    if exists:
        return error("paper_exists", 409)
    try:
        saved = upload_service.save_pdf(request.files.get("file"), "papers")
        marking = upload_service.save_pdf(request.files.get("marking"), "papers") \
            if request.files.get("marking") and request.files["marking"].filename else None
    except UploadError as e:
        return error(e.code, 400)
    paper = PastPaper(**fields, file_name=saved.name, file_size=saved.size,
                      marking_file=marking.name if marking else None,
                      marking_size=marking.size if marking else None, uploaded_by=g.admin.id)
    db.session.add(paper)
    db.session.commit()
    audit("upload_paper", paper_id=paper.id, subject=paper.subject_code, year=paper.year)
    return ok({"id": paper.id}, 201)


@bp.post("/api/papers/<int:paper_id>")
def update_paper(paper_id: int):
    paper = get_or_404(PastPaper, paper_id)
    form = V.Form(request.form.to_dict())
    fields = _paper_fields(form)
    if form.errors:
        return validation_error(form.errors)
    try:
        if request.files.get("file") and request.files["file"].filename:
            saved = upload_service.save_pdf(request.files["file"], "papers")
            upload_service.delete_file("papers", paper.file_name)
            paper.file_name, paper.file_size = saved.name, saved.size
        if request.files.get("marking") and request.files["marking"].filename:
            marking = upload_service.save_pdf(request.files["marking"], "papers")
            upload_service.delete_file("papers", paper.marking_file)
            paper.marking_file, paper.marking_size = marking.name, marking.size
        elif V.boolean(request.form.get("remove_marking")):
            upload_service.delete_file("papers", paper.marking_file)
            paper.marking_file = paper.marking_size = None
    except UploadError as e:
        return error(e.code, 400)
    for key, value in fields.items():
        setattr(paper, key, value)
    db.session.commit()
    audit("update_paper", paper_id=paper.id)
    return ok()


@bp.delete("/api/papers/<int:paper_id>")
def delete_paper(paper_id: int):
    paper = get_or_404(PastPaper, paper_id)
    upload_service.delete_file("papers", paper.file_name)
    upload_service.delete_file("papers", paper.marking_file)
    db.session.delete(paper)
    db.session.commit()
    audit("delete_paper", paper_id=paper_id)
    return ok()


# ====================================================================== materials API
def _material_from_form(material: Material | None):
    data = request.form.to_dict()
    form = V.Form(data)
    fields = {
        "subject_code": form.field("subject", V.subject_code),
        "topic": form.field("topic", V.text, max_len=80) or "General",
        "title": form.field("title", V.text, max_len=160, required=True, code="title_required"),
        "description": form.field("description", V.text, max_len=2000, multiline=True),
        "kind": form.field("kind", V.choice, C.MATERIAL_KINDS, code="kind_invalid"),
        "language": form.field("language", V.choice, C.CONTENT_LANGUAGES,
                               code="language_invalid"),
        "allow_download": V.boolean(data.get("allow_download")),
        "is_published": V.boolean(data.get("published")),
    }
    kind = fields["kind"]
    if kind == "video_link":
        fields["url"] = form.field("url", V.url)
    elif kind == "note":
        fields["body"] = form.field("body", V.text, max_len=20000, multiline=True,
                                    required=True, code="body_required")
    upload = request.files.get("file")
    has_upload = bool(upload and upload.filename)
    if kind in ("pdf", "image") and not has_upload and \
            (material is None or material.kind != kind or not material.file_name):
        form.errors["file"] = "file_missing"
    return form, fields, upload if has_upload else None


def _apply_material(material: Material, fields: dict, upload) -> None:
    kind = fields["kind"]
    if upload is not None:
        saved = upload_service.save_pdf(upload, "materials") if kind == "pdf" \
            else upload_service.save_image(upload, "materials", max_side=2400)
        upload_service.delete_file("materials", material.file_name)
        material.file_name, material.file_size = saved.name, saved.size
    if kind in ("video_link", "note") and material.file_name:
        upload_service.delete_file("materials", material.file_name)
        material.file_name = material.file_size = None
    for key, value in fields.items():
        setattr(material, key, value)
    if kind != "video_link":
        material.url = None
    if kind != "note":
        material.body = None


def _notify_material(material: Material) -> None:
    ids = db.session.execute(
        db.select(User.id).where(User.subjects.any(code=material.subject_code),
                                 User.is_deleted.is_(False), User.is_blocked.is_(False))
    ).scalars().all()
    subj = C.SUBJECT_BY_CODE[material.subject_code]
    notification_service.notify_many(
        ids, "material",
        {"en": f"New {subj['name_en']} material", "zh-HK": f"新的{subj['name_zh']}學習資源"},
        material.title, f"/material?id={material.id}")


@bp.post("/api/materials")
def create_material():
    form, fields, upload = _material_from_form(None)
    if form.errors:
        return validation_error(form.errors)
    material = Material(created_by=g.admin.id)
    try:
        _apply_material(material, fields, upload)
    except UploadError as e:
        return error(e.code, 400)
    db.session.add(material)
    db.session.commit()
    audit("create_material", material_id=material.id)
    if material.is_published and V.boolean(request.form.get("notify")):
        _notify_material(material)
    return ok({"id": material.id}, 201)


@bp.post("/api/materials/<int:material_id>")
def update_material(material_id: int):
    material = get_or_404(Material, material_id)
    was_published = material.is_published
    form, fields, upload = _material_from_form(material)
    if form.errors:
        return validation_error(form.errors)
    try:
        _apply_material(material, fields, upload)
    except UploadError as e:
        return error(e.code, 400)
    db.session.commit()
    audit("update_material", material_id=material.id)
    if material.is_published and not was_published and V.boolean(request.form.get("notify")):
        _notify_material(material)
    return ok()


@bp.post("/api/materials/<int:material_id>/publish")
def publish_material(material_id: int):
    material = get_or_404(Material, material_id)
    material.is_published = V.boolean(json_body().get("published", True))
    db.session.commit()
    audit("publish_material", material_id=material.id, published=material.is_published)
    return ok({"published": material.is_published})


@bp.delete("/api/materials/<int:material_id>")
def delete_material(material_id: int):
    material = get_or_404(Material, material_id)
    upload_service.delete_file("materials", material.file_name)
    db.session.delete(material)
    db.session.commit()
    audit("delete_material", material_id=material_id)
    return ok()


# ====================================================================== quiz bank API
@bp.post("/api/banks")
def create_bank():
    form = V.Form(form_or_json())
    subject = form.field("subject", V.subject_code)
    level = form.field("level", V.choice, C.QUIZ_LEVELS, code="level_invalid")
    name = form.field("name", V.text, max_len=120, required=True, code="name_required")
    description = form.field("description", V.text, max_len=1000, multiline=True)
    if form.errors:
        return validation_error(form.errors)
    bank = QuestionBank(subject_code=subject, level=level, name=name, description=description)
    db.session.add(bank)
    db.session.commit()
    audit("create_bank", bank_id=bank.id)
    return ok({"id": bank.id}, 201)


@bp.delete("/api/banks/<int:bank_id>")
def delete_bank(bank_id: int):
    bank = get_or_404(QuestionBank, bank_id)
    used = db.session.execute(
        db.select(Attempt.id).join(Assessment, Attempt.assessment_id == Assessment.id)
        .where(Assessment.bank_id == bank.id).limit(1)).first()
    if used:
        return error("bank_in_use", 409)
    for a in db.session.execute(db.select(Assessment).where(Assessment.bank_id == bank.id)) \
            .scalars():
        db.session.delete(a)
    for q in bank.questions:
        upload_service.delete_file("questions", q.image_file)
    db.session.delete(bank)
    db.session.commit()
    audit("delete_bank", bank_id=bank_id)
    return ok()


def _question_fields(data: dict) -> tuple[V.Form, dict]:
    form = V.Form(data)
    qtype = form.field("type", V.choice, C.QUESTION_TYPES, code="type_invalid")
    fields = {
        "topic": form.field("topic", V.text, max_len=80) or "General",
        "qtype": qtype,
        "prompt": form.field("prompt", V.text, max_len=4000, required=True, multiline=True,
                             code="prompt_required"),
        "explanation": form.field("explanation", V.text, max_len=4000, multiline=True),
        "marks": form.field("marks", V.integer, min_value=1, max_value=20,
                            code="marks_invalid", required=False) or 1,
    }
    if qtype == "mcq":
        options = []
        for letter in "abcdef":
            text = V.clean_text(data.get(f"option_{letter}"), 500)
            if text:
                options.append({"id": letter, "text": text})
        if len(options) < 2:
            form.errors["option_a"] = "options_required"
        answer = V.clean_text(data.get("answer_mcq") or data.get("answer"), 5).lower()
        if answer not in {o["id"] for o in options}:
            form.errors["answer"] = "answer_invalid"
        fields.update(options=options, answer=answer)
    elif qtype == "short":
        answer = V.clean_text(data.get("answer_short") or data.get("answer"), 300)
        if not answer:
            form.errors["answer"] = "answer_invalid"
        fields.update(options=None, answer=answer)
    return form, fields


@bp.post("/api/banks/<int:bank_id>/questions")
def create_question(bank_id: int):
    bank = get_or_404(QuestionBank, bank_id)
    form, fields = _question_fields(request.form.to_dict())
    if form.errors:
        return validation_error(form.errors)
    question = Question(bank_id=bank.id, **fields)
    image = request.files.get("image")
    if image and image.filename:
        try:
            question.image_file = upload_service.save_image(image, "questions", 1600).name
        except UploadError as e:
            return error(e.code, 400)
    db.session.add(question)
    db.session.commit()
    audit("create_question", question_id=question.id, bank_id=bank.id)
    return ok({"id": question.id}, 201)


@bp.post("/api/questions/<int:question_id>")
def update_question(question_id: int):
    question = get_or_404(Question, question_id)
    form, fields = _question_fields(request.form.to_dict())
    if form.errors:
        return validation_error(form.errors)
    image = request.files.get("image")
    try:
        if image and image.filename:
            saved = upload_service.save_image(image, "questions", 1600)
            upload_service.delete_file("questions", question.image_file)
            question.image_file = saved.name
        elif V.boolean(request.form.get("remove_image")):
            upload_service.delete_file("questions", question.image_file)
            question.image_file = None
    except UploadError as e:
        return error(e.code, 400)
    for key, value in fields.items():
        setattr(question, key, value)
    db.session.commit()
    audit("update_question", question_id=question.id)
    return ok()


@bp.post("/api/questions/<int:question_id>/active")
def question_active(question_id: int):
    question = get_or_404(Question, question_id)
    question.is_active = V.boolean(json_body().get("active", True))
    db.session.commit()
    audit("question_active", question_id=question.id, active=question.is_active)
    return ok({"active": question.is_active})


@bp.delete("/api/questions/<int:question_id>")
def delete_question(question_id: int):
    question = get_or_404(Question, question_id)
    used = db.session.execute(db.select(AttemptQuestion.id)
                              .where(AttemptQuestion.question_id == question.id).limit(1)).first()
    if used:                                    # keep it for past results; just retire it
        question.is_active = False
        db.session.commit()
        audit("retire_question", question_id=question.id)
        return ok({"retired": True})
    upload_service.delete_file("questions", question.image_file)
    db.session.delete(question)
    db.session.commit()
    audit("delete_question", question_id=question_id)
    return ok({"retired": False})


CSV_COLUMNS = ("topic", "type", "prompt", "option_a", "option_b", "option_c", "option_d",
               "answer", "explanation", "marks")


@bp.post("/api/banks/<int:bank_id>/import")
def import_questions(bank_id: int):
    """CSV columns: topic,type,prompt,option_a,option_b,option_c,option_d,answer,explanation,
    marks (subject and level columns are allowed and ignored). preview=1 only checks."""
    bank = get_or_404(QuestionBank, bank_id)
    upload = request.files.get("file")
    if upload is None or not upload.filename:
        return error("file_missing", 400)
    raw = upload.read(C.MAX_CSV_MB * 1024 * 1024 + 1)
    if len(raw) > C.MAX_CSV_MB * 1024 * 1024:
        return error("file_too_large", 400)
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return error("csv_not_utf8", 400)
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames or not {"type", "prompt", "answer"} <= {
            (f or "").strip().lower() for f in reader.fieldnames}:
        return error("csv_columns", 400)
    rows, problems = [], []
    for line_no, row in enumerate(reader, start=2):
        row = {(k or "").strip().lower(): (v or "") for k, v in row.items()}
        row.setdefault("type", "mcq")
        row["type"] = row["type"].strip().lower() or "mcq"
        if row["type"] == "mcq":
            row["answer"] = row.get("answer", "").strip().lower()
        form, fields = _question_fields(row)
        if form.errors:
            problems.append({"line": line_no, "errors": form.errors})
        else:
            rows.append(fields)
        if line_no > 2001:
            problems.append({"line": line_no, "errors": {"file": "csv_too_many_rows"}})
            break
    preview = V.boolean(request.form.get("preview"))
    if preview or problems:
        return ok({"preview": [
            {"topic": r["topic"], "type": r["qtype"], "prompt": r["prompt"][:120],
             "answer": r["answer"], "options": len(r["options"] or [])} for r in rows[:200]],
            "valid": len(rows), "problems": problems[:100], "saved": 0})
    for fields in rows:
        db.session.add(Question(bank_id=bank.id, **fields))
    db.session.commit()
    audit("import_questions", bank_id=bank.id, count=len(rows))
    return ok({"saved": len(rows), "valid": len(rows), "problems": [], "preview": []})


@bp.post("/api/assessments")
def create_assessment():
    form = V.Form(form_or_json())
    bank_id = form.field("bank_id", V.integer, min_value=1, code="bank_invalid")
    kind = form.field("kind", V.choice, C.ASSESSMENT_KINDS, code="kind_invalid")
    defaults = C.ASSESSMENT_RULES.get(kind or "quiz")
    title = form.field("title", V.text, max_len=160, required=True, code="title_required")
    count = form.field("question_count", V.integer, min_value=1, max_value=200,
                       code="number_invalid", required=False) or defaults["questions"]
    minutes = form.field("time_limit_min", V.integer, min_value=1, max_value=300,
                         code="number_invalid", required=False) or defaults["minutes"]
    base = form.field("points_base", V.integer, min_value=0, max_value=100,
                      code="number_invalid", required=False)
    bonus = form.field("points_bonus_max", V.integer, min_value=0, max_value=100,
                       code="number_invalid", required=False)
    bank = db.session.get(QuestionBank, bank_id) if bank_id else None
    if bank_id and bank is None:
        form.errors["bank_id"] = "bank_invalid"
    if form.errors:
        return validation_error(form.errors)
    assessment = Assessment(
        title=title, bank_id=bank.id, subject_code=bank.subject_code, level=bank.level,
        kind=kind, question_count=count, time_limit_min=minutes,
        points_base=defaults["base"] if base is None else base,
        points_bonus_max=defaults["bonus_max"] if bonus is None else bonus,
        is_published=V.boolean(form.data.get("published")))
    db.session.add(assessment)
    db.session.commit()
    audit("create_assessment", assessment_id=assessment.id)
    return ok({"id": assessment.id}, 201)


@bp.post("/api/assessments/<int:assessment_id>/publish")
def publish_assessment(assessment_id: int):
    assessment = get_or_404(Assessment, assessment_id)
    assessment.is_published = V.boolean(json_body().get("published", True))
    db.session.commit()
    audit("publish_assessment", assessment_id=assessment.id, published=assessment.is_published)
    return ok({"published": assessment.is_published})


@bp.delete("/api/assessments/<int:assessment_id>")
def delete_assessment(assessment_id: int):
    assessment = get_or_404(Assessment, assessment_id)
    used = db.session.execute(db.select(Attempt.id).where(
        Attempt.assessment_id == assessment.id).limit(1)).first()
    if used:
        assessment.is_published = False         # keep results; just hide it
        db.session.commit()
        audit("unpublish_assessment", assessment_id=assessment.id)
        return ok({"retired": True})
    db.session.delete(assessment)
    db.session.commit()
    audit("delete_assessment", assessment_id=assessment_id)
    return ok({"retired": False})


# ====================================================================== chat API
@bp.get("/api/chat/<code>/messages")
def chat_messages(code: str):
    code = code.upper()
    if code not in C.SUBJECT_CODES:
        abort(404)
    stmt = db.select(Message).where(Message.subject_code == code)
    q = V.clean_text(request.args.get("q"), 80)
    if q:
        stmt = stmt.where(Message.text.contains(q, autoescape=True))
    if request.args.get("filter") == "reported":
        stmt = stmt.where(Message.report_count > 0)
    rows = db.session.execute(stmt.order_by(Message.id.desc()).limit(100)).scalars().all()
    pinned_ids = {m.id for m in chat_service.pinned(code)}
    items = []
    for m in reversed(rows):
        d = m.to_dict(for_admin=True)
        d["pinned"] = m.id in pinned_ids
        d["admin_image_url"] = url_for("admin.chat_image", name=d["image_file"]) \
            if d.get("image_file") else None
        d["user_link"] = url_for("admin.user_detail", user_id=m.user_id)
        items.append(d)
    return ok({"messages": items})


@bp.delete("/api/messages/<int:message_id>")
def delete_message(message_id: int):
    message = get_or_404(Message, message_id)
    data = json_body()
    reason = V.clean_text(data.get("reason"), 200) or "Removed by moderator"
    penalty = V.boolean(data.get("penalty"))
    chat_service.delete_message(message, g.admin.id, reason, penalty=penalty)
    moderation_service.close_reports("message", message.id, g.admin.id, "delete_message")
    audit("delete_message", message_id=message.id, reason=reason, penalty=penalty)
    return ok()


@bp.post("/api/messages/<int:message_id>/pin")
def pin_message(message_id: int):
    message = get_or_404(Message, message_id)
    pinned = V.boolean(json_body().get("pinned", True))
    chat_service.set_pinned(message, g.admin.id, pinned)
    audit("pin_message", message_id=message.id, pinned=pinned)
    return ok({"pinned": pinned})


@bp.post("/api/messages/<int:message_id>/unhide")
def unhide_message(message_id: int):
    message = get_or_404(Message, message_id)
    message.is_hidden = False
    db.session.commit()
    moderation_service.close_reports("message", message.id, g.admin.id, "dismiss")
    socketio.emit("message_restored", message.to_dict(), to=message.subject_code,
                  namespace="/chat")
    audit("unhide_message", message_id=message.id)
    return ok()


# ====================================================================== reports API
@bp.post("/api/reports/<int:report_id>/action")
def report_action(report_id: int):
    report = get_or_404(Report, report_id)
    data = json_body()
    minutes = None
    if data.get("minutes"):
        try:
            minutes = V.integer(data.get("minutes"), min_value=1, max_value=60 * 24 * 30)
        except V.FieldError as e:
            return validation_error({"minutes": e.code})
    try:
        result = moderation_service.action_report(
            report, g.admin, str(data.get("action")), V.clean_text(data.get("reason"), 200),
            minutes)
    except moderation_service.ModerationError as e:
        return error(e.code, 400)
    audit("report_action", report_id=report.id, action=result["action"],
          target_type=report.target_type, target_id=report.target_id)
    return ok(result)


# ====================================================================== security API
@bp.post("/api/ips/block")
def block_ip():
    data = json_body()
    ip = V.clean_text(data.get("ip"), 45)
    try:
        ipaddress.ip_address(ip)
    except ValueError:
        return validation_error({"ip": "ip_invalid"})
    hours = data.get("hours")
    try:
        hours = None if hours in (None, "", "permanent") else \
            V.integer(hours, min_value=1, max_value=24 * 365)
    except V.FieldError as e:
        return validation_error({"hours": e.code})
    reason = V.clean_text(data.get("reason"), 200) or "Blocked by admin"
    abuse_detector.block_ip(ip, hours=hours, reason=reason, created_by=f"admin:{g.admin.id}")
    audit("block_ip", ip=ip, hours=hours, reason=reason)
    return ok()


@bp.delete("/api/ips/<int:block_id>")
def unblock_ip(block_id: int):
    row = get_or_404(BlockedIP, block_id)
    ip = row.ip
    db.session.delete(row)
    db.session.commit()
    ip_tracker.invalidate_block_cache()
    audit("unblock_ip", ip=ip)
    return ok()


@bp.post("/api/stats/refresh")
def refresh_stats():
    analytics_service.summary(force=True)
    return ok()


# ====================================================================== DSE dates API
def _event_fields():
    form = V.Form(form_or_json())
    fields = {
        "title_en": form.field("title_en", V.text, max_len=160, required=True,
                               code="title_required"),
        "title_zh": form.field("title_zh", V.text, max_len=160, required=True,
                               code="title_required"),
        "subject_code": form.field("subject", V.subject_code)
        if form.data.get("subject") else None,
        "kind": form.field("kind", V.choice, C.DSE_EVENT_KINDS, code="kind_invalid"),
        "starts_at": form.field("starts_at", V.hk_datetime),
        "is_published": V.boolean(form.data.get("published")),
    }
    return form, fields


@bp.post("/api/dse-events")
def create_event():
    form, fields = _event_fields()
    if form.errors:
        return validation_error(form.errors)
    event = DseEvent(**fields)
    db.session.add(event)
    db.session.commit()
    audit("create_dse_event", event_id=event.id, starts_at=iso_hk(event.starts_at))
    return ok({"id": event.id}, 201)


@bp.post("/api/dse-events/<int:event_id>")
def update_event(event_id: int):
    event = get_or_404(DseEvent, event_id)
    form, fields = _event_fields()
    if form.errors:
        return validation_error(form.errors)
    for key, value in fields.items():
        setattr(event, key, value)
    db.session.commit()
    audit("update_dse_event", event_id=event.id)
    return ok()


@bp.delete("/api/dse-events/<int:event_id>")
def delete_event(event_id: int):
    event = get_or_404(DseEvent, event_id)
    db.session.delete(event)
    db.session.commit()
    audit("delete_dse_event", event_id=event_id)
    return ok()


@bp.post("/api/dse-events/<int:event_id>/publish")
def publish_event(event_id: int):
    event = get_or_404(DseEvent, event_id)
    event.is_published = V.boolean(json_body().get("published", True))
    db.session.commit()
    audit("publish_dse_event", event_id=event.id, published=event.is_published)
    return ok({"published": event.is_published})
