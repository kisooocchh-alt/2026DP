"""Booking requests between students and tutors: /api/bookings..."""
from flask import Blueprint, g
from sqlalchemy import distinct, func

from .. import constants as C
from ..extensions import db, limiter
from ..models.booking import BookingRequest
from ..models.user import TutorProfile, User
from ..security import ip_tracker, rate_limits
from ..security import validators as V
from ..security.decorators import login_required, role_required
from ..services import moderation_service, notification_service
from ..utils.responses import error, json_body, ok
from ..utils.time_utils import utcnow

bp = Blueprint("bookings", __name__, url_prefix="/api/bookings")

# action -> (who may do it, allowed current statuses, new status)
TRANSITIONS = {
    "accept": ("tutor", ("pending",), "accepted"),
    "decline": ("tutor", ("pending",), "declined"),
    "cancel": ("either", ("pending", "accepted"), "cancelled"),
    "complete": ("student", ("accepted",), "completed"),
}

MESSAGES = {
    "created": ({"en": "New booking request", "zh-HK": "新的預約請求"},
                {"en": "{name} would like lessons in {subject}.",
                 "zh-HK": "{name} 想預約{subject_zh}課堂。"}),
    "accepted": ({"en": "Booking accepted", "zh-HK": "預約已接受"},
                 {"en": "{name} accepted your {subject} booking. You can now see their contact.",
                  "zh-HK": "{name} 接受了你的{subject_zh}預約，你現在可以查看對方的聯絡方法。"}),
    "declined": ({"en": "Booking declined", "zh-HK": "預約被拒絕"},
                 {"en": "{name} declined your {subject} booking.",
                  "zh-HK": "{name} 拒絕了你的{subject_zh}預約。"}),
    "cancelled": ({"en": "Booking cancelled", "zh-HK": "預約已取消"},
                  {"en": "{name} cancelled the {subject} booking.",
                   "zh-HK": "{name} 取消了{subject_zh}預約。"}),
    "completed": ({"en": "Lessons marked as completed", "zh-HK": "課堂已標記為完成"},
                  {"en": "{name} marked your {subject} lessons as completed.",
                   "zh-HK": "{name} 已將{subject_zh}課堂標記為完成。"}),
}


def _notify(event: str, booking: BookingRequest, actor: User, recipient_id: int) -> None:
    title, body = MESSAGES[event]
    subj = C.SUBJECT_BY_CODE[booking.subject_code]
    fill = {"name": actor.name, "subject": subj["name_en"], "subject_zh": subj["name_zh"]}
    notification_service.notify(recipient_id, "booking", title,
                                {k: v.format(**fill) for k, v in body.items()}, "/bookings")


@bp.post("")
@role_required("student")
@limiter.limit(rate_limits.BOOKING, key_func=rate_limits.user_key)
def create():
    form = V.Form(json_body())
    tutor_id = form.field("tutor_id", V.integer, min_value=1, code="tutor_invalid")
    subject = form.field("subject", V.subject_code)
    message = form.field("message", V.text, max_len=C.BOOKING_MESSAGE_MAX, required=True,
                         multiline=True, code="message_required")
    times = form.field("preferred_times", V.text, max_len=200)
    if message and moderation_service.contains_banned_words(message):
        form.errors["message"] = "blocked_words"
    if form.errors:
        return error("validation_failed", 400, fields=form.errors)
    tutor = db.session.get(User, tutor_id)
    if tutor is None or tutor.role != "tutor" or tutor.is_blocked or tutor.is_deleted:
        return error("not_found", 404)
    if subject not in {s.code for s in tutor.subjects}:
        return error("validation_failed", 400, fields={"subject": "subject_not_taught"})
    pending = db.session.execute(
        db.select(BookingRequest.id).where(BookingRequest.student_id == g.user.id,
                                           BookingRequest.tutor_id == tutor.id,
                                           BookingRequest.status == "pending")).first()
    if pending:
        return error("booking_exists", 409)
    booking = BookingRequest(student_id=g.user.id, tutor_id=tutor.id, subject_code=subject,
                             message=message, preferred_times=times or None)
    db.session.add(booking)
    db.session.commit()
    ip_tracker.log_activity("booking.create", user_id=g.user.id,
                            meta={"booking_id": booking.id, "tutor_id": tutor.id})
    _notify("created", booking, g.user, tutor.id)
    return ok({"booking": booking.to_dict(g.user.id)}, 201)


@bp.get("")
@login_required
def mine():
    sent = db.session.execute(
        db.select(BookingRequest).where(BookingRequest.student_id == g.user.id)
        .order_by(BookingRequest.id.desc()).limit(100)).scalars()
    received = db.session.execute(
        db.select(BookingRequest).where(BookingRequest.tutor_id == g.user.id)
        .order_by(BookingRequest.id.desc()).limit(100)).scalars()
    return ok({"sent": [b.to_dict(g.user.id) for b in sent],
               "received": [b.to_dict(g.user.id) for b in received]})


@bp.patch("/<int:booking_id>")
@login_required
def change(booking_id: int):
    action = json_body().get("action")
    if action not in TRANSITIONS:
        return error("action_invalid", 400)
    booking = db.session.get(BookingRequest, booking_id)
    me = g.user.id
    if booking is None or me not in (booking.student_id, booking.tutor_id):
        return error("not_found", 404)
    who, allowed, new_status = TRANSITIONS[action]
    my_side = "student" if me == booking.student_id else "tutor"
    if who != "either" and who != my_side:
        return error("forbidden", 403)
    if booking.status not in allowed:
        return error("booking_status_invalid", 409)
    booking.status = new_status
    if action in ("accept", "decline"):
        booking.responded_at = utcnow()
    if action == "complete":
        booking.completed_at = utcnow()
        tp = db.session.get(TutorProfile, booking.tutor_id)
        if tp is not None:
            tp.students_helped = db.session.execute(
                db.select(func.count(distinct(BookingRequest.student_id)))
                .where(BookingRequest.tutor_id == booking.tutor_id,
                       BookingRequest.status == "completed")).scalar_one()
    db.session.commit()
    ip_tracker.log_activity(f"booking.{action}", user_id=me, meta={"booking_id": booking.id})
    other = booking.tutor_id if my_side == "student" else booking.student_id
    _notify(new_status, booking, g.user, other)
    return ok({"booking": booking.to_dict(me)})
