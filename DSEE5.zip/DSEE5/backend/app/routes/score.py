"""Points balance, daily reward and history: /api/score..."""
from flask import Blueprint, g

from ..security import ip_tracker
from ..security.decorators import login_required
from ..services import score_service
from ..utils.responses import error, ok

bp = Blueprint("score", __name__, url_prefix="/api/score")


@bp.get("")
@login_required
def balance():
    return ok(score_service.summary(g.user))


@bp.post("/daily")
@login_required
def claim_daily():
    try:
        result = score_service.claim_daily_reward(g.user)
    except score_service.AlreadyClaimed:
        return error("already_claimed", 409)
    ip_tracker.log_activity("score.daily", user_id=g.user.id, meta={"amount": result["amount"]})
    return ok(result)


@bp.get("/history")
@login_required
def history():
    return ok({"items": score_service.history(g.user.id)})
