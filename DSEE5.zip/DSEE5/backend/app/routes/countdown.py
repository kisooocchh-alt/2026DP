"""Data for the DSE countdown timer: /api/countdown..."""
from flask import Blueprint, g

from ..extensions import db
from ..models.dse_event import CountdownFollow, DseEvent
from ..security import validators as V
from ..security.decorators import login_required
from ..utils.responses import error, json_body, ok
from ..utils.time_utils import iso_utc, utcnow

bp = Blueprint("countdown", __name__, url_prefix="/api/countdown")


@bp.get("/events")
def events():
    """Works when logged out, so the home page can show the countdown."""
    rows = db.session.execute(
        db.select(DseEvent).where(DseEvent.is_published.is_(True),
                                  DseEvent.starts_at > utcnow())
        .order_by(DseEvent.starts_at).limit(200)).scalars()
    return ok({"events": [e.to_dict() for e in rows], "server_now": iso_utc(utcnow())})


@bp.get("/following")
@login_required
def following():
    codes = db.session.execute(
        db.select(CountdownFollow.subject_code).where(CountdownFollow.user_id == g.user.id)
    ).scalars().all()
    return ok({"subjects": list(codes)})


@bp.put("/following")
@login_required
def set_following():
    try:
        codes = V.subject_list(json_body().get("subjects"), max_count=30)
    except V.FieldError as e:
        return error("validation_failed", 400, fields={"subjects": e.code})
    db.session.execute(db.delete(CountdownFollow).where(CountdownFollow.user_id == g.user.id))
    for code in codes:
        db.session.add(CountdownFollow(user_id=g.user.id, subject_code=code))
    db.session.commit()
    return ok({"subjects": codes})
