"""The hidden admin login. It only exists under the secret prefix from .env, for example
/k3Jd9-xQ2a/login. Password AND a 6-digit authenticator code are always required."""
from datetime import timedelta

from flask import Blueprint, abort, g, redirect, render_template, request, session, url_for

from ..extensions import db, limiter
from ..models.admin import AdminAccount
from ..security import ip_tracker, rate_limits, totp
from ..security.decorators import admin_ip_allowed
from ..security.passwords import DUMMY_HASH, needs_rehash, hash_password, verify_password
from ..security.sessions import end_admin_session, start_admin_session
from ..utils.time_utils import utcnow

bp = Blueprint("admin_auth", __name__, template_folder="../admin_ui/templates")

MAX_FAILURES = 3
LOCK_MINUTES = 30
GENERIC_ERROR = "Sign-in failed. Check your details and try again."


@bp.before_request
def only_allowed_ips():
    if not admin_ip_allowed():
        abort(404)


@bp.after_request
def no_store(response):
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Robots-Tag"] = "noindex, nofollow"
    return response


@bp.get("/login")
def login_page():
    if g.get("admin") is not None:
        return redirect(url_for("admin.dashboard"))
    return render_template("admin_login.html", error=None)


@bp.post("/login")
@limiter.limit(rate_limits.ADMIN_LOGIN)
def login():
    username = (request.form.get("username") or "").strip()[:40]
    password = request.form.get("password") or ""
    code = request.form.get("code") or ""
    admin = db.session.execute(
        db.select(AdminAccount).where(AdminAccount.username == username)
    ).scalar_one_or_none()

    if admin is not None and admin.locked_until and admin.locked_until > utcnow():
        verify_password(DUMMY_HASH, password)
        ip_tracker.log_activity("admin.login", admin_id=admin.id, success=False,
                                meta={"reason": "locked"})
        return render_template("admin_login.html", error=GENERIC_ERROR), 400

    password_ok = verify_password(admin.password_hash if admin else DUMMY_HASH, password)
    step = totp.verify(admin.totp_secret, code, admin.totp_last_timecode) \
        if admin is not None and password_ok else None

    if admin is None or not password_ok or step is None:
        if admin is not None:
            admin.failed_attempts += 1
            if admin.failed_attempts >= MAX_FAILURES:
                admin.locked_until = utcnow() + timedelta(minutes=LOCK_MINUTES)
                admin.failed_attempts = 0
            db.session.commit()
        ip_tracker.log_activity("admin.login", admin_id=admin.id if admin else None,
                                success=False, meta={"username": username})
        return render_template("admin_login.html", error=GENERIC_ERROR), 400

    admin.failed_attempts = 0
    admin.locked_until = None
    admin.totp_last_timecode = step
    admin.last_login_at = utcnow()
    admin.last_login_ip = ip_tracker.client_ip()
    if needs_rehash(admin.password_hash):
        admin.password_hash = hash_password(password)
    db.session.commit()
    ip_tracker.log_activity("admin.login", admin_id=admin.id)
    session.clear()
    return start_admin_session(admin, redirect(url_for("admin.dashboard")))


@bp.post("/logout")
def logout():
    if g.get("admin") is not None:
        ip_tracker.log_activity("admin.logout", admin_id=g.admin.id)
    session.clear()
    return end_admin_session(redirect(url_for("admin_auth.login_page")))
