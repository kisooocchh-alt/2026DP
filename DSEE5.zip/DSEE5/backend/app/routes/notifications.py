"""In-app notifications and browser push subscription: /api/notifications..."""
from urllib.parse import urlparse

from flask import Blueprint, current_app, g

from ..extensions import db
from ..models.notification import Notification, PushSubscription
from ..security import validators as V
from ..security.decorators import login_required
from ..services import notification_service
from ..utils.responses import error, json_body, ok

bp = Blueprint("notifications", __name__, url_prefix="/api/notifications")


@bp.get("")
@login_required
def list_notifications():
    rows = db.session.execute(
        db.select(Notification).where(Notification.user_id == g.user.id)
        .order_by(Notification.id.desc()).limit(50)).scalars()
    return ok({"items": [n.to_dict() for n in rows],
               "unread": notification_service.unread_count(g.user.id)})


@bp.get("/unread")
@login_required
def unread():
    return ok({"unread": notification_service.unread_count(g.user.id)})


@bp.post("/read")
@login_required
def mark_read():
    try:
        ids = V.id_list(json_body().get("ids"))
    except V.FieldError:
        return error("bad_request", 400)
    stmt = db.update(Notification).where(Notification.user_id == g.user.id,
                                         Notification.is_read.is_(False))
    if ids:
        stmt = stmt.where(Notification.id.in_(ids))
    db.session.execute(stmt.values(is_read=True))
    db.session.commit()
    return ok({"unread": notification_service.unread_count(g.user.id)})


@bp.get("/vapid-key")
def vapid_key():
    enabled = notification_service.push_enabled()
    return ok({"enabled": enabled,
               "key": current_app.config["VAPID_PUBLIC_KEY"] if enabled else ""})


@bp.post("/subscribe")
@login_required
def subscribe():
    sub = json_body().get("subscription") or {}
    endpoint = str(sub.get("endpoint") or "")
    keys = sub.get("keys") or {}
    if urlparse(endpoint).scheme != "https" or len(endpoint) > 500 or \
            not keys.get("p256dh") or not keys.get("auth"):
        return error("subscription_invalid", 400)
    row = db.session.execute(
        db.select(PushSubscription).where(PushSubscription.endpoint == endpoint)
    ).scalar_one_or_none()
    if row is None:
        row = PushSubscription(endpoint=endpoint)
        db.session.add(row)
    row.user_id = g.user.id
    row.p256dh = str(keys["p256dh"])[:200]
    row.auth = str(keys["auth"])[:100]
    db.session.commit()
    return ok({}, 201)


@bp.delete("/subscribe")
@login_required
def unsubscribe():
    endpoint = str(json_body().get("endpoint") or "")
    db.session.execute(db.delete(PushSubscription).where(
        PushSubscription.user_id == g.user.id, PushSubscription.endpoint == endpoint))
    db.session.commit()
    return ok()
