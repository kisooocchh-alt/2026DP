"""Registers every blueprint and the error handlers."""
from flask import current_app, g, jsonify, request, send_from_directory
from flask_wtf.csrf import CSRFError

from ..extensions import limiter
from ..security import rate_limits
from . import (admin, admin_auth, auth, bookings, bookmarks, chat, countdown, materials,
               notifications, pages, papers, profile, quiz, reports, score, tutors)

API_BLUEPRINTS = [auth.bp, profile.bp, tutors.bp, bookings.bp, papers.bp, materials.bp,
                  bookmarks.bp, chat.bp, quiz.bp, score.bp, countdown.bp, reports.bp,
                  notifications.bp]
_limited: set[str] = set()


def register_blueprints(app) -> None:
    for bp in API_BLUEPRINTS:
        if bp.name not in _limited:                  # blueprints are shared module objects
            limiter.limit(rate_limits.GENERAL_API)(bp)
            _limited.add(bp.name)
        app.register_blueprint(bp)
    app.register_blueprint(pages.bp)

    prefix = app.config["ADMIN_URL_PREFIX"]          # secret path from .env
    app.register_blueprint(admin_auth.bp, url_prefix=prefix)
    app.register_blueprint(admin.bp, url_prefix=prefix)
    _register_error_handlers(app)


def _wants_json() -> bool:
    path = request.path
    if path.startswith("/api/"):
        return True
    prefix = current_app.config["ADMIN_URL_PREFIX"]
    return path.startswith(prefix + "/api/") and g.get("admin") is not None


def _not_found_page():
    return send_from_directory(current_app.static_folder, "pages/404.html"), 404


def _simple_page(text: str, status: int):
    body = (f"<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\">"
            f"<title>DSEE5</title></head><body><p>{text}</p>"
            f"<p><a href=\"/\">Back to DSEE5</a></p></body></html>")
    return body, status, {"Content-Type": "text/html; charset=utf-8"}


def _register_error_handlers(app) -> None:
    def api_error(code: str, status: int):
        return jsonify(ok=False, error=code), status

    @app.errorhandler(400)
    def bad_request(_e):
        if _wants_json():
            return api_error("bad_request", 400)
        return _simple_page("The request was not valid. Go back and try again.", 400)

    @app.errorhandler(CSRFError)
    def csrf_failed(_e):
        if _wants_json():
            return api_error("csrf_failed", 400)
        return _simple_page("Your session expired. Go back, refresh the page and try again.",
                            400)

    @app.errorhandler(403)
    def forbidden(_e):
        if _wants_json():
            return api_error("forbidden", 403)
        return _not_found_page()

    @app.errorhandler(404)
    def not_found(_e):
        if _wants_json():
            return api_error("not_found", 404)
        return _not_found_page()

    @app.errorhandler(405)
    def method_not_allowed(_e):
        if _wants_json():
            return api_error("method_not_allowed", 405)
        return _not_found_page()

    @app.errorhandler(413)
    def too_large(_e):
        if _wants_json() or request.path.startswith("/api/"):
            return api_error("file_too_large", 413)
        return _simple_page("That file is too large.", 413)

    @app.errorhandler(429)
    def too_many(_e):
        if _wants_json():
            return api_error("too_many_requests", 429)
        return _simple_page("Too many attempts. Please wait a few minutes and try again.", 429)

    @app.errorhandler(500)
    def server_error(_e):
        if _wants_json():
            return api_error("server_error", 500)
        return _simple_page("Something went wrong on our side. Please try again.", 500)
