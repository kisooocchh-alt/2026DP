"""Tutor finding: search, filters, detail pages and ratings: /api/tutors..."""
from flask import Blueprint, g, request
from sqlalchemy import func, or_

from .. import constants as C
from ..extensions import db
from ..models.booking import BookingRequest
from ..models.rating import TutorRating
from ..models.subject import Subject
from ..models.user import TutorProfile, User
from ..security import ip_tracker
from ..security import validators as V
from ..security.decorators import role_required
from ..services import moderation_service, privacy_service
from ..utils.pagination import paginate
from ..utils.responses import error, json_body, ok

bp = Blueprint("tutors", __name__, url_prefix="/api/tutors")

SORTS = {
    "rating": (TutorProfile.is_verified.desc(), TutorProfile.rating_avg.desc(),
               TutorProfile.rating_count.desc(), User.id.desc()),
    "wage_low": (TutorProfile.hourly_wage.is_(None), TutorProfile.hourly_wage.asc(),
                 User.id.desc()),
    "wage_high": (TutorProfile.hourly_wage.desc(), User.id.desc()),
    "newest": (User.id.desc(),),
}


def _active_tutor():
    return (User.role == "tutor", User.is_deleted.is_(False), User.is_blocked.is_(False),
            User.is_shadow_banned.is_(False))


@bp.get("")
def search():
    args = request.args
    stmt = db.select(User).join(TutorProfile, TutorProfile.user_id == User.id) \
        .where(*_active_tutor())
    subject = (args.get("subject") or "").upper()
    if subject in C.SUBJECT_CODES:
        stmt = stmt.where(User.subjects.any(Subject.code == subject))
    for key, op in (("min_wage", "ge"), ("max_wage", "le")):
        try:
            value = int(args.get(key, ""))
        except ValueError:
            continue
        stmt = stmt.where(TutorProfile.hourly_wage >= value if op == "ge"
                          else TutorProfile.hourly_wage <= value)
    if args.get("gender") in C.GENDERS:
        stmt = stmt.where(User.gender == args["gender"])
    if args.get("verified_only") in ("1", "true"):
        stmt = stmt.where(TutorProfile.is_verified.is_(True))
    q = V.clean_text(args.get("q"), 40)
    if q:
        stmt = stmt.where(or_(User.username.contains(q, autoescape=True),
                              User.display_name.contains(q, autoescape=True),
                              TutorProfile.short_description.contains(q, autoescape=True)))
    stmt = stmt.order_by(*SORTS.get(args.get("sort"), SORTS["rating"]))
    viewer = g.user
    return ok(paginate(stmt, lambda u: privacy_service.tutor_card(u, viewer), per_page=12))


@bp.get("/<int:tutor_id>")
def detail(tutor_id: int):
    tutor = db.session.get(User, tutor_id)
    if tutor is None or tutor.role != "tutor" or tutor.is_deleted or tutor.is_blocked:
        return error("not_found", 404)
    ratings = db.session.execute(
        db.select(TutorRating).where(TutorRating.tutor_id == tutor.id)
        .order_by(TutorRating.id.desc()).limit(20)).scalars().all()
    my_bookings = []
    if g.user is not None and g.user.role == "student":
        my_bookings = [b.to_dict(g.user.id) for b in db.session.execute(
            db.select(BookingRequest).where(BookingRequest.student_id == g.user.id,
                                            BookingRequest.tutor_id == tutor.id)
            .order_by(BookingRequest.id.desc())).scalars()]
    return ok({"tutor": privacy_service.public_profile(tutor, g.user),
               "ratings": [r.to_dict() for r in ratings], "my_bookings": my_bookings})


@bp.post("/<int:tutor_id>/ratings")
@role_required("student")
def rate(tutor_id: int):
    form = V.Form(json_body())
    booking_id = form.field("booking_id", V.integer, min_value=1, code="booking_invalid")
    stars = form.field("stars", V.integer, min_value=1, max_value=5, code="stars_invalid")
    comment = form.field("comment", V.text, max_len=C.RATING_COMMENT_MAX, multiline=True)
    if comment and moderation_service.contains_banned_words(comment):
        form.errors["comment"] = "blocked_words"
    if form.errors:
        return error("validation_failed", 400, fields=form.errors)
    booking = db.session.get(BookingRequest, booking_id)
    if booking is None or booking.student_id != g.user.id or booking.tutor_id != tutor_id:
        return error("not_found", 404)
    if booking.status != "completed":
        return error("booking_not_completed", 409)
    if booking.rating is not None:
        return error("already_rated", 409)
    db.session.add(TutorRating(booking_id=booking.id, student_id=g.user.id, tutor_id=tutor_id,
                               stars=stars, comment=comment or None))
    db.session.flush()
    avg, count = db.session.execute(
        db.select(func.avg(TutorRating.stars), func.count(TutorRating.id))
        .where(TutorRating.tutor_id == tutor_id)).one()
    tp = db.session.get(TutorProfile, tutor_id)
    tp.rating_avg, tp.rating_count = float(avg or 0), int(count or 0)
    db.session.commit()
    ip_tracker.log_activity("tutor.rate", user_id=g.user.id,
                            meta={"tutor_id": tutor_id, "stars": stars})
    return ok({"rating_avg": round(tp.rating_avg, 2), "rating_count": tp.rating_count}, 201)
