"""Common-user authentication: /api/auth/..."""
from flask import Blueprint, g, session
from flask_wtf.csrf import generate_csrf

from ..extensions import limiter
from ..security import rate_limits
from ..security.decorators import login_required
from ..security.sessions import (end_session, list_user_sessions, revoke_all_user_sessions,
                                 revoke_user_session, start_user_session)
from ..security.validators import ValidationError
from ..services import auth_service, captcha_service
from ..utils.responses import error, json_body, ok

bp = Blueprint("auth", __name__, url_prefix="/api/auth")


@bp.get("/csrf")
def csrf_token():
    return ok({"csrf_token": generate_csrf()})


@bp.get("/captcha-key")
def captcha_key():
    return ok({"enabled": captcha_service.is_enabled(), "site_key": captcha_service.site_key()})


@bp.post("/register")
@limiter.limit(rate_limits.REGISTER)
def register():
    data = json_body()
    if not captcha_service.verify(data.get("captcha_token")):
        return error("captcha_failed", 400)
    try:
        user = auth_service.register_user(data)            # validates every field
    except ValidationError as e:
        return error(e.code, 400, fields=e.fields)
    except auth_service.AuthError as e:
        return error(e.code, e.status)
    return start_user_session(user, ok({"user": user.to_private_dict()}, status=201))


@bp.post("/login")
@limiter.limit(rate_limits.LOGIN)
def login():
    data = json_body()
    result = auth_service.authenticate(
        str(data.get("username", "")), str(data.get("password", "")),
        totp_code=data.get("totp_code"), captcha_token=data.get("captcha_token"))
    if not result.user:
        # same answer for unknown user and wrong password
        return error(result.error_code, 400, captcha_required=result.captcha_required)
    session.clear()                                  # fresh CSRF token after login
    return start_user_session(result.user, ok({"user": result.user.to_private_dict()}))


@bp.post("/logout")
def logout():
    session.clear()
    return end_session(ok())


@bp.get("/me")
def me():
    """Who is logged in. Guests get user: null (not 401), so every public page can ask
    without filling the browser console with errors."""
    return ok({"user": g.user.to_private_dict() if g.user is not None else None})


@bp.post("/password")
@login_required
@limiter.limit(rate_limits.PASSWORD_CHANGE, key_func=rate_limits.user_key)
def change_password():
    data = json_body()
    try:
        auth_service.change_password(g.user, str(data.get("old_password", "")),
                                     str(data.get("new_password", "")), g.user_session_id)
    except ValidationError as e:
        return error(e.code, 400, fields=e.fields)
    return ok()


# ---------------------------------------------------------------- two-factor
@bp.post("/2fa/setup")
@login_required
@limiter.limit(rate_limits.TWO_FACTOR, key_func=rate_limits.user_key)
def two_factor_setup():
    try:
        data = auth_service.begin_2fa_setup(g.user)
    except auth_service.AuthError as e:
        return error(e.code, e.status)
    session["pending_totp"] = data["secret"]
    return ok(data)


@bp.post("/2fa/enable")
@login_required
@limiter.limit(rate_limits.TWO_FACTOR, key_func=rate_limits.user_key)
def two_factor_enable():
    try:
        codes = auth_service.enable_2fa(g.user, session.get("pending_totp"),
                                        str(json_body().get("code", "")))
    except auth_service.AuthError as e:
        return error(e.code, e.status)
    session.pop("pending_totp", None)
    return ok({"recovery_codes": codes})


@bp.post("/2fa/disable")
@login_required
@limiter.limit(rate_limits.TWO_FACTOR, key_func=rate_limits.user_key)
def two_factor_disable():
    data = json_body()
    try:
        auth_service.disable_2fa(g.user, str(data.get("password", "")),
                                 str(data.get("code", "")))
    except auth_service.AuthError as e:
        return error(e.code, e.status)
    return ok()


@bp.post("/2fa/recovery-codes")
@login_required
@limiter.limit(rate_limits.TWO_FACTOR, key_func=rate_limits.user_key)
def two_factor_recovery_codes():
    try:
        codes = auth_service.regenerate_recovery_codes(g.user, str(json_body().get("code", "")))
    except auth_service.AuthError as e:
        return error(e.code, e.status)
    return ok({"recovery_codes": codes})


# ---------------------------------------------------------------- sessions
@bp.get("/sessions")
@login_required
def sessions():
    rows = list_user_sessions(g.user.id)
    return ok({"sessions": [s.to_dict(g.user_session_id) for s in rows]})


@bp.delete("/sessions/<int:session_id>")
@login_required
def end_one_session(session_id: int):
    if not revoke_user_session(g.user.id, session_id):
        return error("not_found", 404)
    return ok()


@bp.post("/sessions/revoke-others")
@login_required
def end_other_sessions():
    count = revoke_all_user_sessions(g.user.id, except_id=g.user_session_id)
    return ok({"ended": count})
