"""Save and remove bookmarks for past papers and materials: /api/bookmarks..."""
from flask import Blueprint, g
from sqlalchemy.exc import IntegrityError

from ..extensions import db
from ..models.bookmark import Bookmark
from ..models.material import Material
from ..models.past_paper import PastPaper
from ..security.decorators import login_required
from ..utils.responses import error, json_body, ok

bp = Blueprint("bookmarks", __name__, url_prefix="/api/bookmarks")
ITEM_TYPES = {"paper": PastPaper, "material": Material}


def _describe(b: Bookmark) -> dict | None:
    item = db.session.get(ITEM_TYPES[b.item_type], b.item_id)
    if item is None:
        return None
    if b.item_type == "paper":
        return {"id": b.id, "item_type": "paper", "item_id": item.id,
                "title": f"{item.subject_code} {item.year} {item.paper}",
                "subject": item.subject_code, "language": item.language,
                "link": f"/papers?subject={item.subject_code}&year={item.year}"}
    if not item.is_published:
        return None
    return {"id": b.id, "item_type": "material", "item_id": item.id, "title": item.title,
            "subject": item.subject_code, "language": item.language,
            "link": f"/material?id={item.id}"}


@bp.get("")
@login_required
def list_bookmarks():
    rows = db.session.execute(
        db.select(Bookmark).where(Bookmark.user_id == g.user.id).order_by(Bookmark.id.desc())
    ).scalars()
    items = [d for d in (_describe(b) for b in rows) if d]
    return ok({"items": items})


@bp.post("")
@login_required
def add():
    data = json_body()
    item_type = data.get("item_type")
    try:
        item_id = int(data.get("item_id"))
    except (TypeError, ValueError):
        return error("bad_request", 400)
    if item_type not in ITEM_TYPES or db.session.get(ITEM_TYPES[item_type], item_id) is None:
        return error("not_found", 404)
    bookmark = Bookmark(user_id=g.user.id, item_type=item_type, item_id=item_id)
    db.session.add(bookmark)
    try:
        db.session.commit()
    except IntegrityError:                           # already bookmarked
        db.session.rollback()
        bookmark = db.session.execute(
            db.select(Bookmark).where(Bookmark.user_id == g.user.id,
                                      Bookmark.item_type == item_type,
                                      Bookmark.item_id == item_id)).scalar_one()
    return ok({"bookmark_id": bookmark.id}, 201)


@bp.delete("/<int:bookmark_id>")
@login_required
def remove(bookmark_id: int):
    bookmark = db.session.get(Bookmark, bookmark_id)
    if bookmark is None or bookmark.user_id != g.user.id:
        return error("not_found", 404)
    db.session.delete(bookmark)
    db.session.commit()
    return ok()
