"""Lets users report a message or a profile: /api/reports"""
from flask import Blueprint, g
from sqlalchemy.exc import IntegrityError

from .. import constants as C
from ..extensions import db, limiter
from ..models.chat import Message
from ..models.report import Report
from ..models.user import User
from ..security import ip_tracker, rate_limits
from ..security import validators as V
from ..security.decorators import login_required
from ..services import moderation_service
from ..utils.responses import error, json_body, ok

bp = Blueprint("reports", __name__, url_prefix="/api/reports")


@bp.post("")
@login_required
@limiter.limit(rate_limits.REPORT, key_func=rate_limits.user_key)
def create():
    form = V.Form(json_body())
    target_type = form.field("target_type", V.choice, C.REPORT_TARGETS, code="target_invalid")
    target_id = form.field("target_id", V.integer, min_value=1, code="target_invalid")
    reason = form.field("reason", V.choice, C.REPORT_REASONS, code="reason_invalid")
    details = form.field("details", V.text, max_len=C.REPORT_DETAILS_MAX, multiline=True)
    if form.errors:
        return error("validation_failed", 400, fields=form.errors)
    model = Message if target_type == "message" else User
    target = db.session.get(model, target_id)
    if target is None:
        return error("not_found", 404)
    owner_id = target.user_id if target_type == "message" else target.id
    if owner_id == g.user.id:
        return error("cannot_report_self", 400)
    report = Report(reporter_id=g.user.id, target_type=target_type, target_id=target_id,
                    reason=reason, details=details or None)
    db.session.add(report)
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        return error("already_reported", 409)
    ip_tracker.log_activity("report.create", user_id=g.user.id,
                            meta={"target_type": target_type, "target_id": target_id})
    moderation_service.handle_new_report(report)
    return ok({"report_id": report.id}, 201)
