"""Clean page addresses: /login sends frontend/pages/login.html, and so on.

The pages are public files; the private data inside them is loaded from the API,
which checks the login. Never build a file path from user input - only names in
PAGES can be served here.
"""
from flask import Blueprint, current_app, send_from_directory
from sqlalchemy import text

from ..extensions import db

bp = Blueprint("pages", __name__)

PAGES = {
    "/": "index.html",
    "/login": "pages/login.html",
    "/register": "pages/register.html",
    "/dashboard": "pages/dashboard.html",
    "/profile": "pages/profile.html",
    "/profile/edit": "pages/profile-edit.html",
    "/settings": "pages/settings.html",
    "/tutors": "pages/tutors.html",
    "/tutor": "pages/tutor-detail.html",
    "/bookings": "pages/bookings.html",
    "/papers": "pages/papers.html",
    "/materials": "pages/materials.html",
    "/material": "pages/material-view.html",
    "/chat": "pages/chat.html",
    "/quizzes": "pages/quiz-list.html",
    "/quiz-take": "pages/quiz-take.html",
    "/quiz-result": "pages/quiz-result.html",
    "/notifications": "pages/notifications.html",
    "/terms": "pages/terms.html",
    "/privacy": "pages/privacy.html",
}


def _make_view(file_name: str):
    def view():
        response = send_from_directory(current_app.static_folder, file_name)
        response.headers["Cache-Control"] = "no-cache"
        return response
    return view


for _url, _file in PAGES.items():
    _endpoint = "home" if _url == "/" else _url.strip("/").replace("/", "_").replace("-", "_")
    bp.add_url_rule(_url, _endpoint, _make_view(_file))


@bp.get("/api/health")
def health():
    """Used by Docker and uptime monitors. Fails (500) if the database cannot be reached."""
    db.session.execute(text("SELECT 1"))
    return {"ok": True}, 200, {"Cache-Control": "no-store"}
