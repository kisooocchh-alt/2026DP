"""Fixed values and rules for DSEE5. Change numbers here only.

User-facing limits are mirrored in frontend/js/core/config.js so the browser can
warn early - the server always checks again.
"""
import json
from pathlib import Path

_DATA = Path(__file__).parent / "data"
SUBJECTS: list[dict] = json.loads((_DATA / "subjects.json").read_text(encoding="utf-8"))
SUBJECT_CODES = frozenset(s["code"] for s in SUBJECTS)
SUBJECT_BY_CODE = {s["code"]: s for s in SUBJECTS}

ROLES = ("student", "tutor")
GENDERS = ("male", "female", "other", "prefer_not_to_say")
LANGUAGES = ("en", "zh-HK")
DSE_GRADES = ("5**", "5*", "5", "4", "3", "2", "1", "U", "Attained", "Not Attained")
QUIZ_LEVELS = ("foundation", "standard", "advanced")    # about Level 2-3 / 4 / 5-5**
ASSESSMENT_KINDS = ("quiz", "test", "exam")
QUESTION_TYPES = ("mcq", "short")
VISIBILITY = ("everyone", "members", "nobody")
REPORT_REASONS = ("spam", "harassment", "inappropriate_image", "personal_info",
                  "cheating", "other")
REPORT_TARGETS = ("message", "user")
REPORT_ACTIONS = ("delete_message", "warn", "mute", "block", "dismiss")
BOOKING_STATUSES = ("pending", "accepted", "declined", "cancelled", "completed")
MATERIAL_KINDS = ("pdf", "image", "video_link", "note")
CONTENT_LANGUAGES = ("en", "zh")
DSE_EVENT_KINDS = ("exam", "results", "registration", "other")
NOTIFICATION_KINDS = ("mention", "booking", "countdown", "material", "system")
ALLOWED_VIDEO_HOSTS = ("youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be",
                       "vimeo.com", "player.vimeo.com")

# ---- Scoring economy (see docs/SCORING.md) ----
SIGNUP_BONUS = 20                 # new users can post a few messages straight away
DAILY_BASE = 10
DAILY_STREAK_STEP = 2             # +2 for each extra consecutive day
DAILY_STREAK_MAX_BONUS = 10       # so the biggest daily reward is 20
ASSESSMENT_RULES = {              # defaults; admin can override per assessment
    "quiz": {"questions": 10, "minutes": 15, "base": 5, "bonus_max": 10},
    "test": {"questions": 25, "minutes": 40, "base": 15, "bonus_max": 15},
    "exam": {"questions": 45, "minutes": 75, "base": 30, "bonus_max": 30},
}
REWARDED_ATTEMPTS_PER_DAY = 5     # later attempts that day give 0 points
ASSESSMENT_POINTS_DAILY_CAP = 120
MIN_TIME_FRACTION = 0.2           # rushing (<20% of time AND <50% correct) gives 0 points
RUSH_MAX_ACCURACY = 0.5
MESSAGE_COST_TEXT = 2
MESSAGE_COST_IMAGE = 5
REMOVED_MESSAGE_PENALTY = 10      # taken when admin removes a message for breaking rules

# ---- Limits ----
USERNAME_PATTERN = r"^[A-Za-z0-9_]{3,20}$"
RESERVED_USERNAMES = frozenset({"admin", "administrator", "root", "system", "dsee5",
                                "moderator", "support", "staff", "hkeaa"})
DISPLAY_NAME_MAX = 40
BIO_MAX = 500
CONTACT_MAX = 120
SCHOOL_MAX = 120
DSE_GOAL_MAX = 120
SHORT_DESCRIPTION_MAX = 200
BOOKING_MESSAGE_MAX = 600
REPORT_DETAILS_MAX = 500
RATING_COMMENT_MAX = 500
MAX_MESSAGE_LENGTH = 1000
MAX_SUBJECTS_PER_USER = 12
MIN_WAGE = 50                     # HKD per hour
MAX_WAGE = 2000
MAX_IMAGE_MB = 5
MAX_PDF_MB = 30
MAX_CSV_MB = 2
ALLOWED_IMAGE_TYPES = frozenset({"image/jpeg", "image/png", "image/webp"})
ALLOWED_DOC_TYPES = frozenset({"application/pdf"})
REPORTS_TO_AUTO_HIDE = 3
MENTIONS_PER_MESSAGE = 3
CHAT_PAGE_SIZE = 50
LOG_RETENTION_DAYS = 180
BACKUP_KEEP_DAYS = 14
MINOR_AGE = 18
QUIZ_GRACE_SECONDS = 30           # network delay allowed after the timer ends
COUNTDOWN_ALERT_DAYS = (100, 30, 7, 1)
