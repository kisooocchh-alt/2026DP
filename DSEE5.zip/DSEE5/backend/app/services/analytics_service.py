"""Numbers for the admin dashboard and the security (IP tracking) page."""
import threading
import time
from datetime import timedelta

from sqlalchemy import distinct, func

from ..extensions import db
from ..models.chat import Message
from ..models.past_paper import PastPaper
from ..models.quiz import Assessment, Attempt
from ..models.report import Report
from ..models.security_log import ActivityLog, BlockedIP
from ..models.user import TutorProfile, User
from ..utils.time_utils import to_hk, utcnow

_CACHE_SECONDS = 300
_cache_lock = threading.Lock()
_cache: dict = {"at": 0.0, "data": None}


def _scalar(stmt) -> int:
    return db.session.execute(stmt).scalar_one() or 0


def summary(force: bool = False) -> dict:
    """Dashboard numbers, cached for 5 minutes so the page stays fast."""
    with _cache_lock:
        if not force and _cache["data"] and time.monotonic() - _cache["at"] < _CACHE_SECONDS:
            return _cache["data"]
    now = utcnow()
    week = now - timedelta(days=7)
    day = now - timedelta(days=1)
    active_users = User.is_deleted.is_(False)
    data = {
        "students": _scalar(db.select(func.count(User.id)).where(active_users,
                                                                 User.role == "student")),
        "tutors": _scalar(db.select(func.count(User.id)).where(active_users,
                                                               User.role == "tutor")),
        "new_users_7d": _scalar(db.select(func.count(User.id)).where(User.created_at >= week)),
        "daily_active": _scalar(db.select(func.count(distinct(ActivityLog.user_id)))
                                .where(ActivityLog.created_at >= day,
                                       ActivityLog.user_id.is_not(None))),
        "messages_7d": _scalar(db.select(func.count(Message.id))
                               .where(Message.created_at >= week)),
        "attempts_7d": _scalar(db.select(func.count(Attempt.id))
                               .where(Attempt.started_at >= week)),
        "open_reports": _scalar(db.select(func.count(Report.id)).where(Report.status == "open")),
        "blocked_ips": len(BlockedIP.active_ips()),
        "unverified_tutors": _scalar(
            db.select(func.count(TutorProfile.user_id))
            .where(TutorProfile.certificate_file.is_not(None),
                   TutorProfile.is_verified.is_(False))),
        "messages_by_subject": [
            {"subject": s, "count": c} for s, c in db.session.execute(
                db.select(Message.subject_code, func.count(Message.id))
                .where(Message.created_at >= week).group_by(Message.subject_code)
                .order_by(func.count(Message.id).desc()).limit(12)).all()],
        "attempts_by_subject": [
            {"subject": s, "count": c} for s, c in db.session.execute(
                db.select(Assessment.subject_code, func.count(Attempt.id))
                .join(Assessment, Attempt.assessment_id == Assessment.id)
                .where(Attempt.started_at >= week)
                .group_by(Assessment.subject_code)
                .order_by(func.count(Attempt.id).desc()).limit(12)).all()],
        "top_papers": [p.to_dict() for p in db.session.execute(
            db.select(PastPaper).order_by(PastPaper.download_count.desc()).limit(10)
        ).scalars()],
        "high_priority": [{**a.to_dict(), "when_hk": to_hk(a.created_at).strftime("%Y-%m-%d %H:%M")}
                          for a in db.session.execute(
            db.select(ActivityLog).where(
                ActivityLog.action.in_(("admin.login", "security.ip_blocked",
                                        "security.auto_mute")),
                ActivityLog.success.is_(False), ActivityLog.created_at >= week)
            .order_by(ActivityLog.id.desc()).limit(10)).scalars()],
        "generated_hk": to_hk(now).strftime("%Y-%m-%d %H:%M"),
    }
    with _cache_lock:
        _cache.update(at=time.monotonic(), data=data)
    return data


def security_overview() -> dict:
    now = utcnow()
    day = now - timedelta(days=1)
    hour = now - timedelta(hours=1)
    month = now - timedelta(days=30)
    logins = db.session.execute(
        db.select(ActivityLog).where(ActivityLog.action == "auth.login")
        .order_by(ActivityLog.id.desc()).limit(50)).scalars().all()
    failed_by_ip = db.session.execute(
        db.select(ActivityLog.ip, func.count(ActivityLog.id).label("n"),
                  func.max(ActivityLog.country))
        .where(ActivityLog.action == "auth.login", ActivityLog.success.is_(False),
               ActivityLog.created_at >= day)
        .group_by(ActivityLog.ip).order_by(func.count(ActivityLog.id).desc()).limit(20)).all()
    shared_ips = db.session.execute(
        db.select(ActivityLog.ip, func.count(distinct(ActivityLog.user_id)).label("n"))
        .where(ActivityLog.action.in_(("auth.login", "auth.register")),
               ActivityLog.success.is_(True), ActivityLog.user_id.is_not(None),
               ActivityLog.created_at >= month)
        .group_by(ActivityLog.ip).having(func.count(distinct(ActivityLog.user_id)) > 1)
        .order_by(func.count(distinct(ActivityLog.user_id)).desc()).limit(20)).all()
    shared_devices = db.session.execute(
        db.select(ActivityLog.device_id, func.count(distinct(ActivityLog.user_id)).label("n"))
        .where(ActivityLog.action.in_(("auth.login", "auth.register")),
               ActivityLog.success.is_(True), ActivityLog.user_id.is_not(None),
               ActivityLog.device_id.is_not(None), ActivityLog.created_at >= month)
        .group_by(ActivityLog.device_id).having(func.count(distinct(ActivityLog.user_id)) > 1)
        .order_by(func.count(distinct(ActivityLog.user_id)).desc()).limit(20)).all()
    spikes = db.session.execute(
        db.select(ActivityLog.ip, func.count(ActivityLog.id).label("n"))
        .where(ActivityLog.created_at >= hour)
        .group_by(ActivityLog.ip).having(func.count(ActivityLog.id) >= 30)
        .order_by(func.count(ActivityLog.id).desc()).limit(20)).all()
    blocked = db.session.execute(
        db.select(BlockedIP).order_by(BlockedIP.created_at.desc()).limit(100)).scalars().all()
    admin_logins = db.session.execute(
        db.select(ActivityLog).where(ActivityLog.action == "admin.login")
        .order_by(ActivityLog.id.desc()).limit(30)).scalars().all()
    usernames = _usernames({a.user_id for a in logins if a.user_id})
    return {
        "logins": [{**a.to_dict(), "username": usernames.get(a.user_id) or
                    (a.meta or {}).get("username")} for a in logins],
        "failed_by_ip": [{"ip": ip, "count": n, "country": c} for ip, n, c in failed_by_ip],
        "shared_ips": [{"ip": ip, "accounts": n} for ip, n in shared_ips],
        "shared_devices": [{"device_id": d, "accounts": n} for d, n in shared_devices],
        "spikes": [{"ip": ip, "count": n} for ip, n in spikes],
        "blocked": [b.to_dict() for b in blocked],
        "admin_logins": [a.to_dict() for a in admin_logins],
    }


def related_accounts(user: User) -> list[dict]:
    """Other accounts seen from the same IPs or devices as this user (last 90 days)."""
    since = utcnow() - timedelta(days=90)
    mine = db.session.execute(
        db.select(ActivityLog.ip, ActivityLog.device_id)
        .where(ActivityLog.user_id == user.id, ActivityLog.created_at >= since).distinct()
    ).all()
    ips = {ip for ip, _ in mine if ip}
    devices = {d for _, d in mine if d}
    if not ips and not devices:
        return []
    cond = ActivityLog.ip.in_(ips)
    if devices:
        cond = cond | ActivityLog.device_id.in_(devices)
    others = db.session.execute(
        db.select(distinct(ActivityLog.user_id))
        .where(cond, ActivityLog.user_id.is_not(None), ActivityLog.user_id != user.id,
               ActivityLog.created_at >= since)
    ).scalars().all()
    users = db.session.execute(db.select(User).where(User.id.in_(others))).scalars().all()
    return [{"id": u.id, "username": u.username, "role": u.role, "blocked": u.is_blocked}
            for u in users]


def _usernames(ids: set[int]) -> dict[int, str]:
    if not ids:
        return {}
    rows = db.session.execute(db.select(User.id, User.username).where(User.id.in_(ids))).all()
    return dict(rows)
