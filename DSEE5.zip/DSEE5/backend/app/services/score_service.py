"""Earning and spending points. All point changes go through this file so every change
is recorded in score_transactions. All numbers come from constants.py."""
from datetime import timedelta

from sqlalchemy import case, func, update
from sqlalchemy.exc import IntegrityError

from .. import constants as C
from ..extensions import db
from ..models.quiz import Attempt
from ..models.score import DailyClaim, ScoreTransaction
from ..models.user import User
from ..utils.time_utils import hk_day_start_utc, hk_today, seconds_between

ASSESSMENT_REASONS = ("quiz", "test", "exam")


class NotEnoughPoints(Exception):
    pass


class AlreadyClaimed(Exception):
    pass


def spend_points(user_id: int, cost: int, reason: str, ref_id: int | None = None,
                 note: str | None = None) -> None:
    """Take points in ONE database statement, so two quick requests can never spend
    the same points twice. The caller must commit (or roll back)."""
    result = db.session.execute(
        update(User).where(User.id == user_id, User.score >= cost)
        .values(score=User.score - cost)
    )
    if result.rowcount == 0:
        raise NotEnoughPoints()
    db.session.add(ScoreTransaction(user_id=user_id, amount=-cost, reason=reason, ref_id=ref_id,
                                    note=note))


def add_points(user_id: int, amount: int, reason: str, ref_id: int | None = None,
               note: str | None = None) -> None:
    """Add points. The caller must commit."""
    if amount <= 0:
        return
    db.session.execute(
        update(User).where(User.id == user_id)
        .values(score=User.score + amount, lifetime_points=User.lifetime_points + amount)
    )
    db.session.add(ScoreTransaction(user_id=user_id, amount=amount, reason=reason, ref_id=ref_id,
                                    note=note))


def take_points(user_id: int, amount: int, reason: str, note: str | None = None,
                ref_id: int | None = None) -> int:
    """Remove up to `amount` points (balance never goes below 0). Returns points taken.
    The caller must commit."""
    current = db.session.execute(db.select(User.score).where(User.id == user_id)).scalar_one()
    taken = max(0, min(amount, current))
    if taken:
        db.session.execute(
            update(User).where(User.id == user_id)
            .values(score=case((User.score >= taken, User.score - taken), else_=0))
        )
        db.session.add(ScoreTransaction(user_id=user_id, amount=-taken, reason=reason,
                                        ref_id=ref_id, note=note))
    return taken


def daily_amount_for_streak(streak: int) -> int:
    return C.DAILY_BASE + min(max(streak - 1, 0) * C.DAILY_STREAK_STEP, C.DAILY_STREAK_MAX_BONUS)


def _streak_if_claimed_today(user: User) -> int:
    yesterday = hk_today() - timedelta(days=1)
    return user.login_streak + 1 if user.last_daily_claim == yesterday else 1


def claimed_today(user: User) -> bool:
    return user.last_daily_claim == hk_today()


def claim_daily_reward(user: User) -> dict:
    today = hk_today()
    if user.last_daily_claim == today:
        raise AlreadyClaimed()
    streak = _streak_if_claimed_today(user)
    amount = daily_amount_for_streak(streak)
    try:
        db.session.add(DailyClaim(user_id=user.id, claim_date=today, amount=amount))
        db.session.flush()            # unique (user_id, claim_date) blocks a second claim
    except IntegrityError:
        db.session.rollback()
        raise AlreadyClaimed() from None
    user.login_streak = streak
    user.last_daily_claim = today
    add_points(user.id, amount, reason="daily_reward")
    db.session.commit()
    db.session.refresh(user)
    return {"amount": amount, "streak": streak, "score": user.score,
            "tomorrow": daily_amount_for_streak(streak + 1)}


def assessment_points_today(user_id: int) -> int:
    return db.session.execute(
        db.select(func.coalesce(func.sum(ScoreTransaction.amount), 0))
        .where(ScoreTransaction.user_id == user_id,
               ScoreTransaction.reason.in_(ASSESSMENT_REASONS),
               ScoreTransaction.created_at >= hk_day_start_utc())
    ).scalar_one()


def rewarded_attempts_today(user_id: int, exclude_id: int | None = None) -> int:
    stmt = db.select(func.count(Attempt.id)).where(
        Attempt.user_id == user_id, Attempt.points_awarded > 0,
        Attempt.submitted_at >= hk_day_start_utc())
    if exclude_id:
        stmt = stmt.where(Attempt.id != exclude_id)
    return db.session.execute(stmt).scalar_one()


def assessment_points(attempt: Attempt) -> tuple[int, str]:
    """Points for a finished attempt, and why. Rules in docs/SCORING.md."""
    a = attempt.assessment
    if attempt.max_score <= 0:
        return 0, "no_questions"
    accuracy = attempt.raw_score / attempt.max_score
    end = min(attempt.submitted_at, attempt.expires_at)
    time_used = seconds_between(attempt.started_at, end)
    if time_used < C.MIN_TIME_FRACTION * a.time_limit_min * 60 and \
            accuracy < C.RUSH_MAX_ACCURACY:
        return 0, "too_fast"
    already = db.session.execute(
        db.select(func.count(Attempt.id)).where(
            Attempt.user_id == attempt.user_id, Attempt.assessment_id == a.id,
            Attempt.id != attempt.id, Attempt.points_awarded > 0,
            Attempt.submitted_at >= hk_day_start_utc())
    ).scalar_one()
    if already:
        return 0, "already_rewarded_today"
    if rewarded_attempts_today(attempt.user_id, exclude_id=attempt.id) >= \
            C.REWARDED_ATTEMPTS_PER_DAY:
        return 0, "daily_attempt_limit"
    room = C.ASSESSMENT_POINTS_DAILY_CAP - assessment_points_today(attempt.user_id)
    if room <= 0:
        return 0, "daily_cap"
    points = a.points_base + round(a.points_bonus_max * accuracy)
    if points > room:
        return room, "daily_cap_partial"
    return points, "ok"


def admin_adjust(user_id: int, amount: int, note: str) -> int:
    """Admin changes a balance. Returns the actual change. The caller must commit."""
    if amount > 0:
        add_points(user_id, amount, reason="admin_adjust", note=note)
        return amount
    return -take_points(user_id, -amount, reason="admin_adjust", note=note)


def summary(user: User) -> dict:
    claimed = claimed_today(user)
    streak_now = user.login_streak if claimed else _streak_if_claimed_today(user)
    return {
        "score": user.score,
        "lifetime_points": user.lifetime_points,
        "login_streak": user.login_streak,
        "claimed_today": claimed,
        "daily_amount": daily_amount_for_streak(streak_now),
        "next_daily_amount": daily_amount_for_streak(streak_now + 1 if claimed else streak_now),
        "assessment_points_today": assessment_points_today(user.id),
        "assessment_daily_cap": C.ASSESSMENT_POINTS_DAILY_CAP,
        "rewarded_attempts_today": rewarded_attempts_today(user.id),
        "rewarded_attempts_cap": C.REWARDED_ATTEMPTS_PER_DAY,
        "costs": {"text": C.MESSAGE_COST_TEXT, "image": C.MESSAGE_COST_IMAGE},
    }


def history(user_id: int, limit: int = 50) -> list[dict]:
    rows = db.session.execute(
        db.select(ScoreTransaction).where(ScoreTransaction.user_id == user_id)
        .order_by(ScoreTransaction.id.desc()).limit(limit)
    ).scalars()
    return [r.to_dict() for r in rows]
