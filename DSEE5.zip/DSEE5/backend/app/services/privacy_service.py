"""Decides exactly which profile fields a viewer can see. All public profile output goes
through this file, so privacy rules are never forgotten.

- "everyone": anybody, even when logged out
- "members":  any logged-in user
- "nobody":   only the owner (and the admin)
Contact details are also shared with the other person once a booking is accepted.
Under-18 users can never show their age or contact to "everyone".
"""
from sqlalchemy import and_, or_

from ..extensions import db
from ..models.booking import BookingRequest
from ..models.user import User
from ..utils.time_utils import iso_utc


def can_see(owner: User, viewer: User | None, setting: str) -> bool:
    if viewer is not None and viewer.id == owner.id:
        return True
    if setting == "everyone":
        return True
    if setting == "members":
        return viewer is not None
    return False


def allowed_visibility(user: User, field: str, wanted: str) -> str:
    """Under-18 users cannot show age or contact to everyone."""
    if user.is_minor and field in ("age", "contact") and wanted == "everyone":
        return "members"
    return wanted


def has_accepted_booking(a: User, b: User) -> bool:
    if a is None or b is None:
        return False
    stmt = db.select(BookingRequest.id).where(
        BookingRequest.status.in_(("accepted", "completed")),
        or_(and_(BookingRequest.student_id == a.id, BookingRequest.tutor_id == b.id),
            and_(BookingRequest.student_id == b.id, BookingRequest.tutor_id == a.id)),
    ).limit(1)
    return db.session.execute(stmt).first() is not None


def public_profile(owner: User, viewer: User | None) -> dict:
    is_me = viewer is not None and viewer.id == owner.id
    data = {
        "id": owner.id, "username": owner.username, "display_name": owner.name,
        "role": owner.role, "avatar_url": owner.avatar_url, "gender": owner.gender,
        "bio": owner.bio or "", "score": owner.score,
        "subjects": [s.code for s in owner.subjects],
        "verified": owner.is_verified_tutor, "created_at": iso_utc(owner.created_at),
        "is_me": is_me,
    }
    if can_see(owner, viewer, owner.show_age):
        data["age"] = owner.age
    if can_see(owner, viewer, owner.show_contact) or has_accepted_booking(owner, viewer):
        data["contact"] = owner.contact or ""
    if owner.role == "student" and owner.student_profile:
        data["dse_goal"] = owner.student_profile.dse_goal
        data["exam_year"] = owner.student_profile.exam_year
        if can_see(owner, viewer, owner.show_school):
            data["school"] = owner.student_profile.school
    if owner.role == "tutor" and owner.tutor_profile:
        data["tutor"] = owner.tutor_profile.to_dict(include_private=is_me)
    return data


def tutor_card(owner: User, viewer: User | None) -> dict:
    """The smaller version used in the tutor search results."""
    tp = owner.tutor_profile
    card = {
        "id": owner.id, "username": owner.username, "display_name": owner.name,
        "avatar_url": owner.avatar_url, "gender": owner.gender,
        "subjects": [s.code for s in owner.subjects],
        "hourly_wage": tp.hourly_wage if tp else None,
        "short_description": (tp.short_description if tp else "") or "",
        "dse_results": (tp.dse_results if tp else []) or [],
        "verified": bool(tp and tp.is_verified),
        "rating_avg": round(tp.rating_avg or 0, 2) if tp else 0,
        "rating_count": tp.rating_count if tp else 0,
        "students_helped": tp.students_helped if tp else 0,
    }
    if can_see(owner, viewer, owner.show_age):
        card["age"] = owner.age
    return card
