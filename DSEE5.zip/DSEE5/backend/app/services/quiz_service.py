"""Runs quizzes, tests and exams fairly.

- The timer is enforced on the server: answers after the deadline (+30 s grace for
  network delay) are refused, and overdue attempts are submitted automatically.
- Correct answers are never sent to the browser before the attempt is submitted.
- MCQ options are shuffled per attempt.
"""
import math
import random
import unicodedata
from collections import OrderedDict
from datetime import timedelta
from fractions import Fraction

from .. import constants as C
from ..extensions import db
from ..models.quiz import Assessment, Attempt, AttemptQuestion, Question
from ..security import ip_tracker
from ..utils.time_utils import iso_utc, seconds_between, utcnow
from . import score_service

GRACE = timedelta(seconds=C.QUIZ_GRACE_SECONDS)
_DASHES = str.maketrans({"\u2212": "-", "\u2013": "-", "\u2014": "-", "\u00d7": "*"})


class QuizError(Exception):
    def __init__(self, code: str, status: int = 400, **extra):
        super().__init__(code)
        self.code = code
        self.status = status
        self.extra = extra


# ------------------------------------------------------------------ attempts
def current_attempt(user_id: int) -> Attempt | None:
    return db.session.execute(
        db.select(Attempt).where(Attempt.user_id == user_id, Attempt.status == "in_progress")
        .order_by(Attempt.id.desc())
    ).scalars().first()


def get_owned_attempt(user_id: int, attempt_id: int) -> Attempt:
    attempt = db.session.get(Attempt, attempt_id)
    if attempt is None or attempt.user_id != user_id:
        raise QuizError("not_found", 404)
    return attempt


def start_attempt(user, assessment: Assessment | None) -> Attempt:
    if assessment is None or not assessment.is_published:
        raise QuizError("not_found", 404)
    expire_overdue(user_id=user.id)
    existing = current_attempt(user.id)
    if existing is not None:
        raise QuizError("attempt_in_progress", 409, attempt_id=existing.id)
    pool = db.session.execute(
        db.select(Question).where(Question.bank_id == assessment.bank_id,
                                  Question.is_active.is_(True))
    ).scalars().all()
    if not pool:
        raise QuizError("no_questions")
    chosen = random.sample(pool, min(assessment.question_count, len(pool)))
    now = utcnow()
    attempt = Attempt(user_id=user.id, assessment_id=assessment.id, started_at=now,
                      expires_at=now + timedelta(minutes=assessment.time_limit_min),
                      max_score=sum(q.marks for q in chosen))
    for position, q in enumerate(chosen, start=1):
        order = None
        if q.qtype == "mcq":
            order = [o["id"] for o in (q.options or [])]
            random.shuffle(order)
        attempt.questions.append(AttemptQuestion(question_id=q.id, position=position,
                                                 option_order=order))
    db.session.add(attempt)
    db.session.commit()
    ip_tracker.log_activity("quiz.start", user_id=user.id,
                            meta={"attempt_id": attempt.id, "assessment_id": assessment.id})
    return attempt


def _question_view(aq: AttemptQuestion, *, reveal: bool) -> dict:
    q = aq.question
    options = []
    if q.qtype == "mcq":
        by_id = {o["id"]: o["text"] for o in (q.options or [])}
        options = [{"id": oid, "text": by_id[oid]} for oid in (aq.option_order or by_id)
                   if oid in by_id]
    data = {"id": aq.id, "position": aq.position, "topic": q.topic, "type": q.qtype,
            "prompt": q.prompt, "image_url": q.image_url, "marks": q.marks, "options": options,
            "answer": aq.answer}
    if reveal:
        data.update(correct_answer=q.answer.split("|")[0] if q.qtype == "short" else q.answer,
                    is_correct=bool(aq.is_correct), explanation=q.explanation or "")
    return data


def attempt_payload(attempt: Attempt) -> dict:
    """The in-progress view: questions WITHOUT correct answers."""
    data = attempt.summary_dict()
    data.update(time_limit_min=attempt.assessment.time_limit_min,
                server_now=iso_utc(utcnow()),
                questions=[_question_view(aq, reveal=False) for aq in attempt.questions])
    return data


def _clean_answer(aq: AttemptQuestion, value) -> str | None:
    if value is None:
        return None
    value = str(value).strip()[:300]
    if not value:
        return None
    if aq.question.qtype == "mcq":
        return value if value in (aq.option_order or []) else None
    return value


def _save(attempt: Attempt, answers: dict) -> int:
    by_id = {aq.id: aq for aq in attempt.questions}
    saved = 0
    for key, value in (answers or {}).items():
        try:
            aq = by_id.get(int(key))
        except (TypeError, ValueError):
            continue
        if aq is not None:
            aq.answer = _clean_answer(aq, value)
            saved += 1
    return saved


def save_answers(attempt: Attempt, answers: dict) -> int:
    if attempt.status != "in_progress":
        raise QuizError("attempt_closed", 409)
    if utcnow() > attempt.expires_at + GRACE:
        raise QuizError("time_up", 409)
    if not isinstance(answers, dict):
        raise QuizError("answers_invalid")
    saved = _save(attempt, answers)
    db.session.commit()
    return saved


# ------------------------------------------------------------------ marking
def _normalize(text: str) -> str:
    """Compare short answers without case, spaces, full-width characters or a final dot:
    "(x + 3)(x - 3)" matches "(x+3)(x-3)"."""
    text = unicodedata.normalize("NFKC", text).lower().strip().translate(_DASHES)
    return "".join(text.split()).rstrip(".")


def _as_number(text: str) -> float | None:
    cleaned = _normalize(text).replace(" ", "").replace(",", "")
    try:
        return float(Fraction(cleaned))
    except (ValueError, ZeroDivisionError):
        return None


def is_correct(question: Question, answer: str | None) -> bool:
    if not answer:
        return False
    if question.qtype == "mcq":
        return answer == question.answer
    given = _normalize(answer)
    given_num = _as_number(answer)
    for accepted in question.answer.split("|"):
        if given == _normalize(accepted):
            return True
        expected_num = _as_number(accepted)
        if given_num is not None and expected_num is not None and \
                math.isclose(given_num, expected_num, rel_tol=1e-3, abs_tol=1e-9):
            return True
    return False


def submit(attempt: Attempt, answers: dict | None = None, *, expired: bool = False) -> Attempt:
    if attempt.status != "in_progress":
        return attempt                                   # already submitted: idempotent
    now = utcnow()
    if answers and now <= attempt.expires_at + GRACE:
        _save(attempt, answers)
    raw = 0
    for aq in attempt.questions:
        aq.is_correct = is_correct(aq.question, aq.answer)
        aq.marks_awarded = aq.question.marks if aq.is_correct else 0
        raw += aq.marks_awarded
    attempt.raw_score = raw
    attempt.status = "expired" if expired else "submitted"
    attempt.submitted_at = now
    db.session.flush()
    points, reason = score_service.assessment_points(attempt)
    attempt.points_awarded, attempt.points_reason = points, reason
    if points:
        score_service.add_points(attempt.user_id, points, reason=attempt.assessment.kind,
                                 ref_id=attempt.id)
    db.session.commit()
    ip_tracker.log_activity("quiz.submit", user_id=attempt.user_id,
                            meta={"attempt_id": attempt.id, "score": raw,
                                  "max": attempt.max_score, "points": points})
    return attempt


def expire_overdue(user_id: int | None = None) -> int:
    """Submit attempts whose time ran out. Called by the scheduler every minute."""
    stmt = db.select(Attempt).where(Attempt.status == "in_progress",
                                    Attempt.expires_at < utcnow() - GRACE)
    if user_id is not None:
        stmt = stmt.where(Attempt.user_id == user_id)
    count = 0
    for attempt in db.session.execute(stmt).scalars().all():
        submit(attempt, expired=True)
        count += 1
    return count


# ------------------------------------------------------------------ results
def result_payload(attempt: Attempt) -> dict:
    if attempt.status == "in_progress":
        raise QuizError("attempt_not_finished", 409)
    topics: OrderedDict[str, dict] = OrderedDict()
    for aq in attempt.questions:
        t = topics.setdefault(aq.question.topic, {"topic": aq.question.topic, "correct": 0,
                                                  "total": 0})
        t["total"] += 1
        t["correct"] += 1 if aq.is_correct else 0
    end = min(attempt.submitted_at or utcnow(), attempt.expires_at)
    data = attempt.summary_dict()
    data.update(
        time_limit_min=attempt.assessment.time_limit_min,
        time_used_sec=seconds_between(attempt.started_at, end),
        points_reason=attempt.points_reason or "ok",
        topics=list(topics.values()),
        questions=[_question_view(aq, reveal=True) for aq in attempt.questions],
    )
    return data


def history(user_id: int, limit: int = 30) -> list[dict]:
    rows = db.session.execute(
        db.select(Attempt).where(Attempt.user_id == user_id, Attempt.status != "in_progress")
        .order_by(Attempt.id.desc()).limit(limit)
    ).scalars()
    return [a.summary_dict() for a in rows]


def best_scores(user_id: int) -> dict[int, dict]:
    rows = db.session.execute(
        db.select(Attempt).where(Attempt.user_id == user_id, Attempt.status != "in_progress")
    ).scalars()
    best: dict[int, dict] = {}
    for a in rows:
        entry = best.setdefault(a.assessment_id, {"best_percent": 0, "attempts": 0})
        entry["attempts"] += 1
        entry["best_percent"] = max(entry["best_percent"], a.percent)
    return best
