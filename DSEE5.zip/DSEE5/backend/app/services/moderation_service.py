"""Content filtering and the report system.

- Banned words: data/banned_words_en.txt (whole words / phrases) and
  data/banned_words_zh.txt (substrings, because Chinese has no spaces).
- Under-18 users cannot post phone numbers, emails or messaging handles in public chat.
- 3 reports from different users hide a message until the admin reviews it.
"""
import functools
import re
from datetime import timedelta
from pathlib import Path

from .. import constants as C
from ..extensions import db, socketio
from ..models.chat import Message
from ..models.report import Report
from ..models.user import User
from ..security.sessions import revoke_all_user_sessions
from ..utils.time_utils import utcnow
from . import notification_service

_DATA = Path(__file__).parents[1] / "data"
_LEET = str.maketrans({"0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t",
                       "@": "a", "$": "s", "!": "i"})
_WORD = re.compile(r"[a-z0-9']+")
_CONTACT_PATTERNS = [
    re.compile(r"[\w.+-]+@[\w-]+\.[\w.]{2,}", re.I),                       # email
    re.compile(r"\+?852[\s-]?[2-9]\d{3}[\s-]?\d{4}"),                       # +852 phone
    re.compile(r"(?<![\d.,])[2-9]\d{3}[\s-]\d{4}(?![\d.,])"),                # 9123 4567
    re.compile(r"(?:tel|phone|mobile|call me|whatsapp|電話|手機|聯絡)\D{0,8}\d{8}", re.I),
    re.compile(r"\b(?:whats\s?app|wechat|telegram|signal|instagram|snapchat|line\s?id|"
               r"discord)\b|\big\s*[:：@]", re.I),
]


class ModerationError(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


@functools.lru_cache(maxsize=1)
def _word_lists() -> tuple[frozenset, tuple, tuple]:
    def read(name):
        lines = (_DATA / name).read_text(encoding="utf-8").splitlines()
        return [ln.strip().lower() for ln in lines if ln.strip() and not ln.startswith("#")]
    en = read("banned_words_en.txt")
    zh = read("banned_words_zh.txt")
    words = frozenset(w for w in en if " " not in w)
    phrases = tuple(w for w in en if " " in w)
    return words, phrases, tuple(zh)


def contains_banned_words(text: str) -> bool:
    if not text:
        return False
    words, phrases, zh = _word_lists()
    lowered = text.lower()
    if any(term in lowered for term in zh):
        return True
    for candidate in {lowered, lowered.translate(_LEET)}:
        if any(w in words for w in _WORD.findall(candidate)):
            return True
        squashed = " ".join(_WORD.findall(candidate))
        if any(p in squashed for p in phrases):
            return True
    return False


def contains_contact_info(text: str) -> bool:
    return any(p.search(text or "") for p in _CONTACT_PATTERNS)


# ------------------------------------------------------------------ reports
def handle_new_report(report: Report) -> None:
    """Update counters and auto-hide a message after enough different reporters."""
    if report.target_type != "message":
        return
    msg = db.session.get(Message, report.target_id)
    if msg is None:
        return
    msg.report_count = db.session.execute(
        db.select(db.func.count(Report.id))
        .where(Report.target_type == "message", Report.target_id == msg.id,
               Report.status == "open")
    ).scalar_one()
    newly_hidden = msg.report_count >= C.REPORTS_TO_AUTO_HIDE and not msg.is_hidden
    if newly_hidden:
        msg.is_hidden = True
    db.session.commit()
    if newly_hidden:
        socketio.emit("message_hidden", {"id": msg.id}, to=msg.subject_code, namespace="/chat")


def report_target_user(report: Report) -> User | None:
    if report.target_type == "user":
        return db.session.get(User, report.target_id)
    msg = db.session.get(Message, report.target_id)
    return msg.user if msg else None


def warn_user(user: User, reason: str) -> None:
    notification_service.notify(
        user.id, "system",
        {"en": "A warning from the DSEE5 moderators", "zh-HK": "DSEE5 管理員的警告"},
        {"en": f"Please follow the community rules. Reason: {reason}",
         "zh-HK": f"請遵守社群守則。原因：{reason}"},
        "/terms")


def mute_user(user: User, minutes: int, reason: str) -> None:
    user.muted_until = utcnow() + timedelta(minutes=minutes)
    db.session.commit()
    notification_service.notify(
        user.id, "system",
        {"en": "You have been muted in chat", "zh-HK": "你已被禁止在討論區發言"},
        {"en": f"You can post again in {minutes} minutes. Reason: {reason}",
         "zh-HK": f"{minutes} 分鐘後可再發言。原因：{reason}"},
        "/terms")


def block_user(user: User, reason: str) -> None:
    user.is_blocked = True
    user.blocked_reason = reason[:200]
    db.session.commit()
    revoke_all_user_sessions(user.id)


def unblock_user(user: User) -> None:
    user.is_blocked = False
    user.blocked_reason = None
    user.failed_logins = 0
    user.locked_until = None
    db.session.commit()


def close_reports(target_type: str, target_id: int, admin_id: int, action: str) -> int:
    rows = db.session.execute(
        db.select(Report).where(Report.target_type == target_type, Report.target_id == target_id,
                                Report.status == "open")
    ).scalars().all()
    status = "dismissed" if action == "dismiss" else "actioned"
    for r in rows:
        r.status, r.action_taken, r.handled_by, r.handled_at = status, action, admin_id, utcnow()
    db.session.commit()
    return len(rows)


def action_report(report: Report, admin, action: str, reason: str,
                  minutes: int | None = None) -> dict:
    """Carry out the admin's decision and close every open report on the same target."""
    from . import chat_service  # local import avoids a cycle

    if action not in C.REPORT_ACTIONS:
        raise ModerationError("action_invalid")
    target_user = report_target_user(report)
    message = db.session.get(Message, report.target_id) if report.target_type == "message" \
        else None
    reason = reason or report.reason

    if action == "delete_message":
        if message is None:
            raise ModerationError("action_invalid")
        chat_service.delete_message(message, admin.id, reason, penalty=True)
    elif action == "warn" and target_user:
        warn_user(target_user, reason)
    elif action == "mute" and target_user:
        mute_user(target_user, minutes or 60 * 24, reason)
    elif action == "block" and target_user:
        block_user(target_user, reason)
        if message is not None and not message.is_deleted:
            chat_service.delete_message(message, admin.id, reason, penalty=False)
    elif action == "dismiss" and message is not None and message.is_hidden:
        message.is_hidden = False
        db.session.commit()
        socketio.emit("message_restored", message.to_dict(), to=message.subject_code,
                      namespace="/chat")
    closed = close_reports(report.target_type, report.target_id, admin.id, action)
    return {"closed": closed, "action": action}
