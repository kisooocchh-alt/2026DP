"""Anti-robot check with Cloudflare Turnstile.

The browser widget (frontend/js/components/captcha.js) gives a one-time token; the
server confirms it with Cloudflare here. Tokens can only be used once.
"""
import logging

import requests
from flask import current_app, has_request_context, request

VERIFY_URL = "https://challenges.cloudflare.com/turnstile/v0/siteverify"
log = logging.getLogger(__name__)


def is_enabled() -> bool:
    cfg = current_app.config
    return not cfg.get("CAPTCHA_BYPASS") and bool(cfg.get("TURNSTILE_SECRET_KEY")) \
        and bool(cfg.get("TURNSTILE_SITE_KEY"))


def site_key() -> str:
    return current_app.config.get("TURNSTILE_SITE_KEY", "") if is_enabled() else ""


def verify(token: str | None) -> bool:
    """True if the token is valid (or the CAPTCHA is switched off)."""
    if current_app.config.get("CAPTCHA_BYPASS") or not is_enabled():
        return True
    if not token or not isinstance(token, str) or len(token) > 2048:
        return False
    payload = {"secret": current_app.config["TURNSTILE_SECRET_KEY"], "response": token}
    if has_request_context() and request.remote_addr:
        payload["remoteip"] = request.remote_addr
    try:
        res = requests.post(VERIFY_URL, data=payload, timeout=5)
        return bool(res.json().get("success"))
    except (requests.RequestException, ValueError):
        log.warning("CAPTCHA verification failed to reach Cloudflare")
        return False                     # fail closed: no network = no pass
