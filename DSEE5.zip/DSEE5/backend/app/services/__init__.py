"""Business rules. Services know nothing about URLs or JSON: they take Python values,
apply the rules and save to the database, so both HTTP routes and chat events reuse them."""
