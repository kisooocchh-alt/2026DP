"""Registration, login, password, two-factor and account-deletion rules."""
import secrets
from dataclasses import dataclass
from datetime import timedelta

from flask import g
from sqlalchemy.exc import IntegrityError

from .. import constants as C
from ..extensions import db
from ..models.booking import BookingRequest
from ..models.bookmark import Bookmark
from ..models.chat import Message
from ..models.dse_event import CountdownFollow
from ..models.notification import Notification, PushSubscription
from ..models.quiz import Attempt
from ..models.score import ScoreTransaction
from ..models.security_log import ActivityLog
from ..models.subject import Subject
from ..models.user import StudentProfile, TutorProfile, User
from ..security import abuse_detector, ip_tracker, totp
from ..security import validators as V
from ..security.passwords import (DUMMY_HASH, hash_password, needs_rehash, password_problems,
                                  verify_password)
from ..security.sessions import list_user_sessions, revoke_all_user_sessions
from ..security.validators import FieldError, Form, ValidationError
from ..utils.time_utils import days_ago, hk_today, iso_utc, utcnow
from . import captcha_service, upload_service

MAX_FAILED_LOGINS = 5
LOCK_MINUTES = 15
CAPTCHA_AFTER_FAILURES = 3
CORE_SUBJECTS = ("CHI", "ENG", "MATH", "CSD")


class AuthError(Exception):
    def __init__(self, code: str, status: int = 400):
        super().__init__(code)
        self.code = code
        self.status = status


@dataclass
class LoginResult:
    user: User | None = None
    error_code: str | None = None
    captcha_required: bool = False


def find_user(username: str) -> User | None:
    name = V.clean_text(username, 40).lower()
    if not name:
        return None
    return db.session.execute(
        db.select(User).where(User.username_lower == name)
    ).scalar_one_or_none()


def _password(value, username: str) -> str:
    pw = value if isinstance(value, str) else ""
    problems = password_problems(pw, username)
    if problems:
        raise FieldError(problems[0])
    return pw


def _subjects(codes: list[str]) -> list[Subject]:
    if not codes:
        return []
    rows = db.session.execute(db.select(Subject).where(Subject.code.in_(codes))).scalars().all()
    order = {c: i for i, c in enumerate(codes)}
    return sorted(rows, key=lambda s: order.get(s.code, 99))


# ------------------------------------------------------------------ sign-up
def register_user(data: dict) -> User:
    """Validate everything, then create the user. Raises ValidationError / AuthError."""
    ip = ip_tracker.client_ip()
    if not abuse_detector.signup_allowed(ip, g.get("device_id")):
        ip_tracker.log_activity("auth.register", success=False, meta={"reason": "limit"})
        raise AuthError("signup_limited", 429)

    form = Form(data)
    role = form.field("role", V.choice, C.ROLES, code="role_invalid")
    name = form.field("username", V.username)
    if name and find_user(name) is not None:
        form.errors["username"] = "username_taken"
    password = form.field("password", _password, name or "")
    year = form.field("birth_year", V.birth_year)
    gender = form.field("gender", V.choice, C.GENDERS, code="gender_invalid", required=False)
    guardian = form.field("guardian_email", V.email)
    if not V.boolean(data.get("accept_terms")):
        form.errors["accept_terms"] = "terms_required"

    subjects: list[str] = []
    results: list[dict] = []
    goal = school = exam_year = None
    if role == "student":
        goal = form.field("dse_goal", V.text, max_len=C.DSE_GOAL_MAX, required=True,
                          code="dse_goal_required")
        school = form.field("school", V.text, max_len=C.SCHOOL_MAX, required=True,
                            code="school_required")
        exam_year = form.field("exam_year", V.integer, min_value=hk_today().year - 1,
                               max_value=hk_today().year + 6, code="exam_year_invalid",
                               required=False)
        subjects = form.field("subjects", V.subject_list) or []
    elif role == "tutor":
        subjects = form.field("teaching_subjects", V.subject_list, min_count=1) or []
        results = form.field("dse_results", V.dse_results, required=True) or []
    form.raise_if_errors()

    language = data.get("language") if data.get("language") in C.LANGUAGES else "en"
    user = User(username=name, username_lower=name.lower(), password_hash=hash_password(password),
                role=role, display_name=name, birth_year=year, gender=gender,
                guardian_email=guardian, language=language,     # notifications use it
                last_login_at=utcnow(), last_login_ip=ip)
    if user.is_minor:                                # private by default for under-18s
        user.show_age, user.show_contact = "nobody", "nobody"
    user.subjects = _subjects(subjects)
    if role == "student":
        user.student_profile = StudentProfile(dse_goal=goal, school=school, exam_year=exam_year)
    else:
        user.tutor_profile = TutorProfile(dse_results=results)
    db.session.add(user)
    try:
        db.session.flush()
    except IntegrityError:
        db.session.rollback()
        raise ValidationError({"username": "username_taken"}) from None

    db.session.add(ScoreTransaction(user_id=user.id, amount=C.SIGNUP_BONUS,
                                    reason="signup_bonus"))
    if role == "student":                            # follow exam dates for own subjects
        for code in dict.fromkeys([*CORE_SUBJECTS, *subjects]):
            db.session.add(CountdownFollow(user_id=user.id, subject_code=code))
    db.session.commit()
    ip_tracker.log_activity("auth.register", user_id=user.id, meta={"role": role})
    return user


# ------------------------------------------------------------------ login
def _login_failed(user: User | None, ip: str, username: str, reason: str) -> None:
    if user is not None:
        user.failed_logins += 1
        if user.failed_logins >= MAX_FAILED_LOGINS:
            user.locked_until = utcnow() + timedelta(minutes=LOCK_MINUTES)
            user.failed_logins = 0
        db.session.commit()
    ip_tracker.log_activity("auth.login", user_id=user.id if user else None, success=False,
                            meta={"username": username[:40], "reason": reason})
    abuse_detector.after_login_failure(ip)


def _captcha_needed(user: User | None, ip: str) -> bool:
    if not captcha_service.is_enabled():
        return False
    return abuse_detector.recent_login_failures(ip) >= CAPTCHA_AFTER_FAILURES or \
        bool(user and user.failed_logins >= CAPTCHA_AFTER_FAILURES)


def authenticate(username: str, password: str, *, totp_code: str | None = None,
                 captcha_token: str | None = None) -> LoginResult:
    """Check a login. Wrong username and wrong password give the same answer, and the
    same amount of work, so attackers cannot discover which usernames exist."""
    ip = ip_tracker.client_ip()
    name = V.clean_text(username, 40)
    user = find_user(name)

    if _captcha_needed(user, ip) and not captcha_service.verify(captcha_token):
        return LoginResult(error_code="captcha_required", captcha_required=True)

    if user is not None and user.locked_until and user.locked_until > utcnow():
        verify_password(DUMMY_HASH, password or "")
        ip_tracker.log_activity("auth.login", user_id=user.id, success=False,
                                meta={"reason": "locked"})
        return LoginResult(error_code="account_locked")

    stored = user.password_hash if user is not None and not user.is_deleted else DUMMY_HASH
    if not verify_password(stored, password or "") or user is None or user.is_deleted:
        _login_failed(user, ip, name, "password")
        return LoginResult(error_code="invalid_credentials",
                           captcha_required=_captcha_needed(user, ip))

    if user.is_blocked:
        ip_tracker.log_activity("auth.login", user_id=user.id, success=False,
                                meta={"reason": "blocked"})
        return LoginResult(error_code="account_blocked")

    if user.totp_secret:
        if not totp_code:
            return LoginResult(error_code="totp_required")
        step = totp.verify(user.totp_secret, totp_code, user.totp_last_timecode)
        if step is not None:
            user.totp_last_timecode = step
        else:
            remaining = totp.use_recovery_code(user.recovery_codes, totp_code) \
                if totp.looks_like_recovery_code(totp_code) else None
            if remaining is None:
                _login_failed(user, ip, name, "totp")
                return LoginResult(error_code="totp_invalid")
            user.recovery_codes = remaining

    user.failed_logins = 0
    user.locked_until = None
    user.last_login_at = utcnow()
    user.last_login_ip = ip
    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(password)
    db.session.commit()
    ip_tracker.log_activity("auth.login", user_id=user.id)
    return LoginResult(user=user)


# ------------------------------------------------------------------ password
def change_password(user: User, old: str, new: str, keep_session_id: int | None) -> None:
    if not verify_password(user.password_hash, old or ""):
        raise ValidationError({"old_password": "password_wrong"})
    problems = password_problems(new if isinstance(new, str) else "", user.username)
    if problems:
        raise ValidationError({"new_password": problems[0]})
    if verify_password(user.password_hash, new):
        raise ValidationError({"new_password": "password_same"})
    user.password_hash = hash_password(new)
    db.session.commit()
    revoke_all_user_sessions(user.id, except_id=keep_session_id)
    ip_tracker.log_activity("auth.password_change", user_id=user.id)


# ------------------------------------------------------------------ two-factor
def begin_2fa_setup(user: User) -> dict:
    if user.totp_secret:
        raise AuthError("totp_already_enabled", 409)
    secret = totp.new_secret()
    uri = totp.provisioning_uri(secret, user.username)
    return {"secret": secret, "otpauth_uri": uri, "qr_data_uri": totp.qr_data_uri(uri)}


def enable_2fa(user: User, pending_secret: str | None, code: str) -> list[str]:
    if user.totp_secret:
        raise AuthError("totp_already_enabled", 409)
    if not pending_secret:
        raise AuthError("totp_setup_expired")
    step = totp.verify(pending_secret, code)
    if step is None:
        raise AuthError("totp_invalid")
    codes, hashes = totp.new_recovery_codes()
    user.totp_secret, user.totp_last_timecode, user.recovery_codes = pending_secret, step, hashes
    db.session.commit()
    ip_tracker.log_activity("auth.2fa_enabled", user_id=user.id)
    return codes


def _check_second_factor(user: User, code: str) -> None:
    step = totp.verify(user.totp_secret, code, user.totp_last_timecode)
    if step is not None:
        user.totp_last_timecode = step
        return
    remaining = totp.use_recovery_code(user.recovery_codes, code)
    if remaining is None:
        raise AuthError("totp_invalid")
    user.recovery_codes = remaining


def disable_2fa(user: User, password: str, code: str) -> None:
    if not user.totp_secret:
        raise AuthError("totp_not_enabled", 409)
    if not verify_password(user.password_hash, password or ""):
        raise AuthError("password_wrong")
    _check_second_factor(user, code)
    user.totp_secret = user.totp_last_timecode = None
    user.recovery_codes = None
    db.session.commit()
    ip_tracker.log_activity("auth.2fa_disabled", user_id=user.id)


def regenerate_recovery_codes(user: User, code: str) -> list[str]:
    if not user.totp_secret:
        raise AuthError("totp_not_enabled", 409)
    _check_second_factor(user, code)
    codes, hashes = totp.new_recovery_codes()
    user.recovery_codes = hashes
    db.session.commit()
    ip_tracker.log_activity("auth.recovery_codes", user_id=user.id)
    return codes


# ------------------------------------------------------------------ your data
def export_user_data(user: User) -> dict:
    """Everything DSEE5 stores about this user (a data access request under the PDPO)."""
    def rows(stmt):
        return db.session.execute(stmt).scalars().all()

    return {
        "exported_at": iso_utc(utcnow()),
        "profile": user.to_private_dict(),
        "score_history": [t.to_dict() for t in rows(
            db.select(ScoreTransaction).where(ScoreTransaction.user_id == user.id)
            .order_by(ScoreTransaction.id))],
        "attempts": [a.summary_dict() for a in rows(
            db.select(Attempt).where(Attempt.user_id == user.id).order_by(Attempt.id))],
        "bookings": [b.to_dict(user.id) for b in rows(
            db.select(BookingRequest).where((BookingRequest.student_id == user.id)
                                            | (BookingRequest.tutor_id == user.id)))],
        "messages": [{"subject": m.subject_code, "text": m.text, "deleted": m.is_deleted,
                      "created_at": iso_utc(m.created_at)} for m in rows(
            db.select(Message).where(Message.user_id == user.id).order_by(Message.id))],
        "bookmarks": [{"type": b.item_type, "id": b.item_id} for b in rows(
            db.select(Bookmark).where(Bookmark.user_id == user.id))],
        "notifications": [n.to_dict() for n in rows(
            db.select(Notification).where(Notification.user_id == user.id))],
        "sessions": [s.to_dict() for s in list_user_sessions(user.id)],
        "activity_log": [a.to_dict() for a in rows(
            db.select(ActivityLog).where(ActivityLog.user_id == user.id,
                                         ActivityLog.created_at >= days_ago(C.LOG_RETENTION_DAYS))
            .order_by(ActivityLog.id))],
    }


def delete_account(user: User, password: str) -> None:
    """Remove personal data and close the account. Messages stay as 'deleted user'
    so conversations still make sense; logs expire on their normal schedule."""
    if not verify_password(user.password_hash, password or ""):
        raise AuthError("password_wrong")
    upload_service.delete_file("avatars", user.avatar_file)
    if user.tutor_profile:
        upload_service.delete_file("certificates", user.tutor_profile.certificate_file)
        tp = user.tutor_profile
        tp.certificate_file, tp.short_description, tp.hourly_wage = None, None, None
        tp.dse_results, tp.is_verified = [], False
    if user.student_profile:
        user.student_profile.school, user.student_profile.dse_goal = "-", "-"
    for b in db.session.execute(db.select(BookingRequest).where(
            ((BookingRequest.student_id == user.id) | (BookingRequest.tutor_id == user.id)),
            BookingRequest.status.in_(("pending", "accepted")))).scalars():
        b.status = "cancelled"
    db.session.execute(db.delete(PushSubscription).where(PushSubscription.user_id == user.id))
    db.session.execute(db.delete(CountdownFollow).where(CountdownFollow.user_id == user.id))
    user.username = user.username_lower = f"deleted_{user.id}"
    user.display_name = user.bio = user.contact = user.avatar_file = None
    user.guardian_email = user.gender = user.birth_year = None
    user.totp_secret = user.recovery_codes = None
    user.password_hash = hash_password(secrets.token_urlsafe(32))
    user.subjects = []
    user.is_deleted, user.deleted_at = True, utcnow()
    db.session.commit()
    revoke_all_user_sessions(user.id)
    ip_tracker.log_activity("auth.account_deleted", user_id=user.id)
