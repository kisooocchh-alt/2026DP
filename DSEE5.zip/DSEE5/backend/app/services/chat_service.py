"""Rules for the subject chat rooms. Used by sockets/chat_events.py and routes/chat.py."""
import re

from sqlalchemy import func, or_

from .. import constants as C
from ..extensions import db, socketio
from ..models.chat import ChatImage, Message, PinnedMessage
from ..models.user import User
from ..security import abuse_detector, ip_tracker
from ..utils.time_utils import hk_day_start_utc, utcnow
from . import captcha_service, moderation_service, notification_service, score_service

_MENTION = re.compile(r"(?<![\w@])@([A-Za-z0-9_]{3,20})\b")
NAMESPACE = "/chat"


class ChatError(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


def needs_captcha(user: User) -> bool:
    """A robot check before a user's first message of each Hong Kong day."""
    if not captcha_service.is_enabled():
        return False
    sent_today = db.session.execute(
        db.select(Message.id).where(Message.user_id == user.id,
                                    Message.created_at >= hk_day_start_utc()).limit(1)
    ).first()
    return sent_today is None


def send_message(user: User, subject: str, text: str, image_id=None,
                 captcha_token: str | None = None) -> Message:
    text = (text or "").replace("\r\n", "\n").strip()
    if subject not in C.SUBJECT_CODES:
        raise ChatError("unknown_subject")
    if not text and not image_id:
        raise ChatError("empty_message")
    if len(text) > C.MAX_MESSAGE_LENGTH:
        raise ChatError("message_too_long")
    if user.is_muted:
        raise ChatError("muted")
    flood = abuse_detector.check_chat_flood(user, text)
    if flood:
        raise ChatError(flood)
    if moderation_service.contains_banned_words(text):
        raise ChatError("blocked_words")
    if user.is_minor and moderation_service.contains_contact_info(text):
        raise ChatError("no_contact_info_minor")

    image = None
    if image_id not in (None, ""):
        image = db.session.get(ChatImage, int(image_id)) if str(image_id).isdigit() else None
        if image is None or image.owner_id != user.id or image.message_id is not None:
            raise ChatError("bad_image")
    if needs_captcha(user) and not captcha_service.verify(captcha_token):
        raise ChatError("captcha_required")

    msg = Message(subject_code=subject, user_id=user.id, text=text)
    db.session.add(msg)
    db.session.flush()                                     # gives msg.id
    cost = C.MESSAGE_COST_IMAGE if image else C.MESSAGE_COST_TEXT
    try:
        score_service.spend_points(user.id, cost, "chat_message", ref_id=msg.id)
    except score_service.NotEnoughPoints:
        db.session.rollback()
        raise ChatError("not_enough_points") from None
    if image is not None:
        image.message_id = msg.id
    db.session.commit()                                    # message + points saved together
    db.session.refresh(user)                               # up-to-date score
    ip_tracker.log_activity("chat.message", user_id=user.id,
                            meta={"message_id": msg.id, "subject": subject,
                                  "image": image is not None})
    if not user.is_shadow_banned:
        _notify_mentions(user, msg)
    return msg


def _notify_mentions(sender: User, msg: Message) -> None:
    names = []
    for name in _MENTION.findall(msg.text):
        if name.lower() not in names and name.lower() != sender.username_lower:
            names.append(name.lower())
    names = names[:C.MENTIONS_PER_MESSAGE]
    if not names:
        return
    ids = db.session.execute(
        db.select(User.id).where(User.username_lower.in_(names), User.is_blocked.is_(False),
                                 User.is_deleted.is_(False))
    ).scalars().all()
    subject = C.SUBJECT_BY_CODE[msg.subject_code]
    preview = msg.text[:120]
    notification_service.notify_many(
        ids, "mention",
        {"en": f"{sender.name} mentioned you in {subject['name_en']}",
         "zh-HK": f"{sender.name} 在{subject['name_zh']}討論區提及你"},
        preview, f"/chat?room={msg.subject_code}#m{msg.id}")


def _visible_to(viewer: User | None):
    """Shadow-banned users' messages are only visible to themselves."""
    cond = User.is_shadow_banned.is_(False)
    if viewer is not None:
        cond = or_(cond, Message.user_id == viewer.id)
    return cond


def history(subject: str, viewer: User | None, before_id: int | None = None,
            limit: int = C.CHAT_PAGE_SIZE) -> tuple[list[Message], bool]:
    stmt = (db.select(Message).join(User, Message.user_id == User.id)
            .where(Message.subject_code == subject, _visible_to(viewer)))
    if before_id:
        stmt = stmt.where(Message.id < before_id)
    rows = db.session.execute(stmt.order_by(Message.id.desc()).limit(limit + 1)).scalars().all()
    has_more = len(rows) > limit
    return list(reversed(rows[:limit])), has_more


def search(subject: str, viewer: User | None, query: str, limit: int = 30) -> list[Message]:
    query = query.strip()[:80]
    stmt = (db.select(Message).join(User, Message.user_id == User.id)
            .where(Message.subject_code == subject, _visible_to(viewer),
                   Message.is_deleted.is_(False), Message.is_hidden.is_(False),
                   Message.text.contains(query, autoescape=True))
            .order_by(Message.id.desc()).limit(limit))
    return list(db.session.execute(stmt).scalars())


def pinned(subject: str) -> list[Message]:
    stmt = (db.select(Message).join(PinnedMessage, PinnedMessage.message_id == Message.id)
            .where(PinnedMessage.subject_code == subject, Message.is_deleted.is_(False))
            .order_by(PinnedMessage.pinned_at.desc()))
    return list(db.session.execute(stmt).scalars())


def last_message_times() -> dict[str, str]:
    rows = db.session.execute(
        db.select(Message.subject_code, func.max(Message.created_at))
        .where(Message.is_deleted.is_(False)).group_by(Message.subject_code)
    ).all()
    return {code: when for code, when in rows}


def delete_message(message: Message, admin_id: int, reason: str, penalty: bool = False) -> None:
    """Soft delete (kept for audit), optional points penalty, tell everyone in the room."""
    if message.is_deleted:
        return
    message.is_deleted = True
    message.deleted_by = admin_id
    message.delete_reason = (reason or "")[:200]
    message.deleted_at = utcnow()
    db.session.execute(db.delete(PinnedMessage).where(PinnedMessage.message_id == message.id))
    if penalty:
        score_service.take_points(message.user_id, C.REMOVED_MESSAGE_PENALTY, "penalty",
                                  note=f"Message {message.id} removed", ref_id=message.id)
    db.session.commit()
    socketio.emit("message_deleted", {"id": message.id}, to=message.subject_code,
                  namespace=NAMESPACE)


def set_pinned(message: Message, admin_id: int, pin: bool) -> None:
    existing = db.session.execute(
        db.select(PinnedMessage).where(PinnedMessage.message_id == message.id)
    ).scalar_one_or_none()
    if pin and existing is None and not message.is_deleted:
        db.session.add(PinnedMessage(subject_code=message.subject_code, message_id=message.id,
                                     pinned_by=admin_id))
    elif not pin and existing is not None:
        db.session.delete(existing)
    db.session.commit()
    socketio.emit("message_pinned", {"id": message.id, "pinned": pin},
                  to=message.subject_code, namespace=NAMESPACE)
