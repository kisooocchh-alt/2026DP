"""Safe file uploads for avatars, chat images, tutor certificates, question images,
past papers and materials.

- The real file type is detected from the bytes, never from the file name.
- Images are re-encoded to WebP with Pillow: this removes EXIF data (including GPS
  location) and anything hidden inside the file.
- PDFs must start with %PDF and may not contain JavaScript, launch actions, embedded
  files or Flash, even hidden in compressed streams or written with #xx escapes; they
  can also be virus-scanned with ClamAV (CLAMAV_ENABLED=true).
- Files get random names and live in backend/storage/, outside the public folder.
"""
import re
import secrets
import socket
import struct
import zlib
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path

import filetype
from flask import current_app, send_from_directory
from PIL import Image, ImageOps, UnidentifiedImageError

from .. import constants as C

FOLDERS = ("avatars", "chat_images", "certificates", "papers", "materials", "questions")
_NAME_RE = re.compile(r"^[a-f0-9]{32}\.(webp|pdf)$")
Image.MAX_IMAGE_PIXELS = 40_000_000          # refuse "decompression bomb" images


class UploadError(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


@dataclass
class SavedFile:
    name: str
    size: int
    width: int | None = None
    height: int | None = None
    kind: str = "image"                      # image | pdf


def ensure_storage_dirs(app) -> None:
    for name in FOLDERS:
        (Path(app.config["STORAGE_DIR"]) / name).mkdir(parents=True, exist_ok=True)


def _folder(folder: str) -> Path:
    if folder not in FOLDERS:
        raise ValueError(f"unknown storage folder {folder}")
    return Path(current_app.config["STORAGE_DIR"]) / folder


def _read_limited(file_storage, max_mb: int) -> bytes:
    if file_storage is None or not getattr(file_storage, "filename", None):
        raise UploadError("file_missing")
    limit = max_mb * 1024 * 1024
    data = file_storage.read(limit + 1)
    if not data:
        raise UploadError("file_missing")
    if len(data) > limit:
        raise UploadError("file_too_large")
    return data


def detect_kind(data: bytes) -> str | None:
    kind = filetype.guess(data[:8192])
    if kind is None:
        return None
    if kind.mime in C.ALLOWED_IMAGE_TYPES:
        return "image"
    if kind.mime in C.ALLOWED_DOC_TYPES:
        return "pdf"
    return None


def save_image(file_storage, folder: str, max_side: int = 1600, *,
               data: bytes | None = None) -> SavedFile:
    data = data if data is not None else _read_limited(file_storage, C.MAX_IMAGE_MB)
    if detect_kind(data) != "image":
        raise UploadError("bad_file_type")
    try:
        img = Image.open(BytesIO(data))
        img.load()
        img = ImageOps.exif_transpose(img)         # keep the photo the right way up
        img.thumbnail((max_side, max_side))
        if img.mode in ("RGBA", "LA", "P"):
            img = img.convert("RGBA")
        else:
            img = img.convert("RGB")
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError, ValueError):
        raise UploadError("bad_image") from None
    name = f"{secrets.token_hex(16)}.webp"
    path = _folder(folder) / name
    img.save(path, "WEBP", quality=82, method=4)   # the new file has no EXIF / GPS data
    return SavedFile(name=name, size=path.stat().st_size, width=img.width, height=img.height)


_PDF_DANGER = re.compile(rb"/(?:JavaScript|JS|Launch|EmbeddedFiles?|RichMedia)(?![A-Za-z0-9])")
_PDF_NAME_ESCAPE = re.compile(rb"#([0-9A-Fa-f]{2})")
_PDF_STREAM = re.compile(rb"stream\r?\n(.*?)\r?\nendstream", re.S)
_PDF_INFLATE_BUDGET = 64 * 1024 * 1024       # stop "zip bomb" streams


def _pdf_has_danger(data: bytes) -> bool:
    """Look for active content in the file and inside its compressed streams (object
    streams can hide whole objects). #xx escapes in names are decoded first, so
    /Java#53cript is caught too."""
    def dangerous(chunk: bytes) -> bool:
        return bool(_PDF_DANGER.search(_PDF_NAME_ESCAPE.sub(
            lambda m: bytes([int(m.group(1), 16)]), chunk)))

    if dangerous(data):
        return True
    budget = _PDF_INFLATE_BUDGET
    for match in _PDF_STREAM.finditer(data):
        if budget <= 0:
            return True                      # too much hidden data to check: refuse
        try:
            inflater = zlib.decompressobj()
            inflated = inflater.decompress(match.group(1), budget)
        except zlib.error:
            continue                         # not Flate (images, fonts): nothing to check
        budget -= len(inflated)
        if dangerous(inflated):
            return True
    return False


def save_pdf(file_storage, folder: str, max_mb: int = C.MAX_PDF_MB, *,
             data: bytes | None = None) -> SavedFile:
    data = data if data is not None else _read_limited(file_storage, max_mb)
    if not data.startswith(b"%PDF-") or detect_kind(data) != "pdf":
        raise UploadError("bad_file_type")
    if _pdf_has_danger(data):
        raise UploadError("unsafe_pdf")
    if current_app.config.get("CLAMAV_ENABLED") and not _clamav_clean(data):
        raise UploadError("virus_found")
    name = f"{secrets.token_hex(16)}.pdf"
    path = _folder(folder) / name
    path.write_bytes(data)
    return SavedFile(name=name, size=len(data), kind="pdf")


def save_image_or_pdf(file_storage, folder: str, max_side: int = 2000,
                      max_pdf_mb: int = C.MAX_PDF_MB) -> SavedFile:
    data = _read_limited(file_storage, max(max_pdf_mb, C.MAX_IMAGE_MB))
    kind = detect_kind(data)
    if kind == "image":
        if len(data) > C.MAX_IMAGE_MB * 1024 * 1024:
            raise UploadError("file_too_large")
        return save_image(None, folder, max_side, data=data)
    if kind == "pdf":
        return save_pdf(None, folder, max_pdf_mb, data=data)
    raise UploadError("bad_file_type")


def delete_file(folder: str, name: str | None) -> None:
    if not name or not _NAME_RE.match(name):
        return
    try:
        (_folder(folder) / name).unlink(missing_ok=True)
    except OSError:
        current_app.logger.warning("Could not delete %s/%s", folder, name)


def valid_name(name: str) -> bool:
    return bool(name and _NAME_RE.match(name))


def send_stored(folder: str, name: str, *, download_name: str | None = None,
                as_attachment: bool = False, max_age: int = 0, private: bool = True):
    """Send a stored file. Only call this after checking the viewer may see it."""
    if not valid_name(name):
        from flask import abort
        abort(404)
    response = send_from_directory(_folder(folder), name, as_attachment=as_attachment,
                                   download_name=download_name, max_age=max_age,
                                   conditional=True)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Cache-Control"] = (f"{'private' if private else 'public'}, "
                                         f"max-age={max_age}")
    return response


def _clamav_clean(data: bytes) -> bool:
    """Stream the file to clamd (INSTREAM). True = clean. Fails closed."""
    host, port = current_app.config["CLAMAV_HOST"], current_app.config["CLAMAV_PORT"]
    try:
        with socket.create_connection((host, port), timeout=15) as s:
            s.sendall(b"zINSTREAM\0")
            for i in range(0, len(data), 8192):
                chunk = data[i:i + 8192]
                s.sendall(struct.pack("!I", len(chunk)) + chunk)
            s.sendall(struct.pack("!I", 0))
            reply = s.recv(4096).strip(b"\0").strip()
    except OSError:
        raise UploadError("scan_unavailable") from None
    return reply.endswith(b"OK")
