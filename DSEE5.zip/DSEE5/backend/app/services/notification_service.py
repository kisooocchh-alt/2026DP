"""In-app notifications and browser push messages.

Titles and bodies may be given as {"en": "...", "zh-HK": "..."}; each user gets the
text in their own language. Push messages are sent in a background thread so a slow
push service never slows down the request.
"""
import json
import logging
from concurrent.futures import ThreadPoolExecutor

from flask import current_app

from ..extensions import db
from ..models.notification import Notification, PushSubscription
from ..models.user import User

log = logging.getLogger(__name__)
_executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="push")

Text = str | dict


def _pick(text: Text, language: str) -> str:
    if isinstance(text, dict):
        return text.get(language) or text.get("en") or next(iter(text.values()), "")
    return text or ""


def push_enabled() -> bool:
    cfg = current_app.config
    if not (cfg.get("VAPID_PUBLIC_KEY") and cfg.get("VAPID_PRIVATE_KEY")) or cfg.get("TESTING"):
        return False
    try:
        import pywebpush  # noqa: F401
    except ImportError:
        return False
    return True


def notify(user_id: int, kind: str, title: Text, body: Text = "", link: str = "") -> None:
    notify_many([user_id], kind, title, body, link)


def notify_many(user_ids, kind: str, title: Text, body: Text = "", link: str = "") -> int:
    """Create a notification for each user (and push it). Commits. Returns the count."""
    ids = sorted({int(u) for u in user_ids if u})
    if not ids:
        return 0
    users = db.session.execute(
        db.select(User.id, User.language).where(User.id.in_(ids), User.is_deleted.is_(False))
    ).all()
    payloads = []
    for uid, lang in users:
        t, b = _pick(title, lang)[:160], _pick(body, lang)[:500]
        db.session.add(Notification(user_id=uid, kind=kind, title=t, body=b, link=link[:200]))
        payloads.append((uid, {"title": t, "body": b, "link": link or "/notifications"}))
    db.session.commit()
    if push_enabled():
        app = current_app._get_current_object()
        for uid, payload in payloads:
            _executor.submit(_push_to_user, app, uid, payload)
    return len(payloads)


def _push_to_user(app, user_id: int, payload: dict) -> None:
    from pywebpush import WebPushException, webpush
    with app.app_context():
        subs = db.session.execute(
            db.select(PushSubscription).where(PushSubscription.user_id == user_id)
        ).scalars().all()
        for sub in subs:
            try:
                webpush(
                    subscription_info={"endpoint": sub.endpoint,
                                       "keys": {"p256dh": sub.p256dh, "auth": sub.auth}},
                    data=json.dumps(payload),
                    vapid_private_key=app.config["VAPID_PRIVATE_KEY"],
                    vapid_claims={"sub": app.config["VAPID_CLAIM_EMAIL"]},
                    ttl=60 * 60 * 24,
                )
            except WebPushException as exc:
                status = getattr(exc.response, "status_code", None)
                if status in (404, 410):                 # the browser unsubscribed
                    db.session.delete(sub)
                    db.session.commit()
                else:
                    log.warning("Push to user %s failed: %s", user_id, exc)
            except Exception:  # noqa: BLE001 - never crash the worker thread
                log.exception("Push to user %s failed", user_id)
        db.session.remove()


def unread_count(user_id: int) -> int:
    return db.session.execute(
        db.select(db.func.count(Notification.id))
        .where(Notification.user_id == user_id, Notification.is_read.is_(False))
    ).scalar_one()
