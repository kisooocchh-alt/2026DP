"""DSE countdown reminders: 100, 30, 7 and 1 day(s) before each published event.

Subject events go to users who follow that subject; general events (first exam day,
results day) go to everyone.
"""
import logging

from .. import constants as C
from ..extensions import db
from ..models.dse_event import CountdownFollow, DseEvent
from ..models.user import User
from ..services import notification_service
from ..utils.time_utils import hk_date_of, hk_today, utcnow

log = logging.getLogger(__name__)


def _when_text(days: int) -> dict:
    if days == 1:
        return {"en": "is tomorrow", "zh-HK": "就在明天"}
    return {"en": f"is in {days} days", "zh-HK": f"還有 {days} 日"}


def send_due_alerts() -> int:
    today = hk_today()
    events = db.session.execute(
        db.select(DseEvent).where(DseEvent.is_published.is_(True), DseEvent.starts_at > utcnow())
    ).scalars().all()
    sent = 0
    for event in events:
        days = (hk_date_of(event.starts_at) - today).days
        if days not in C.COUNTDOWN_ALERT_DAYS:
            continue
        if event.subject_code:
            user_ids = db.session.execute(
                db.select(CountdownFollow.user_id)
                .where(CountdownFollow.subject_code == event.subject_code)).scalars().all()
        else:
            user_ids = db.session.execute(
                db.select(User.id).where(User.is_deleted.is_(False),
                                         User.is_blocked.is_(False))).scalars().all()
        when = _when_text(days)
        sent += notification_service.notify_many(
            user_ids, "countdown",
            {"en": f"{event.title_en} {when['en']}", "zh-HK": f"{event.title_zh}{when['zh-HK']}"},
            {"en": "Keep going - check your plan on DSEE5.",
             "zh-HK": "繼續努力，在 DSEE5 查看你的溫習計劃。"},
            "/dashboard")
    log.info("Sent %s countdown notifications", sent)
    return sent
