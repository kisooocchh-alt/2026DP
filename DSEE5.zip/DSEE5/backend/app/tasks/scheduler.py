"""Background jobs, run in Hong Kong time.

Started once by run.py (development) or wsgi.py (production, single Gunicorn worker).
Triggers are created as objects, not strings, so they work in every install.
"""
import logging

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from ..services import quiz_service
from . import backup, cleanup, countdown_alerts

log = logging.getLogger(__name__)
_scheduler: BackgroundScheduler | None = None


def start_scheduler(app) -> BackgroundScheduler | None:
    global _scheduler
    if _scheduler is not None or app.testing or not app.config.get("SCHEDULER_ENABLED"):
        return _scheduler
    tz = app.config["APP_TIMEZONE"]
    scheduler = BackgroundScheduler(timezone=tz, job_defaults={"coalesce": True,
                                                               "max_instances": 1,
                                                               "misfire_grace_time": 300})

    def in_app(fn):
        def run():
            with app.app_context():
                try:
                    fn()
                except Exception:  # noqa: BLE001 - log and keep the scheduler alive
                    log.exception("Background job %s failed", fn.__name__)
        run.__name__ = fn.__name__
        return run

    scheduler.add_job(in_app(backup.run_backup), CronTrigger(hour=3, minute=30, timezone=tz),
                      id="backup")
    scheduler.add_job(in_app(cleanup.run_cleanup), CronTrigger(hour=4, minute=0, timezone=tz),
                      id="cleanup")
    scheduler.add_job(in_app(countdown_alerts.send_due_alerts),
                      CronTrigger(hour=8, minute=0, timezone=tz), id="countdown")
    scheduler.add_job(in_app(quiz_service.expire_overdue), IntervalTrigger(minutes=1),
                      id="quiz_expiry")
    scheduler.start()
    _scheduler = scheduler
    log.info("Background jobs started")
    return scheduler
