"""Automatic backups so a broken server or a mistake never loses user data.

- Every day: a safe copy of the database (SQLite backup API, or pg_dump for PostgreSQL)
- Every Sunday: a zip of backend/storage (uploaded files)
- Backups older than BACKUP_KEEP_DAYS are deleted

Copy backups to a second place (another server or cloud storage): a backup on the same
disk is lost if that disk fails. Test a restore at least once.
"""
import logging
import os
import shutil
import sqlite3
import subprocess
from datetime import datetime
from pathlib import Path

from flask import current_app
from sqlalchemy.engine import make_url

from .. import constants as C
from ..extensions import db
from ..security import ip_tracker
from ..utils.time_utils import hk_now

log = logging.getLogger(__name__)


def _backup_sqlite(database: str, target: Path) -> Path:
    out = target / f"dsee5-{hk_now():%Y%m%d-%H%M}.db"
    src = sqlite3.connect(database)
    dst = sqlite3.connect(out)
    try:
        with dst:
            src.backup(dst)                      # consistent copy even while in use
    finally:
        dst.close()
        src.close()
    return out


def _backup_postgres(url: str, target: Path) -> Path:
    out = target / f"dsee5-{hk_now():%Y%m%d-%H%M}.dump"
    parsed = make_url(url).set(drivername="postgresql")
    env = {**os.environ, "PGPASSWORD": parsed.password or ""}
    conninfo = parsed.set(password=None).render_as_string(hide_password=False)
    subprocess.run(["pg_dump", "--format=custom", f"--file={out}", conninfo],  # noqa: S603,S607
                   check=True, env=env, timeout=3600)
    return out


def _archive_storage(target: Path) -> Path | None:
    if hk_now().weekday() != 6:                  # Sunday only
        return None
    storage = Path(current_app.config["STORAGE_DIR"])
    base = target / f"storage-{hk_now():%Y%m%d}"
    return Path(shutil.make_archive(str(base), "zip", root_dir=storage))


def _prune(target: Path) -> int:
    cutoff = datetime.now().timestamp() - C.BACKUP_KEEP_DAYS * 86400
    removed = 0
    for item in target.iterdir():
        if item.is_file() and item.name.startswith(("dsee5-", "storage-")) and \
                item.stat().st_mtime < cutoff:
            item.unlink()
            removed += 1
    return removed


def run_backup() -> Path | None:
    target = Path(current_app.config["BACKUP_DIR"])
    target.mkdir(parents=True, exist_ok=True)
    url = str(db.engine.url)
    try:
        if url.startswith("sqlite"):
            database = db.engine.url.database
            if not database or database == ":memory:":
                return None
            out = _backup_sqlite(database, target)
        elif url.startswith("postgresql"):
            out = _backup_postgres(db.engine.url.render_as_string(hide_password=False), target)
        else:
            log.warning("No backup method for %s", db.engine.url.drivername)
            return None
        archive = _archive_storage(target)
        removed = _prune(target)
        ip_tracker.log_activity("system.backup", ip="127.0.0.1",
                                meta={"file": out.name, "storage": archive.name if archive
                                      else None, "removed": removed})
        log.info("Backup written to %s", out)
        return out
    except Exception as exc:  # noqa: BLE001
        ip_tracker.log_activity("system.backup", ip="127.0.0.1", success=False,
                                meta={"error": str(exc)[:200]})
        raise
