"""Removes data that is no longer needed: keeps the database small and follows the
data-minimisation principle of Hong Kong's Personal Data (Privacy) Ordinance."""
import logging
from datetime import timedelta

from .. import constants as C
from ..extensions import db
from ..models.chat import ChatImage
from ..models.notification import Notification
from ..models.security_log import ActivityLog, BlockedIP
from ..models.session import AdminSession, UserSession
from ..services import upload_service
from ..utils.time_utils import utcnow

log = logging.getLogger(__name__)


def run_cleanup() -> dict:
    now = utcnow()
    counts = {}
    counts["user_sessions"] = db.session.execute(db.delete(UserSession).where(
        UserSession.expires_at < now - timedelta(days=30))).rowcount
    counts["admin_sessions"] = db.session.execute(db.delete(AdminSession).where(
        AdminSession.expires_at < now - timedelta(days=30))).rowcount
    counts["ip_blocks"] = db.session.execute(db.delete(BlockedIP).where(
        BlockedIP.expires_at.is_not(None), BlockedIP.expires_at < now)).rowcount
    counts["activity_logs"] = db.session.execute(db.delete(ActivityLog).where(
        ActivityLog.created_at < now - timedelta(days=C.LOG_RETENTION_DAYS))).rowcount
    counts["notifications"] = db.session.execute(db.delete(Notification).where(
        Notification.is_read.is_(True),
        Notification.created_at < now - timedelta(days=90))).rowcount

    unsent = db.session.execute(db.select(ChatImage).where(
        ChatImage.message_id.is_(None), ChatImage.created_at < now - timedelta(hours=24))
    ).scalars().all()
    for image in unsent:
        upload_service.delete_file("chat_images", image.file_name)
        db.session.delete(image)
    counts["unsent_images"] = len(unsent)
    db.session.commit()
    log.info("Clean-up finished: %s", counts)
    return counts
