"""Security layer: passwords, sessions, rate limits, headers, IP tracking, 2FA, input checks."""
