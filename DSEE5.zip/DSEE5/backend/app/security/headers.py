"""HTTPS and browser security headers (flask-talisman).

Because of the Content-Security-Policy, never use inline <script> blocks, onclick=
attributes or style= attributes in HTML. Put all JavaScript in .js files.
"""
from flask_talisman import Talisman

CSP = {
    "default-src": "'self'",
    "script-src": ["'self'", "https://challenges.cloudflare.com"],
    "frame-src": ["'self'", "https://challenges.cloudflare.com"],   # own PDF viewer + CAPTCHA
    "style-src": "'self'",
    "img-src": ["'self'", "data:", "blob:"],
    "font-src": "'self'",
    "connect-src": "'self'",          # API calls and the chat WebSocket go to our own site
    "media-src": "'self'",
    "worker-src": "'self'",
    "manifest-src": "'self'",
    "object-src": "'none'",
    "base-uri": "'self'",
    "form-action": "'self'",
    "frame-ancestors": "'none'",
}

# Learning-material files may be shown inside DSEE5's own viewer page.
FRAMEABLE_CSP = {**CSP, "frame-ancestors": "'self'"}

talisman = Talisman()      # module-level so routes can use @talisman(...) overrides


def init_security_headers(app):
    talisman.init_app(
        app,
        force_https=not (app.debug or app.testing),
        strict_transport_security=True,
        strict_transport_security_max_age=31_536_000,
        strict_transport_security_include_subdomains=True,
        strict_transport_security_preload=True,
        content_security_policy=CSP,
        frame_options="DENY",
        referrer_policy="strict-origin-when-cross-origin",
        session_cookie_secure=app.config["SESSION_COOKIE_SECURE"],
        session_cookie_http_only=True,
        permissions_policy={"camera": "()", "microphone": "()", "geolocation": "()",
                            "payment": "()", "usb": "()"},
    )
