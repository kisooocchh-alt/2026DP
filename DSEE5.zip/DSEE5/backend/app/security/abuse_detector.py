"""Automatic rules that spot robots and attackers and slow or block them, without
waiting for the admin. Every automatic block expires on its own.

Rules
- 10 failed logins from one IP in 10 minutes      -> block the IP for 1 hour
- 5 failed logins on one account in 15 minutes      -> lock the account (auth_service)
- 3+ new accounts from one IP or device in 24 hours -> refuse more sign-ups for 24 hours
  (the number is SIGNUP_LIMIT_PER_IP in .env)
- more than 10 chat messages a minute               -> "slow down"
- 20 attempts a minute, or the same text 5 times    -> mute the user for 10 minutes
- 5 requests for attack paths (/.env, /wp-admin...) in an hour -> block the IP for 24 hours
- 3 failed admin logins                             -> lock the admin account (admin_auth)
"""
import threading
import time
from collections import defaultdict, deque
from datetime import timedelta

from flask import current_app
from sqlalchemy import func, or_

from ..extensions import db
from ..models.security_log import ActivityLog, BlockedIP
from ..utils.time_utils import utcnow
from . import ip_tracker

LOGIN_FAIL_WINDOW = timedelta(minutes=10)
LOGIN_FAIL_LIMIT = 10
SIGNUP_WINDOW = timedelta(hours=24)
PROBE_WINDOW = timedelta(hours=1)
PROBE_LIMIT = 5
CHAT_WINDOW_SECONDS = 60
CHAT_SOFT_LIMIT = 10
CHAT_HARD_LIMIT = 20
SAME_TEXT_LIMIT = 5
CHAT_MUTE = timedelta(minutes=10)

_chat_lock = threading.Lock()
_chat_times: dict[int, deque] = defaultdict(deque)
_chat_last: dict[int, tuple[str, int]] = {}


def _trusted(ip: str) -> bool:
    return bool(current_app.config.get("TRUST_LOCALHOST")) and ip in ("127.0.0.1", "::1")


def block_ip(ip: str, *, hours: float | None, reason: str, created_by: str = "auto") -> BlockedIP:
    """Block an IP (hours=None means permanent). Updates an existing block."""
    expires = utcnow() + timedelta(hours=hours) if hours else None
    row = db.session.execute(db.select(BlockedIP).where(BlockedIP.ip == ip)).scalar_one_or_none()
    if row is None:
        row = BlockedIP(ip=ip, reason=reason[:200], created_by=created_by, expires_at=expires)
        db.session.add(row)
    else:
        row.reason, row.created_by, row.expires_at = reason[:200], created_by, expires
        row.created_at = utcnow()
    db.session.commit()
    ip_tracker.invalidate_block_cache()
    ip_tracker.log_activity("security.ip_blocked", success=False, ip=ip,
                            meta={"reason": reason, "hours": hours, "by": created_by})
    return row


def _count(action: str, since, *, ip: str | None = None, device: str | None = None,
           success: bool | None = None) -> int:
    stmt = db.select(func.count(ActivityLog.id)).where(ActivityLog.action == action,
                                                        ActivityLog.created_at >= since)
    if ip and device:
        stmt = stmt.where(or_(ActivityLog.ip == ip, ActivityLog.device_id == device))
    elif ip:
        stmt = stmt.where(ActivityLog.ip == ip)
    if success is not None:
        stmt = stmt.where(ActivityLog.success.is_(success))
    return db.session.execute(stmt).scalar_one()


def recent_login_failures(ip: str, minutes: int = 15) -> int:
    return _count("auth.login", utcnow() - timedelta(minutes=minutes), ip=ip, success=False)


def after_login_failure(ip: str) -> None:
    """Call after logging a failed login. Blocks the IP if it keeps guessing."""
    if _trusted(ip):
        return
    if _count("auth.login", utcnow() - LOGIN_FAIL_WINDOW, ip=ip, success=False) \
            >= LOGIN_FAIL_LIMIT:
        block_ip(ip, hours=1, reason="Too many failed logins")


def signup_allowed(ip: str, device_id: str | None) -> bool:
    if _trusted(ip):
        return True
    created = _count("auth.register", utcnow() - SIGNUP_WINDOW, ip=ip, device=device_id,
                     success=True)
    return created < current_app.config.get("SIGNUP_LIMIT_PER_IP", 3)


def record_probe(ip: str) -> None:
    if _trusted(ip):
        return
    if _count("security.probe", utcnow() - PROBE_WINDOW, ip=ip) >= PROBE_LIMIT:
        block_ip(ip, hours=24, reason="Scanning for attack paths")


def check_chat_flood(user, text: str) -> str | None:
    """Return None if the message may be sent, "slow_down", or "muted"."""
    now = time.monotonic()
    normalized = " ".join(text.lower().split())
    with _chat_lock:
        times = _chat_times[user.id]
        while times and now - times[0] > CHAT_WINDOW_SECONDS:
            times.popleft()
        times.append(now)
        last_text, repeats = _chat_last.get(user.id, ("", 0))
        repeats = repeats + 1 if normalized and normalized == last_text else 1
        _chat_last[user.id] = (normalized, repeats)
        attempts = len(times)
    if attempts > CHAT_HARD_LIMIT or repeats >= SAME_TEXT_LIMIT:
        user.muted_until = utcnow() + CHAT_MUTE
        db.session.commit()
        ip_tracker.log_activity("security.auto_mute", user_id=user.id, success=False,
                                meta={"attempts": attempts, "repeats": repeats})
        with _chat_lock:
            _chat_times.pop(user.id, None)
            _chat_last.pop(user.id, None)
        return "muted"
    if attempts > CHAT_SOFT_LIMIT:
        return "slow_down"
    return None


def reset_chat_state() -> None:
    """Used by tests."""
    with _chat_lock:
        _chat_times.clear()
        _chat_last.clear()
