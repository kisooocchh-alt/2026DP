"""Server-side sessions. The cookie holds a random token; the database holds its hash,
so sessions can be listed and revoked at any time.

User and admin sessions use different cookies and tables: being logged in as a user
never gives any admin access.
"""
import hashlib
import re
import secrets

from flask import current_app, g, request

from ..extensions import db
from ..models.admin import AdminAccount
from ..models.session import AdminSession, UserSession
from ..models.user import User
from ..utils.time_utils import utcnow

_DEVICE_RE = re.compile(r"^[A-Za-z0-9_-]{16,64}$")
_TOUCH_SECONDS = 300            # update last_seen_at at most every 5 minutes


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def _set_cookie(response, name: str, token: str, lifetime) -> None:
    response.set_cookie(name, token, max_age=int(lifetime.total_seconds()), httponly=True,
                        secure=current_app.config["SESSION_COOKIE_SECURE"], samesite="Lax",
                        path="/")


def _client_info() -> tuple[str | None, str]:
    return request.remote_addr, (request.headers.get("User-Agent") or "")[:255]


def _valid(session, idle_timeout) -> bool:
    now = utcnow()
    return (session is not None and not session.revoked and session.expires_at > now
            and session.last_seen_at > now - idle_timeout)


def _touch(session) -> None:
    now = utcnow()
    if (now - session.last_seen_at).total_seconds() > _TOUCH_SECONDS:
        session.last_seen_at = now
        db.session.commit()


# ---------------------------------------------------------------- users
def start_user_session(user: User, response):
    cfg = current_app.config
    token = secrets.token_urlsafe(32)
    ip, agent = _client_info()
    db.session.add(UserSession(
        user_id=user.id, token_hash=_hash(token), ip=ip, user_agent=agent,
        expires_at=utcnow() + cfg["SESSION_LIFETIME"], last_seen_at=utcnow()))
    db.session.commit()
    _set_cookie(response, cfg["AUTH_COOKIE_NAME"], token, cfg["SESSION_LIFETIME"])
    return response


def _load_user_session(token: str | None) -> UserSession | None:
    if not token or len(token) > 100:
        return None
    s = db.session.execute(
        db.select(UserSession).where(UserSession.token_hash == _hash(token))
    ).scalar_one_or_none()
    if not _valid(s, current_app.config["SESSION_IDLE_TIMEOUT"]):
        return None
    if s.user is None or s.user.is_blocked or s.user.is_deleted:
        return None
    _touch(s)
    return s


def load_user_from_token(token: str | None) -> User | None:
    s = _load_user_session(token)
    return s.user if s else None


def revoke_all_user_sessions(user_id: int, except_id: int | None = None) -> int:
    """Password change, 'log out other devices', or admin block."""
    stmt = db.update(UserSession).where(UserSession.user_id == user_id,
                                        UserSession.revoked.is_(False))
    if except_id is not None:
        stmt = stmt.where(UserSession.id != except_id)
    result = db.session.execute(stmt.values(revoked=True))
    db.session.commit()
    return result.rowcount or 0


def revoke_user_session(user_id: int, session_id: int) -> bool:
    s = db.session.get(UserSession, session_id)
    if s is None or s.user_id != user_id:
        return False
    s.revoked = True
    db.session.commit()
    return True


def list_user_sessions(user_id: int) -> list[UserSession]:
    now = utcnow()
    return list(db.session.execute(
        db.select(UserSession)
        .where(UserSession.user_id == user_id, UserSession.revoked.is_(False),
               UserSession.expires_at > now)
        .order_by(UserSession.last_seen_at.desc())
    ).scalars())


def end_session(response):
    name = current_app.config["AUTH_COOKIE_NAME"]
    token = request.cookies.get(name)
    if token:
        db.session.execute(db.update(UserSession).where(UserSession.token_hash == _hash(token))
                           .values(revoked=True))
        db.session.commit()
    response.delete_cookie(name, path="/")
    return response


# ---------------------------------------------------------------- admins
def start_admin_session(admin: AdminAccount, response):
    cfg = current_app.config
    token = secrets.token_urlsafe(32)
    ip, agent = _client_info()
    db.session.add(AdminSession(
        admin_id=admin.id, token_hash=_hash(token), ip=ip, user_agent=agent,
        expires_at=utcnow() + cfg["ADMIN_SESSION_LIFETIME"], last_seen_at=utcnow()))
    db.session.commit()
    _set_cookie(response, cfg["ADMIN_COOKIE_NAME"], token, cfg["ADMIN_SESSION_LIFETIME"])
    return response


def load_admin_from_token(token: str | None) -> AdminAccount | None:
    if not token or len(token) > 100:
        return None
    s = db.session.execute(
        db.select(AdminSession).where(AdminSession.token_hash == _hash(token))
    ).scalar_one_or_none()
    if not _valid(s, current_app.config["ADMIN_SESSION_IDLE_TIMEOUT"]):
        return None
    _touch(s)
    return s.admin


def end_admin_session(response):
    name = current_app.config["ADMIN_COOKIE_NAME"]
    token = request.cookies.get(name)
    if token:
        db.session.execute(db.update(AdminSession).where(AdminSession.token_hash == _hash(token))
                           .values(revoked=True))
        db.session.commit()
    response.delete_cookie(name, path="/")
    return response


# ---------------------------------------------------------------- per request
def init_sessions(app):
    @app.before_request
    def load_current_principal():
        g.user = g.admin = None
        g.user_session_id = None
        raw_device = request.cookies.get(app.config["DEVICE_COOKIE_NAME"], "")
        if _DEVICE_RE.match(raw_device):
            g.device_id, g.new_device = raw_device, False
        else:
            g.device_id, g.new_device = secrets.token_urlsafe(16), True
        if request.endpoint == "static":
            return
        s = _load_user_session(request.cookies.get(app.config["AUTH_COOKIE_NAME"]))
        if s is not None:
            g.user, g.user_session_id = s.user, s.id
        g.admin = load_admin_from_token(request.cookies.get(app.config["ADMIN_COOKIE_NAME"]))

    @app.after_request
    def ensure_device_cookie(response):
        if g.get("new_device") and request.endpoint != "static":
            response.set_cookie(app.config["DEVICE_COOKIE_NAME"], g.device_id,
                                max_age=60 * 60 * 24 * 730, httponly=True,
                                secure=app.config["SESSION_COOKIE_SECURE"], samesite="Lax",
                                path="/")
        return response
