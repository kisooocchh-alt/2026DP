"""Two-factor authentication with 6-digit codes from an authenticator app
(Google Authenticator, Microsoft Authenticator, 1Password ...).

A used code is remembered (its 30-second time step), so a stolen code cannot be
replayed. Users also get 8 one-time recovery codes; only their hashes are stored.
"""
import base64
import hashlib
import hmac
import io
import secrets
from datetime import datetime, timedelta, timezone

import pyotp
import qrcode

ISSUER = "DSEE5"
RECOVERY_CODE_COUNT = 8


def new_secret() -> str:
    return pyotp.random_base32()


def provisioning_uri(secret: str, username: str) -> str:
    return pyotp.TOTP(secret).provisioning_uri(name=username, issuer_name=ISSUER)


def qr_png(uri: str) -> bytes:
    img = qrcode.make(uri, box_size=6, border=2)
    buf = io.BytesIO()
    img.save(buf)
    return buf.getvalue()


def qr_data_uri(uri: str) -> str:
    return "data:image/png;base64," + base64.b64encode(qr_png(uri)).decode()


def verify(secret: str, code: str, last_timecode: int | None = None) -> int | None:
    """Check a 6-digit code (allowing 30 seconds of clock difference).

    Returns the code's time step to store as the new `last_timecode`, or None if the
    code is wrong or was already used.
    """
    digits = "".join(ch for ch in str(code or "") if ch.isdigit())
    if len(digits) != 6 or not secret:
        return None
    totp = pyotp.TOTP(secret)
    now = datetime.now(timezone.utc)
    for offset in (0, -1, 1):
        moment = now + timedelta(seconds=30 * offset)
        if hmac.compare_digest(totp.at(moment), digits):
            step = totp.timecode(moment)
            if last_timecode is not None and step <= last_timecode:
                return None
            return step
    return None


def _hash_recovery(code: str) -> str:
    cleaned = "".join(ch for ch in code.lower() if ch.isalnum())
    return hashlib.sha256(cleaned.encode()).hexdigest()


def new_recovery_codes() -> tuple[list[str], list[str]]:
    """Return (codes to show the user once, hashes to store)."""
    codes = []
    for _ in range(RECOVERY_CODE_COUNT):
        raw = secrets.token_hex(5)                     # 10 hex characters
        codes.append(f"{raw[:5]}-{raw[5:]}")
    return codes, [_hash_recovery(c) for c in codes]


def use_recovery_code(stored_hashes: list[str] | None, code: str) -> list[str] | None:
    """If `code` matches, return the remaining hashes (the code is used up); else None."""
    if not stored_hashes or not code:
        return None
    target = _hash_recovery(code)
    for h in stored_hashes:
        if hmac.compare_digest(h, target):
            return [x for x in stored_hashes if x != h]
    return None


def looks_like_recovery_code(code: str) -> bool:
    cleaned = "".join(ch for ch in str(code or "") if ch.isalnum())
    return len(cleaned) == 10
