"""Server-side checks for every piece of user input. The browser can be bypassed, so
the server always checks again.

Each check takes the raw value and returns a cleaned value, or raises FieldError.
Use Form to check many fields and report all problems at once:

    form = Form(data)
    name = form.field("username", username)
    form.raise_if_errors()          # -> ValidationError({"username": "username_taken"})
"""
import re
import unicodedata
from urllib.parse import urlparse

from .. import constants as C
from ..utils.time_utils import hk_today, parse_datetime

_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f​-‏‪-‮⁦-⁩]")
_EMAIL = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}\.[A-Za-z]{2,24}$")
_USERNAME = re.compile(C.USERNAME_PATTERN)


class FieldError(Exception):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


class ValidationError(Exception):
    def __init__(self, fields: dict[str, str], code: str = "validation_failed"):
        super().__init__(code)
        self.fields = fields
        self.code = code


class Form:
    def __init__(self, data: dict | None):
        self.data = data if isinstance(data, dict) else {}
        self.errors: dict[str, str] = {}

    def field(self, name: str, check, *args, **kwargs):
        try:
            return check(self.data.get(name), *args, **kwargs)
        except FieldError as e:
            self.errors.setdefault(name, e.code)
            return None

    def has(self, name: str) -> bool:
        return name in self.data

    def raise_if_errors(self) -> None:
        if self.errors:
            raise ValidationError(self.errors)


# ------------------------------------------------------------------ text
def clean_text(value, max_len: int, *, multiline: bool = False) -> str:
    """Strip spaces, remove control characters, normalise Unicode, cut to max_len."""
    if value is None:
        return ""
    if not isinstance(value, str):
        value = str(value)
    value = unicodedata.normalize("NFC", value)
    if multiline:
        value = value.replace("\r\n", "\n").replace("\r", "\n")
        value = "\n".join(_CONTROL.sub("", line).rstrip() for line in value.split("\n"))
        value = re.sub(r"\n{3,}", "\n\n", value)
    else:
        value = _CONTROL.sub("", value.replace("\n", " ").replace("\t", " "))
        value = re.sub(r"\s{2,}", " ", value)
    return value.strip()[:max_len]


def text(value, *, max_len: int, required: bool = False, multiline: bool = False,
         code: str = "required") -> str:
    cleaned = clean_text(value, max_len, multiline=multiline)
    if required and not cleaned:
        raise FieldError(code)
    return cleaned


def optional_text(value, *, max_len: int, multiline: bool = False) -> str | None:
    cleaned = clean_text(value, max_len, multiline=multiline)
    return cleaned or None


# ------------------------------------------------------------------ identity
def username(value) -> str:
    name = clean_text(value, 40)
    if not _USERNAME.match(name):
        raise FieldError("username_invalid")
    if name.lower() in C.RESERVED_USERNAMES:
        raise FieldError("username_taken")
    return name


def email(value, *, required: bool = False) -> str | None:
    cleaned = clean_text(value, 120).lower()
    if not cleaned:
        if required:
            raise FieldError("email_invalid")
        return None
    if not _EMAIL.match(cleaned):
        raise FieldError("email_invalid")
    return cleaned


def birth_year(value) -> int:
    year = integer(value, min_value=hk_today().year - 90, max_value=hk_today().year - 10,
                   code="birth_year_invalid")
    return year


# ------------------------------------------------------------------ choices
def choice(value, allowed, *, code: str = "choice_invalid", required: bool = True):
    if value in (None, "") and not required:
        return None
    if value not in allowed:
        raise FieldError(code)
    return value


def boolean(value) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on"}
    return bool(value)


def integer(value, *, min_value: int | None = None, max_value: int | None = None,
            code: str = "number_invalid", required: bool = True) -> int | None:
    if value in (None, "") and not required:
        return None
    if isinstance(value, bool):
        raise FieldError(code)
    try:
        number = int(str(value).strip())
    except (TypeError, ValueError):
        raise FieldError(code) from None
    if (min_value is not None and number < min_value) or \
            (max_value is not None and number > max_value):
        raise FieldError(code)
    return number


def subject_code(value) -> str:
    code = clean_text(value, 10).upper()
    if code not in C.SUBJECT_CODES:
        raise FieldError("subject_invalid")
    return code


def subject_list(value, *, min_count: int = 0,
                 max_count: int = C.MAX_SUBJECTS_PER_USER) -> list[str]:
    if value in (None, ""):
        value = []
    if not isinstance(value, list):
        raise FieldError("subject_invalid")
    codes: list[str] = []
    for item in value:
        code = subject_code(item)
        if code not in codes:
            codes.append(code)
    if len(codes) < min_count:
        raise FieldError("subjects_required")
    if len(codes) > max_count:
        raise FieldError("too_many_subjects")
    return codes


def grade(value) -> str:
    cleaned = clean_text(value, 20)
    if cleaned not in C.DSE_GRADES:
        raise FieldError("grade_invalid")
    return cleaned


def dse_results(value, *, required: bool = False) -> list[dict]:
    if value in (None, ""):
        value = []
    if not isinstance(value, list) or len(value) > C.MAX_SUBJECTS_PER_USER:
        raise FieldError("dse_results_invalid")
    results, seen = [], set()
    for row in value:
        if not isinstance(row, dict):
            raise FieldError("dse_results_invalid")
        code = subject_code(row.get("subject"))
        if code in seen:
            continue
        seen.add(code)
        results.append({"subject": code, "grade": grade(row.get("grade"))})
    if required and not results:
        raise FieldError("dse_results_required")
    return results


def wage(value, *, required: bool = False) -> int | None:
    return integer(value, min_value=C.MIN_WAGE, max_value=C.MAX_WAGE, code="wage_invalid",
                   required=required)


def visibility(value) -> str:
    return choice(value, C.VISIBILITY, code="visibility_invalid")


def url(value, allowed_hosts=C.ALLOWED_VIDEO_HOSTS) -> str:
    cleaned = clean_text(value, 500)
    parsed = urlparse(cleaned)
    if parsed.scheme != "https" or (parsed.hostname or "").lower() not in allowed_hosts:
        raise FieldError("url_invalid")
    return cleaned


def hk_datetime(value):
    try:
        return parse_datetime(str(value or ""))
    except (TypeError, ValueError):
        raise FieldError("datetime_invalid") from None


def id_list(value, *, max_count: int = 200) -> list[int]:
    if value in (None, ""):
        return []
    if not isinstance(value, list) or len(value) > max_count:
        raise FieldError("ids_invalid")
    return [integer(v, min_value=1, code="ids_invalid") for v in value]
