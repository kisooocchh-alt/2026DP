"""Password hashing (Argon2id) and password rules."""
from pathlib import Path

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError

_ph = PasswordHasher()                          # safe Argon2id defaults
_COMMON = {
    line.strip().lower()
    for line in (Path(__file__).parents[1] / "data" / "common_passwords.txt")
    .read_text(encoding="utf-8").splitlines()
    if line.strip() and not line.startswith("#")
}
DUMMY_HASH = _ph.hash("not-a-real-password")    # checked when the username does not exist

MIN_LENGTH = 10
ADMIN_MIN_LENGTH = 16
MAX_LENGTH = 128


def hash_password(plain: str) -> str:
    return _ph.hash(plain)


def verify_password(stored_hash: str, plain: str) -> bool:
    """Never raises: any problem simply means 'wrong password'."""
    try:
        return _ph.verify(stored_hash, plain)
    except (VerificationError, InvalidHashError, TypeError):
        return False


def needs_rehash(stored_hash: str) -> bool:
    try:
        return _ph.check_needs_rehash(stored_hash)
    except InvalidHashError:
        return True


def password_problems(pw: str, username: str = "", min_length: int = MIN_LENGTH) -> list[str]:
    """Return error codes. An empty list means the password is acceptable."""
    if not isinstance(pw, str):
        return ["password_too_short"]
    problems = []
    if len(pw) < min_length:
        problems.append("password_too_short")
    if len(pw) > MAX_LENGTH:
        problems.append("password_too_long")
    if not any(c.isalpha() for c in pw) or not any(c.isdigit() for c in pw):
        problems.append("password_needs_letter_and_number")
    lowered = pw.lower()
    if lowered in _COMMON or (username and len(username) >= 3 and username.lower() in lowered):
        problems.append("password_too_common")
    return problems
