"""Rate-limit rules in one place. Use with @limiter.limit(RULE, key_func=user_key).

Chat messages travel over Socket.IO, which Flask-Limiter does not see; they are
limited in security/abuse_detector.py instead.
"""
from flask import current_app, g, request
from flask_limiter.util import get_remote_address

from ..extensions import limiter

# Login and sign-up are limited per IP. Students at one school often share a single IP,
# so these allow a whole class; guessing is stopped by the per-account lock, the
# failed-login IP block and the CAPTCHA (security/abuse_detector.py, auth_service.py),
# and successful sign-ups per IP are capped by SIGNUP_LIMIT_PER_IP.
REGISTER = "10 per hour; 50 per day"
LOGIN = "20 per minute; 200 per hour"
ADMIN_LOGIN = "5 per 15 minutes"
PASSWORD_CHANGE = "5 per hour"
TWO_FACTOR = "10 per 10 minutes"
CHAT_IMAGE = "20 per hour"
AVATAR_UPLOAD = "10 per hour"
PAPER_DOWNLOAD = "60 per hour"
REPORT = "20 per day"
BOOKING = "10 per day"
SEARCH = "30 per minute"
GENERAL_API = "120 per minute"


def user_key() -> str:
    """Limit logged-in actions per user, not per IP: students at one school often
    share a single IP address."""
    user = g.get("user")
    return f"user:{user.id}" if user is not None else get_remote_address()


def is_trusted_localhost() -> bool:
    """In development (TRUST_LOCALHOST=true) your own computer is never limited or
    auto-blocked, so testing does not lock you out."""
    return bool(current_app.config.get("TRUST_LOCALHOST")) and \
        request.remote_addr in ("127.0.0.1", "::1")


def init_rate_limit_filters(app) -> None:
    limiter.request_filter(is_trusted_localhost)
