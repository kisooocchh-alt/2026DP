"""Decorators that protect routes. Put them directly under @bp.get / @bp.post."""
from functools import wraps

from flask import abort, current_app, g, request

from ..utils.responses import error


def login_required(view):
    @wraps(view)
    def wrapper(*args, **kwargs):
        if g.get("user") is None:
            return error("login_required", 401)
        return view(*args, **kwargs)
    return wrapper


def role_required(*roles):
    """@role_required("tutor") - only tutors may call this route."""
    def decorator(view):
        @wraps(view)
        @login_required
        def wrapper(*args, **kwargs):
            if g.user.role not in roles:
                return error("forbidden", 403)
            return view(*args, **kwargs)
        return wrapper
    return decorator


def admin_ip_allowed() -> bool:
    allow = current_app.config["ADMIN_IP_ALLOWLIST"]
    return not allow or request.remote_addr in allow


def admin_required(view):
    """Non-admins get a normal 404, so the admin area looks like it does not exist."""
    @wraps(view)
    def wrapper(*args, **kwargs):
        if g.get("admin") is None or not admin_ip_allowed():
            abort(404)
        return view(*args, **kwargs)
    return wrapper
