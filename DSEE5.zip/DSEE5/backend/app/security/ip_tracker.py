"""The IP tracking system: records who did what, from where, and rejects blocked IPs.

IP location uses the free MaxMind GeoLite2 City database (country and city only).
Put GeoLite2-City.mmdb in backend/instance/. Without it, location is simply blank.
"""
import functools
import ipaddress
import logging
import re
import threading
import time

from flask import current_app, g, has_request_context, jsonify, request, send_from_directory

from ..extensions import db
from ..models.security_log import ActivityLog, BlockedIP

log = logging.getLogger(__name__)

_cache_lock = threading.Lock()
_blocked_cache: dict = {"at": None, "ips": frozenset()}     # at=None means "reload now"
_BLOCK_CACHE_SECONDS = 60

_geo_lock = threading.Lock()
_geo_reader = None
_geo_path = None

# Requests for these paths only come from automated attack scanners.
PROBE_PATTERN = re.compile(
    r"^/(wp-admin|wp-login\.php|wp-content|xmlrpc\.php|\.env|\.git|\.aws|\.ssh|phpmyadmin|pma/|"
    r"myadmin|admin\.php|config\.php|cgi-bin|vendor/phpunit|boaform|hnap1|actuator|"
    r"server-status|shell|solr/|owa/|autodiscover|_ignition)", re.IGNORECASE)


def client_ip() -> str:
    """The visitor's IP. Correct behind nginx because ProxyFix is applied in production."""
    return (request.remote_addr or "0.0.0.0") if has_request_context() else "0.0.0.0"


# ------------------------------------------------------------ IP location
def _reader():
    global _geo_reader, _geo_path
    path = current_app.config["GEOIP_DB_PATH"]
    with _geo_lock:
        if _geo_reader is not None and _geo_path == path:
            return _geo_reader
        if not path.exists():
            return None
        try:
            import geoip2.database  # imported lazily: optional at development time
            _geo_reader, _geo_path = geoip2.database.Reader(str(path)), path
        except Exception:  # noqa: BLE001 - a broken database must never break requests
            log.exception("Could not open the GeoIP database at %s", path)
            return None
        return _geo_reader


@functools.lru_cache(maxsize=4096)
def _geo_cached(ip: str, path_key: str) -> tuple[str | None, str | None]:
    reader = _reader()
    if reader is None:
        return None, None
    try:
        record = reader.city(ip)
        return record.country.name, record.city.name
    except Exception:  # noqa: BLE001 - address not in the database
        return None, None


def geo_lookup(ip: str | None) -> tuple[str | None, str | None]:
    """(country, city) for an IP, or (None, None)."""
    if not ip:
        return None, None
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return None, None
    if addr.is_private or addr.is_loopback or addr.is_link_local:
        return "Local network", None
    return _geo_cached(ip, str(current_app.config["GEOIP_DB_PATH"]))


# ------------------------------------------------------------ activity log
_DEVICE_ID = re.compile(r"^[A-Za-z0-9_-]{16,64}$")


def _device_id() -> str | None:
    """The browser's device id. Socket.IO events skip before_request, so fall back to
    reading (and checking) the cookie directly."""
    device = g.get("device_id") or request.cookies.get(current_app.config["DEVICE_COOKIE_NAME"])
    return device if device and _DEVICE_ID.match(device) else None


def log_activity(action: str, *, user_id: int | None = None, admin_id: int | None = None,
                 success: bool = True, meta: dict | None = None, ip: str | None = None,
                 commit: bool = True) -> ActivityLog:
    """Record an important action with IP, device id, user agent and location."""
    ip = ip or client_ip()
    country, city = geo_lookup(ip)
    entry = ActivityLog(
        action=action[:40], user_id=user_id, admin_id=admin_id, ip=ip,
        user_agent=(request.headers.get("User-Agent") or "")[:255] if has_request_context()
        else None,
        device_id=_device_id() if has_request_context() else None,
        country=country, city=city, success=success, meta=meta or None)
    db.session.add(entry)
    if commit:
        db.session.commit()
    return entry


# ------------------------------------------------------------ blocked IPs
def blocked_ips() -> frozenset:
    now = time.monotonic()
    with _cache_lock:
        at = _blocked_cache["at"]
        # Never compare with 0: time.monotonic() starts near 0 when the server boots.
        if at is None or now - at > _BLOCK_CACHE_SECONDS:
            _blocked_cache["ips"] = frozenset(BlockedIP.active_ips())
            _blocked_cache["at"] = now
        return _blocked_cache["ips"]


def is_ip_blocked(ip: str) -> bool:
    return ip in blocked_ips()


def invalidate_block_cache() -> None:
    with _cache_lock:
        _blocked_cache["at"] = None


def init_ip_guard(app):
    @app.before_request
    def guard():
        ip = client_ip()
        if is_ip_blocked(ip):
            if request.path.startswith("/api/"):
                return jsonify(ok=False, error="ip_blocked"), 403
            return "Access from your network has been blocked. Contact DSEE5 support.", 403
        if PROBE_PATTERN.match(request.path):
            from . import abuse_detector  # local import avoids a cycle
            log_activity("security.probe", success=False, meta={"path": request.path[:200]})
            abuse_detector.record_probe(ip)
            return send_from_directory(app.static_folder, "pages/404.html"), 404
        return None
