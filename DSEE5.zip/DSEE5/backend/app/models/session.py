"""Server-side login sessions. The browser only holds a random token; we store its
SHA-256 hash, so sessions can be listed, ended remotely, or cut off instantly."""
from ..extensions import db
from ..utils.time_utils import iso_utc, utcnow


class UserSession(db.Model):
    __tablename__ = "user_sessions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    token_hash = db.Column(db.String(64), unique=True, nullable=False, index=True)
    ip = db.Column(db.String(45))
    user_agent = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    last_seen_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False, index=True)
    revoked = db.Column(db.Boolean, default=False, nullable=False)

    user = db.relationship("User")

    def to_dict(self, current_id: int | None = None) -> dict:
        return {"id": self.id, "ip": self.ip, "user_agent": self.user_agent or "",
                "created_at": iso_utc(self.created_at),
                "last_seen_at": iso_utc(self.last_seen_at),
                "current": self.id == current_id}


class AdminSession(db.Model):
    __tablename__ = "admin_sessions"

    id = db.Column(db.Integer, primary_key=True)
    admin_id = db.Column(db.ForeignKey("admin_accounts.id", ondelete="CASCADE"), nullable=False,
                         index=True)
    token_hash = db.Column(db.String(64), unique=True, nullable=False, index=True)
    ip = db.Column(db.String(45))
    user_agent = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    last_seen_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)
    revoked = db.Column(db.Boolean, default=False, nullable=False)

    admin = db.relationship("AdminAccount")
