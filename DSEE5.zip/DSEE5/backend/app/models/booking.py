"""Booking requests: a student asks a tutor for lessons outside the public chat."""
from ..extensions import db
from ..utils.time_utils import iso_utc, utcnow


class BookingRequest(db.Model):
    __tablename__ = "booking_requests"

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False,
                           index=True)
    tutor_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    subject_code = db.Column(db.ForeignKey("subjects.code"), nullable=False)
    message = db.Column(db.Text, nullable=False, default="")
    preferred_times = db.Column(db.String(200))
    # pending | accepted | declined | cancelled | completed
    status = db.Column(db.String(12), default="pending", nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    responded_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)

    student = db.relationship("User", foreign_keys=[student_id], lazy="joined")
    tutor = db.relationship("User", foreign_keys=[tutor_id], lazy="joined")
    rating = db.relationship("TutorRating", uselist=False, back_populates="booking")

    def to_dict(self, viewer_id: int) -> dict:
        is_student = viewer_id == self.student_id
        other = self.tutor if is_student else self.student
        return {
            "id": self.id, "status": self.status, "subject": self.subject_code,
            "message": self.message, "preferred_times": self.preferred_times or "",
            "created_at": iso_utc(self.created_at), "responded_at": iso_utc(self.responded_at),
            "completed_at": iso_utc(self.completed_at),
            "student": self.student.mini_dict(), "tutor": self.tutor.mini_dict(),
            "my_role": "student" if is_student else "tutor",
            # Contact details are shared only after the tutor accepts.
            "other_contact": (other.contact or "") if self.status in ("accepted", "completed")
            else None,
            "rated": self.rating is not None,
            "can_rate": is_student and self.status == "completed" and self.rating is None,
        }
