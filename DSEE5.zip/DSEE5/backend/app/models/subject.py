"""HKDSE subjects. Chat rooms, papers, materials, quizzes and countdown events all
refer to a subject code such as "MATH" or "CSD"."""
from ..extensions import db


class Subject(db.Model):
    __tablename__ = "subjects"

    code = db.Column(db.String(10), primary_key=True)
    name_en = db.Column(db.String(120), nullable=False)
    name_zh = db.Column(db.String(60), nullable=False)
    category = db.Column(db.String(10), nullable=False)        # core | extended | elective
    sort_order = db.Column(db.Integer, default=0, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)

    def to_dict(self) -> dict:
        return {"code": self.code, "name_en": self.name_en, "name_zh": self.name_zh,
                "category": self.category}

    def __repr__(self) -> str:
        return f"<Subject {self.code}>"
