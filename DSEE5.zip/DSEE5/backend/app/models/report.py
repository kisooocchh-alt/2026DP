"""User reports about messages or profiles - the admin moderation queue."""
from ..extensions import db
from ..utils.time_utils import iso_utc, utcnow


class Report(db.Model):
    __tablename__ = "reports"
    __table_args__ = (db.UniqueConstraint("reporter_id", "target_type", "target_id",
                                          name="uq_reports_reporter_target"),)

    id = db.Column(db.Integer, primary_key=True)
    reporter_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    target_type = db.Column(db.String(10), nullable=False)          # message | user
    target_id = db.Column(db.Integer, nullable=False)
    reason = db.Column(db.String(30), nullable=False)
    details = db.Column(db.Text)
    status = db.Column(db.String(10), default="open", nullable=False, index=True)
    action_taken = db.Column(db.String(30))
    handled_by = db.Column(db.ForeignKey("admin_accounts.id", ondelete="SET NULL"))
    handled_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    reporter = db.relationship("User", foreign_keys=[reporter_id])

    def to_dict(self) -> dict:
        return {"id": self.id, "target_type": self.target_type, "target_id": self.target_id,
                "reason": self.reason, "details": self.details or "", "status": self.status,
                "action_taken": self.action_taken, "created_at": iso_utc(self.created_at),
                "reporter": self.reporter.mini_dict() if self.reporter else None}
