"""Messages in the subject chat rooms, their images, and pinned messages."""
from ..extensions import db
from ..utils.time_utils import iso_utc, utcnow


class Message(db.Model):
    __tablename__ = "messages"
    __table_args__ = (db.Index("ix_messages_subject_id", "subject_code", "id"),)

    id = db.Column(db.Integer, primary_key=True)
    subject_code = db.Column(db.ForeignKey("subjects.code"), nullable=False, index=True)
    user_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    text = db.Column(db.Text, nullable=False, default="")
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False, index=True)
    is_deleted = db.Column(db.Boolean, default=False, nullable=False)
    deleted_by = db.Column(db.ForeignKey("admin_accounts.id", ondelete="SET NULL"))
    delete_reason = db.Column(db.String(200))
    deleted_at = db.Column(db.DateTime)
    is_hidden = db.Column(db.Boolean, default=False, nullable=False)    # auto-hidden by reports
    report_count = db.Column(db.Integer, default=0, nullable=False)

    user = db.relationship("User", lazy="joined")
    image = db.relationship("ChatImage", uselist=False, back_populates="message", lazy="joined")

    @property
    def visible(self) -> bool:
        return not (self.is_deleted or self.is_hidden)

    def to_dict(self, viewer_id: int | None = None, for_admin: bool = False) -> dict:
        show = self.visible or for_admin
        data = {
            "id": self.id,
            "subject": self.subject_code,
            "text": self.text if show else None,
            "image_url": (f"/api/chat/images/{self.image.file_name}"
                          if self.image and show else None),
            "deleted": self.is_deleted,
            "hidden": self.is_hidden and not self.is_deleted,
            "created_at": iso_utc(self.created_at),
            "user": self.user.mini_dict(),
            "is_mine": viewer_id is not None and viewer_id == self.user_id,
        }
        if for_admin:
            data.update(report_count=self.report_count, delete_reason=self.delete_reason,
                        shadow_banned=self.user.is_shadow_banned,
                        image_file=self.image.file_name if self.image else None)
        return data


class ChatImage(db.Model):
    __tablename__ = "chat_images"

    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    file_name = db.Column(db.String(64), unique=True, nullable=False)
    width = db.Column(db.Integer)
    height = db.Column(db.Integer)
    message_id = db.Column(db.ForeignKey("messages.id", ondelete="CASCADE"), unique=True)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    message = db.relationship("Message", back_populates="image")


class PinnedMessage(db.Model):
    __tablename__ = "pinned_messages"

    id = db.Column(db.Integer, primary_key=True)
    subject_code = db.Column(db.ForeignKey("subjects.code"), nullable=False, index=True)
    message_id = db.Column(db.ForeignKey("messages.id", ondelete="CASCADE"), unique=True,
                           nullable=False)
    pinned_by = db.Column(db.ForeignKey("admin_accounts.id", ondelete="SET NULL"))
    pinned_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    message = db.relationship("Message")
