"""The IP tracking system: who did what, from where, plus blocked IP addresses."""
from sqlalchemy import or_

from ..extensions import db
from ..utils.time_utils import iso_utc, utcnow


class ActivityLog(db.Model):
    __tablename__ = "activity_logs"
    __table_args__ = (db.Index("ix_activity_logs_action_created", "action", "created_at"),)

    id = db.Column(db.Integer, primary_key=True)
    # e.g. auth.login, auth.register, chat.message, upload.image, admin.delete_message
    action = db.Column(db.String(40), nullable=False, index=True)
    user_id = db.Column(db.Integer, index=True)          # plain ints: logs outlive accounts
    admin_id = db.Column(db.Integer, index=True)
    ip = db.Column(db.String(45), index=True)
    user_agent = db.Column(db.String(255))
    device_id = db.Column(db.String(64), index=True)
    country = db.Column(db.String(60))
    city = db.Column(db.String(80))
    success = db.Column(db.Boolean, default=True, nullable=False)
    meta = db.Column(db.JSON)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False, index=True)

    def to_dict(self) -> dict:
        return {"id": self.id, "action": self.action, "user_id": self.user_id,
                "admin_id": self.admin_id, "ip": self.ip, "device_id": self.device_id,
                "country": self.country, "city": self.city, "success": self.success,
                "meta": self.meta or {}, "user_agent": self.user_agent or "",
                "created_at": iso_utc(self.created_at)}


class BlockedIP(db.Model):
    __tablename__ = "blocked_ips"

    id = db.Column(db.Integer, primary_key=True)
    ip = db.Column(db.String(45), unique=True, nullable=False, index=True)
    reason = db.Column(db.String(200), nullable=False)
    created_by = db.Column(db.String(40), nullable=False)       # "auto" or "admin:<id>"
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    expires_at = db.Column(db.DateTime)                          # empty = permanent

    @classmethod
    def active_ips(cls) -> set[str]:
        now = utcnow()
        rows = db.session.execute(
            db.select(cls.ip).where(or_(cls.expires_at.is_(None), cls.expires_at > now))
        ).scalars()
        return set(rows)

    @property
    def is_active(self) -> bool:
        return self.expires_at is None or self.expires_at > utcnow()

    def to_dict(self) -> dict:
        return {"id": self.id, "ip": self.ip, "reason": self.reason,
                "created_by": self.created_by, "created_at": iso_utc(self.created_at),
                "expires_at": iso_utc(self.expires_at), "active": self.is_active}
