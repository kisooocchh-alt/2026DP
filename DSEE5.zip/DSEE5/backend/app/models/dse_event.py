"""Dates for the DSE countdown, and which subjects each user follows."""
from ..extensions import db
from ..utils.time_utils import iso_hk, utcnow


class DseEvent(db.Model):
    __tablename__ = "dse_events"

    id = db.Column(db.Integer, primary_key=True)
    title_en = db.Column(db.String(160), nullable=False)
    title_zh = db.Column(db.String(160), nullable=False)
    subject_code = db.Column(db.ForeignKey("subjects.code"), index=True)  # empty = general date
    # exam | results | registration | other
    kind = db.Column(db.String(12), nullable=False, default="exam")
    starts_at = db.Column(db.DateTime, nullable=False, index=True)   # naive UTC
    is_published = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    def to_dict(self) -> dict:
        return {"id": self.id, "title_en": self.title_en, "title_zh": self.title_zh,
                "subject": self.subject_code, "kind": self.kind,
                "starts_at": iso_hk(self.starts_at), "is_published": self.is_published}


class CountdownFollow(db.Model):
    """A user follows the exam dates of the subjects they actually take."""
    __tablename__ = "countdown_follows"

    user_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    subject_code = db.Column(db.ForeignKey("subjects.code"), primary_key=True)
