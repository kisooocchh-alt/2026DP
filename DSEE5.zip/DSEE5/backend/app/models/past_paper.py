"""Past papers, organised by subject and year. Only the admin uploads or deletes them."""
from ..extensions import db
from ..utils.time_utils import iso_utc, utcnow


class PastPaper(db.Model):
    __tablename__ = "past_papers"
    __table_args__ = (
        db.UniqueConstraint("subject_code", "year", "paper", "language",
                            name="uq_past_papers_subject_year_paper_language"),
    )

    id = db.Column(db.Integer, primary_key=True)
    subject_code = db.Column(db.ForeignKey("subjects.code"), nullable=False, index=True)
    year = db.Column(db.Integer, nullable=False, index=True)
    paper = db.Column(db.String(30), nullable=False)               # "Paper 1", "Paper 2" ...
    language = db.Column(db.String(5), nullable=False, default="en")   # en | zh
    file_name = db.Column(db.String(64), nullable=False)           # random name in storage/papers
    file_size = db.Column(db.Integer, default=0, nullable=False)
    marking_file = db.Column(db.String(64))                         # marking scheme (optional)
    marking_size = db.Column(db.Integer)
    uploaded_by = db.Column(db.ForeignKey("admin_accounts.id", ondelete="SET NULL"))
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    download_count = db.Column(db.Integer, default=0, nullable=False)

    subject = db.relationship("Subject")

    @property
    def download_name(self) -> str:
        label = self.paper.replace(" ", "").replace("Paper", "P")
        return f"DSE-{self.year}-{self.subject_code}-{label}-{self.language}.pdf"

    def to_dict(self) -> dict:
        return {
            "id": self.id, "subject": self.subject_code, "year": self.year,
            "paper": self.paper, "language": self.language, "file_size": self.file_size,
            "has_marking": bool(self.marking_file), "downloads": self.download_count,
            "created_at": iso_utc(self.created_at),
        }
