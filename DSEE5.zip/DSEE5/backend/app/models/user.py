"""Users (students and tutors) and their extra profile data.

What OTHER people may see is decided in services/privacy_service.py - never send
these objects to the browser directly.
"""
from .. import constants as C
from ..extensions import db
from ..utils.time_utils import hk_today, iso_utc, utcnow

DEFAULT_AVATAR = "/assets/images/default-avatar.svg"

user_subjects = db.Table(
    "user_subjects",
    db.Column("user_id", db.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    db.Column("subject_code", db.ForeignKey("subjects.code"), primary_key=True),
)


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False, index=True)
    username_lower = db.Column(db.String(20), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(10), nullable=False, index=True)    # "student" | "tutor"

    display_name = db.Column(db.String(40))
    birth_year = db.Column(db.Integer)                            # age is calculated
    gender = db.Column(db.String(20))
    bio = db.Column(db.Text)                                      # self-introduction
    contact = db.Column(db.String(120))
    avatar_file = db.Column(db.String(64))                        # random name in storage/avatars
    language = db.Column(db.String(5), default="en", nullable=False)
    guardian_email = db.Column(db.String(120))                    # optional, for under-18 users

    # Privacy: "everyone" | "members" | "nobody"
    show_age = db.Column(db.String(10), default="members", nullable=False)
    show_school = db.Column(db.String(10), default="members", nullable=False)
    show_contact = db.Column(db.String(10), default="nobody", nullable=False)

    score = db.Column(db.Integer, default=C.SIGNUP_BONUS, nullable=False)
    lifetime_points = db.Column(db.Integer, default=C.SIGNUP_BONUS, nullable=False)
    login_streak = db.Column(db.Integer, default=0, nullable=False)
    last_daily_claim = db.Column(db.Date)

    totp_secret = db.Column(db.String(64))                        # only if the user turns on 2FA
    totp_last_timecode = db.Column(db.Integer)                    # stops a code being reused
    recovery_codes = db.Column(db.JSON)                           # SHA-256 hashes, one-time use

    is_blocked = db.Column(db.Boolean, default=False, nullable=False, index=True)
    blocked_reason = db.Column(db.String(200))
    is_shadow_banned = db.Column(db.Boolean, default=False, nullable=False)
    muted_until = db.Column(db.DateTime)
    failed_logins = db.Column(db.Integer, default=0, nullable=False)
    locked_until = db.Column(db.DateTime)
    last_login_at = db.Column(db.DateTime)
    last_login_ip = db.Column(db.String(45))
    is_deleted = db.Column(db.Boolean, default=False, nullable=False)
    deleted_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    subjects = db.relationship("Subject", secondary=user_subjects, lazy="selectin",
                               order_by="Subject.sort_order")
    student_profile = db.relationship("StudentProfile", uselist=False, back_populates="user",
                                      cascade="all, delete-orphan", lazy="joined")
    tutor_profile = db.relationship("TutorProfile", uselist=False, back_populates="user",
                                    cascade="all, delete-orphan", lazy="joined")

    # ---- calculated values ----
    @property
    def age(self) -> int | None:
        return hk_today().year - self.birth_year if self.birth_year else None

    @property
    def is_minor(self) -> bool:
        return self.age is not None and self.age < C.MINOR_AGE

    @property
    def name(self) -> str:
        return self.display_name or self.username

    @property
    def avatar_url(self) -> str:
        return f"/api/files/avatar/{self.avatar_file}" if self.avatar_file else DEFAULT_AVATAR

    @property
    def is_verified_tutor(self) -> bool:
        return self.role == "tutor" and bool(self.tutor_profile and self.tutor_profile.is_verified)

    @property
    def is_muted(self) -> bool:
        return bool(self.muted_until and self.muted_until > utcnow())

    # ---- output ----
    def mini_dict(self) -> dict:
        """The small public card used in chat, bookings and ratings."""
        if self.is_deleted:
            return {"id": self.id, "username": None, "display_name": None,
                    "avatar_url": DEFAULT_AVATAR, "role": self.role, "verified": False,
                    "deleted": True}
        return {"id": self.id, "username": self.username, "display_name": self.name,
                "avatar_url": self.avatar_url, "role": self.role,
                "verified": self.is_verified_tutor}

    def to_private_dict(self) -> dict:
        """What the owner sees about themselves. Never includes secrets."""
        data = {
            "id": self.id, "username": self.username, "role": self.role,
            "display_name": self.name, "birth_year": self.birth_year, "age": self.age,
            "is_minor": self.is_minor, "gender": self.gender, "bio": self.bio or "",
            "contact": self.contact or "", "language": self.language,
            "guardian_email": self.guardian_email or "", "avatar_url": self.avatar_url,
            "score": self.score, "lifetime_points": self.lifetime_points,
            "login_streak": self.login_streak,
            "subjects": [s.code for s in self.subjects],
            "privacy": {"age": self.show_age, "school": self.show_school,
                        "contact": self.show_contact},
            "has_2fa": bool(self.totp_secret),
            "recovery_codes_left": len(self.recovery_codes or []),
            "muted_until": iso_utc(self.muted_until) if self.is_muted else None,
            "created_at": iso_utc(self.created_at),
            "student": None, "tutor": None,
        }
        if self.role == "student" and self.student_profile:
            data["student"] = self.student_profile.to_dict()
        if self.role == "tutor" and self.tutor_profile:
            data["tutor"] = self.tutor_profile.to_dict(include_private=True)
        return data

    def __repr__(self) -> str:
        return f"<User {self.username} ({self.role})>"


class StudentProfile(db.Model):
    __tablename__ = "student_profiles"

    user_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    dse_goal = db.Column(db.String(120), nullable=False)        # e.g. "5** Maths, HKU Medicine"
    school = db.Column(db.String(120), nullable=False)
    exam_year = db.Column(db.Integer)

    user = db.relationship("User", back_populates="student_profile")

    def to_dict(self) -> dict:
        return {"dse_goal": self.dse_goal, "school": self.school, "exam_year": self.exam_year}


class TutorProfile(db.Model):
    __tablename__ = "tutor_profiles"

    user_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    hourly_wage = db.Column(db.Integer)                           # HKD per hour
    short_description = db.Column(db.String(200))
    dse_results = db.Column(db.JSON, default=list)   # [{"subject": "MATH", "grade": "5**"}]
    certificate_file = db.Column(db.String(64))                   # private, admin-only
    certificate_uploaded_at = db.Column(db.DateTime)
    is_verified = db.Column(db.Boolean, default=False, nullable=False, index=True)
    verified_at = db.Column(db.DateTime)
    rating_avg = db.Column(db.Float, default=0, nullable=False)
    rating_count = db.Column(db.Integer, default=0, nullable=False)
    students_helped = db.Column(db.Integer, default=0, nullable=False)

    user = db.relationship("User", back_populates="tutor_profile")

    @property
    def certificate_status(self) -> str:
        if self.is_verified:
            return "verified"
        return "pending" if self.certificate_file else "none"

    def to_dict(self, include_private: bool = False) -> dict:
        data = {
            "hourly_wage": self.hourly_wage,
            "short_description": self.short_description or "",
            "dse_results": self.dse_results or [],
            "is_verified": self.is_verified,
            "rating_avg": round(self.rating_avg or 0, 2),
            "rating_count": self.rating_count,
            "students_helped": self.students_helped,
        }
        if include_private:
            data["certificate_status"] = self.certificate_status
        return data
