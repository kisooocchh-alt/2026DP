"""A full history of every point earned or spent, so scores can be checked."""
from ..extensions import db
from ..utils.time_utils import iso_utc, utcnow


class ScoreTransaction(db.Model):
    __tablename__ = "score_transactions"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    amount = db.Column(db.Integer, nullable=False)                # + earned / - spent
    # signup_bonus | daily_reward | quiz | test | exam | chat_message | penalty | admin_adjust
    reason = db.Column(db.String(20), nullable=False, index=True)
    ref_id = db.Column(db.Integer)
    note = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False, index=True)

    def to_dict(self) -> dict:
        return {"id": self.id, "amount": self.amount, "reason": self.reason,
                "note": self.note or "", "created_at": iso_utc(self.created_at)}


class DailyClaim(db.Model):
    """One row per user per Hong Kong day. The unique constraint makes a second
    claim on the same day impossible, even if two requests arrive at once."""
    __tablename__ = "daily_claims"
    __table_args__ = (db.UniqueConstraint("user_id", "claim_date",
                                          name="uq_daily_claims_user_date"),)

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    claim_date = db.Column(db.Date, nullable=False)
    amount = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
