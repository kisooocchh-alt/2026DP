"""Import every model so Flask-Migrate can see all tables."""
from .admin import AdminAccount
from .booking import BookingRequest
from .bookmark import Bookmark
from .chat import ChatImage, Message, PinnedMessage
from .dse_event import CountdownFollow, DseEvent
from .material import Material
from .notification import Notification, PushSubscription
from .past_paper import PastPaper
from .quiz import Assessment, Attempt, AttemptQuestion, Question, QuestionBank
from .rating import TutorRating
from .report import Report
from .score import DailyClaim, ScoreTransaction
from .security_log import ActivityLog, BlockedIP
from .session import AdminSession, UserSession
from .subject import Subject
from .user import StudentProfile, TutorProfile, User, user_subjects

__all__ = [
    "AdminAccount", "BookingRequest", "Bookmark", "ChatImage", "Message", "PinnedMessage",
    "CountdownFollow", "DseEvent", "Material", "Notification", "PushSubscription", "PastPaper",
    "Assessment", "Attempt", "AttemptQuestion", "Question", "QuestionBank", "TutorRating",
    "Report", "DailyClaim", "ScoreTransaction", "ActivityLog", "BlockedIP", "AdminSession",
    "UserSession", "Subject", "StudentProfile", "TutorProfile", "User", "user_subjects",
]
