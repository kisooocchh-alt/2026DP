"""Learning materials and textbook chapters that the admin manages."""
from ..extensions import db
from ..utils.time_utils import iso_utc, utcnow


class Material(db.Model):
    __tablename__ = "materials"

    id = db.Column(db.Integer, primary_key=True)
    subject_code = db.Column(db.ForeignKey("subjects.code"), nullable=False, index=True)
    topic = db.Column(db.String(80), nullable=False, default="General", index=True)
    title = db.Column(db.String(160), nullable=False)
    description = db.Column(db.Text)
    kind = db.Column(db.String(12), nullable=False)          # pdf | image | video_link | note
    body = db.Column(db.Text)                                # text for "note" materials
    file_name = db.Column(db.String(64))                     # random name in storage/materials
    file_size = db.Column(db.Integer)
    url = db.Column(db.String(500))                          # for video links (checked host)
    language = db.Column(db.String(5), nullable=False, default="en")
    allow_download = db.Column(db.Boolean, default=True, nullable=False)
    is_published = db.Column(db.Boolean, default=False, nullable=False, index=True)
    created_by = db.Column(db.ForeignKey("admin_accounts.id", ondelete="SET NULL"))
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=utcnow, onupdate=utcnow, nullable=False)

    @property
    def has_file(self) -> bool:
        return self.kind in ("pdf", "image") and bool(self.file_name)

    def to_dict(self, full: bool = False) -> dict:
        data = {
            "id": self.id, "subject": self.subject_code, "topic": self.topic,
            "title": self.title, "description": self.description or "", "kind": self.kind,
            "language": self.language, "allow_download": self.allow_download,
            "url": self.url if self.kind == "video_link" else None,
            "file_size": self.file_size, "updated_at": iso_utc(self.updated_at),
            "is_published": self.is_published,
        }
        if full:
            data["body"] = self.body or ""
        return data
