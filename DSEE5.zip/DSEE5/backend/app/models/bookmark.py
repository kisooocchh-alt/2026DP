"""Past papers and materials saved to a user's personal list."""
from ..extensions import db
from ..utils.time_utils import utcnow


class Bookmark(db.Model):
    __tablename__ = "bookmarks"
    __table_args__ = (db.UniqueConstraint("user_id", "item_type", "item_id",
                                          name="uq_bookmarks_user_item"),)

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    item_type = db.Column(db.String(10), nullable=False)            # paper | material
    item_id = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)
