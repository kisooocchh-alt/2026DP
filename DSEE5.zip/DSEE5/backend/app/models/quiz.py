"""Question banks per subject and level, the quizzes/tests/exams built from them,
and each user's attempts.

Correct answers live only on the server: Question.answer is never sent to the
browser until the attempt has been submitted.
"""
from ..extensions import db
from ..utils.time_utils import iso_utc, utcnow


class QuestionBank(db.Model):
    __tablename__ = "question_banks"

    id = db.Column(db.Integer, primary_key=True)
    subject_code = db.Column(db.ForeignKey("subjects.code"), nullable=False, index=True)
    level = db.Column(db.String(12), nullable=False, index=True)  # foundation|standard|advanced
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    questions = db.relationship("Question", back_populates="bank", cascade="all, delete-orphan",
                                lazy="dynamic")

    def to_dict(self) -> dict:
        return {"id": self.id, "subject": self.subject_code, "level": self.level,
                "name": self.name, "description": self.description or ""}


class Question(db.Model):
    __tablename__ = "questions"

    id = db.Column(db.Integer, primary_key=True)
    bank_id = db.Column(db.ForeignKey("question_banks.id", ondelete="CASCADE"), nullable=False,
                        index=True)
    topic = db.Column(db.String(80), nullable=False, default="General")
    qtype = db.Column(db.String(8), nullable=False, default="mcq")     # mcq | short
    prompt = db.Column(db.Text, nullable=False)
    image_file = db.Column(db.String(64))                               # storage/questions
    options = db.Column(db.JSON)                    # [{"id": "a", "text": "..."}] for MCQ
    answer = db.Column(db.String(300), nullable=False)  # option id, or accepted answers "a|b"
    explanation = db.Column(db.Text)
    marks = db.Column(db.Integer, default=1, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    bank = db.relationship("QuestionBank", back_populates="questions")

    @property
    def image_url(self) -> str | None:
        return f"/api/files/question/{self.image_file}" if self.image_file else None

    def to_admin_dict(self) -> dict:
        return {"id": self.id, "bank_id": self.bank_id, "topic": self.topic,
                "type": self.qtype, "prompt": self.prompt, "image_url": self.image_url,
                "options": self.options or [], "answer": self.answer,
                "explanation": self.explanation or "", "marks": self.marks,
                "is_active": self.is_active}


class Assessment(db.Model):
    __tablename__ = "assessments"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(160), nullable=False)
    bank_id = db.Column(db.ForeignKey("question_banks.id", ondelete="CASCADE"), nullable=False,
                        index=True)
    subject_code = db.Column(db.ForeignKey("subjects.code"), nullable=False, index=True)
    level = db.Column(db.String(12), nullable=False)
    kind = db.Column(db.String(8), nullable=False)                      # quiz | test | exam
    question_count = db.Column(db.Integer, nullable=False)
    time_limit_min = db.Column(db.Integer, nullable=False)
    points_base = db.Column(db.Integer, nullable=False)
    points_bonus_max = db.Column(db.Integer, nullable=False)
    is_published = db.Column(db.Boolean, default=False, nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    bank = db.relationship("QuestionBank")

    def to_dict(self) -> dict:
        return {"id": self.id, "title": self.title, "subject": self.subject_code,
                "level": self.level, "kind": self.kind, "question_count": self.question_count,
                "time_limit_min": self.time_limit_min, "points_base": self.points_base,
                "points_bonus_max": self.points_bonus_max, "is_published": self.is_published,
                "bank_id": self.bank_id}


class Attempt(db.Model):
    __tablename__ = "attempts"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    assessment_id = db.Column(db.ForeignKey("assessments.id", ondelete="CASCADE"),
                              nullable=False, index=True)
    started_at = db.Column(db.DateTime, default=utcnow, nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)
    submitted_at = db.Column(db.DateTime)
    status = db.Column(db.String(12), default="in_progress", nullable=False, index=True)
    raw_score = db.Column(db.Integer, default=0, nullable=False)
    max_score = db.Column(db.Integer, default=0, nullable=False)
    points_awarded = db.Column(db.Integer, default=0, nullable=False)
    points_reason = db.Column(db.String(30))

    assessment = db.relationship("Assessment", lazy="joined")
    questions = db.relationship("AttemptQuestion", back_populates="attempt",
                                cascade="all, delete-orphan",
                                order_by="AttemptQuestion.position")

    @property
    def percent(self) -> int:
        return round(100 * self.raw_score / self.max_score) if self.max_score else 0

    def summary_dict(self) -> dict:
        a = self.assessment
        return {"id": self.id, "assessment_id": a.id, "title": a.title, "kind": a.kind,
                "subject": a.subject_code, "level": a.level, "status": self.status,
                "started_at": iso_utc(self.started_at), "expires_at": iso_utc(self.expires_at),
                "submitted_at": iso_utc(self.submitted_at), "raw_score": self.raw_score,
                "max_score": self.max_score, "percent": self.percent,
                "points_awarded": self.points_awarded}


class AttemptQuestion(db.Model):
    __tablename__ = "attempt_questions"

    id = db.Column(db.Integer, primary_key=True)
    attempt_id = db.Column(db.ForeignKey("attempts.id", ondelete="CASCADE"), nullable=False,
                           index=True)
    question_id = db.Column(db.ForeignKey("questions.id", ondelete="CASCADE"), nullable=False)
    position = db.Column(db.Integer, nullable=False)
    option_order = db.Column(db.JSON)                 # shuffled option ids for this attempt
    answer = db.Column(db.String(300))                # the user's answer
    is_correct = db.Column(db.Boolean)
    marks_awarded = db.Column(db.Integer, default=0, nullable=False)

    attempt = db.relationship("Attempt", back_populates="questions")
    question = db.relationship("Question", lazy="joined")
