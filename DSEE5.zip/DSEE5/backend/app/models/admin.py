"""The hidden admin account, kept in its own table so admins never appear in user
search, tutor lists, chat or profiles. Created only by scripts/create_admin.py."""
from ..extensions import db
from ..utils.time_utils import utcnow


class AdminAccount(db.Model):
    __tablename__ = "admin_accounts"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(40), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    totp_secret = db.Column(db.String(64), nullable=False)        # 2FA is mandatory for admin
    totp_last_timecode = db.Column(db.Integer)
    failed_attempts = db.Column(db.Integer, default=0, nullable=False)
    locked_until = db.Column(db.DateTime)
    last_login_at = db.Column(db.DateTime)
    last_login_ip = db.Column(db.String(45))
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    def __repr__(self) -> str:
        return f"<AdminAccount {self.username}>"
