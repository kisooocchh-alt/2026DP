"""Student ratings of tutors - allowed only after a completed booking."""
from ..extensions import db
from ..utils.time_utils import iso_utc, utcnow


class TutorRating(db.Model):
    __tablename__ = "tutor_ratings"

    id = db.Column(db.Integer, primary_key=True)
    booking_id = db.Column(db.ForeignKey("booking_requests.id", ondelete="CASCADE"), unique=True,
                           nullable=False)
    student_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    tutor_id = db.Column(db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    stars = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=utcnow, nullable=False)

    booking = db.relationship("BookingRequest", back_populates="rating")
    student = db.relationship("User", foreign_keys=[student_id], lazy="joined")

    def to_dict(self) -> dict:
        return {"id": self.id, "stars": self.stars, "comment": self.comment or "",
                "created_at": iso_utc(self.created_at), "student": self.student.mini_dict()}
