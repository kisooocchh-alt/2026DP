"""All settings live here. Secrets come from the .env file in the project root."""
import os
from datetime import timedelta
from pathlib import Path

from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[2]      # .../DSEE5
BACKEND_DIR = ROOT_DIR / "backend"
load_dotenv(ROOT_DIR / ".env")


def _list(name: str) -> list[str]:
    return [x.strip() for x in os.getenv(name, "").split(",") if x.strip()]


def _bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None or value.strip() == "":
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


class BaseConfig:
    SECRET_KEY = os.getenv("SECRET_KEY")
    DEBUG = False
    TESTING = False

    # Database: SQLite file by default, PostgreSQL in production
    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL") or (
        f"sqlite:///{BACKEND_DIR / 'instance' / 'dsee5.db'}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {"pool_pre_ping": True}

    # Files
    STORAGE_DIR = BACKEND_DIR / "storage"
    BACKUP_DIR = BACKEND_DIR / "backups"
    MAX_CONTENT_LENGTH = 32 * 1024 * 1024            # biggest upload accepted (32 MB)
    CLAMAV_ENABLED = _bool("CLAMAV_ENABLED", False)
    CLAMAV_HOST = os.getenv("CLAMAV_HOST", "127.0.0.1")
    CLAMAV_PORT = int(os.getenv("CLAMAV_PORT", "3310"))

    # Cookies and sessions
    AUTH_COOKIE_NAME = "dsee5_auth"                  # DSEE5 login token (see security/sessions.py)
    ADMIN_COOKIE_NAME = "dsee5_adm"                  # separate admin login token
    DEVICE_COOKIE_NAME = "dsee5_did"                 # random device id for abuse detection
    SESSION_COOKIE_NAME = "dsee5_s"                  # Flask's own cookie (holds the CSRF token)
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = True                     # cookies only sent over HTTPS
    SESSION_LIFETIME = timedelta(days=7)
    SESSION_IDLE_TIMEOUT = timedelta(hours=24)
    ADMIN_SESSION_LIFETIME = timedelta(hours=2)
    ADMIN_SESSION_IDLE_TIMEOUT = timedelta(minutes=30)
    WTF_CSRF_TIME_LIMIT = None                       # CSRF token lasts as long as the session
    WTF_CSRF_HEADERS = ["X-CSRFToken", "X-CSRF-Token"]

    # Hidden admin
    ADMIN_URL_PREFIX = os.getenv("ADMIN_URL_PREFIX", "/change-this-admin-path")
    ADMIN_IP_ALLOWLIST = _list("ADMIN_IP_ALLOWLIST")

    # Security services
    RATELIMIT_STORAGE_URI = os.getenv("REDIS_URL") or "memory://"
    RATELIMIT_HEADERS_ENABLED = True
    RATELIMIT_ENABLED = _bool("RATELIMIT_ENABLED", True)
    TRUST_LOCALHOST = False                          # see DevelopmentConfig
    TURNSTILE_SITE_KEY = os.getenv("TURNSTILE_SITE_KEY", "")
    TURNSTILE_SECRET_KEY = os.getenv("TURNSTILE_SECRET_KEY", "")
    CAPTCHA_BYPASS = False
    SIGNUP_LIMIT_PER_IP = int(os.getenv("SIGNUP_LIMIT_PER_IP", "3"))   # new accounts per IP per day
    GEOIP_DB_PATH = BACKEND_DIR / os.getenv("GEOIP_DB_PATH", "instance/GeoLite2-City.mmdb")
    BEHIND_PROXY = False
    ALLOWED_ORIGINS = _list("ALLOWED_ORIGINS") or [
        "http://127.0.0.1:5000", "http://localhost:5000"]

    # Push notifications
    VAPID_PUBLIC_KEY = os.getenv("VAPID_PUBLIC_KEY", "")
    VAPID_PRIVATE_KEY = os.getenv("VAPID_PRIVATE_KEY", "")
    VAPID_CLAIM_EMAIL = os.getenv("VAPID_CLAIM_EMAIL", "mailto:admin@example.com")

    SCHEDULER_ENABLED = _bool("SCHEDULER_ENABLED", True)
    APP_TIMEZONE = "Asia/Hong_Kong"


class DevelopmentConfig(BaseConfig):
    DEBUG = True
    SESSION_COOKIE_SECURE = False        # http://127.0.0.1 is not HTTPS
    TRUST_LOCALHOST = _bool("TRUST_LOCALHOST", True)
    TEMPLATES_AUTO_RELOAD = True


class TestingConfig(BaseConfig):
    TESTING = True
    SECRET_KEY = "test-secret-key-that-is-long-enough-for-tests"
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    WTF_CSRF_ENABLED = False
    RATELIMIT_ENABLED = False
    CAPTCHA_BYPASS = True
    SESSION_COOKIE_SECURE = False
    ADMIN_URL_PREFIX = "/test-admin-area"
    ADMIN_IP_ALLOWLIST: list[str] = []
    SCHEDULER_ENABLED = False
    VAPID_PUBLIC_KEY = ""
    VAPID_PRIVATE_KEY = ""
    CLAMAV_ENABLED = False


class ProductionConfig(BaseConfig):
    BEHIND_PROXY = True                  # nginx sits in front of the app


CONFIGS = {"development": DevelopmentConfig, "testing": TestingConfig,
           "production": ProductionConfig}


def get_config(name: str):
    try:
        return CONFIGS[name]
    except KeyError:
        raise RuntimeError(f"Unknown APP_CONFIG '{name}' - use development, testing or "
                           "production") from None
