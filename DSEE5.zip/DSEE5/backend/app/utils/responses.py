"""Every API answer has the same shape:

    {"ok": true, ...data}            on success
    {"ok": false, "error": "code"}   on failure

Error codes are translated in the browser by frontend/locales/*.json ("errors.<code>").
"""
from flask import jsonify, request


def json_body() -> dict:
    """The JSON request body as a dict (never None, never a list)."""
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else {}


def ok(data: dict | None = None, status: int = 200):
    response = jsonify({"ok": True, **(data or {})})
    response.status_code = status
    return response


def error(code: str, status: int = 400, **extra):
    response = jsonify({"ok": False, "error": code, **extra})
    response.status_code = status
    return response
