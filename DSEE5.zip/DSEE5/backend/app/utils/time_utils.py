"""Time helpers. Database = naive UTC. Users = Hong Kong time (UTC+8)."""
from datetime import date, datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

HK = ZoneInfo("Asia/Hong_Kong")


def utcnow() -> datetime:
    """Naive UTC datetime - the only format stored in the database."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


def hk_now() -> datetime:
    return datetime.now(HK)


def hk_today() -> date:
    return hk_now().date()


def to_hk(dt: datetime) -> datetime:
    return dt.replace(tzinfo=timezone.utc).astimezone(HK)


def hk_date_of(dt: datetime) -> date:
    """The Hong Kong calendar date of a stored (naive UTC) datetime."""
    return to_hk(dt).date()


def hk_day_start_utc(day: date | None = None) -> datetime:
    """Midnight in Hong Kong for `day` (default today), as naive UTC."""
    day = day or hk_today()
    local = datetime.combine(day, time.min, tzinfo=HK)
    return local.astimezone(timezone.utc).replace(tzinfo=None)


def iso_hk(dt: datetime | None) -> str | None:
    """For JSON, e.g. '2027-04-08T08:30:00+08:00'. JavaScript's new Date() reads this."""
    return to_hk(dt).isoformat() if dt else None


def iso_utc(dt: datetime | None) -> str | None:
    return dt.replace(tzinfo=timezone.utc).isoformat() if dt else None


def parse_datetime(value: str) -> datetime:
    """Parse '2027-04-08T08:30' (Hong Kong time) or a full ISO string with an offset.

    Returns naive UTC for storage. Raises ValueError if the text is not a date-time.
    """
    value = (value or "").strip()
    if not value:
        raise ValueError("empty")
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=HK)
    return dt.astimezone(timezone.utc).replace(tzinfo=None)


def seconds_between(start: datetime, end: datetime) -> int:
    return max(0, int((end - start).total_seconds()))


def days_ago(days: int) -> datetime:
    return utcnow() - timedelta(days=days)
