"""Split long lists into pages: ?page=2 -> items 21-40."""
from collections.abc import Callable

from flask import request

from ..extensions import db


def page_number() -> int:
    try:
        return max(1, min(int(request.args.get("page", 1)), 10_000))
    except (TypeError, ValueError):
        return 1


def paginate(stmt, serialize: Callable, per_page: int = 20, max_per_page: int = 50) -> dict:
    """Run a SQLAlchemy select() for one page and return a JSON-ready dict."""
    try:
        per_page = max(1, min(int(request.args.get("per_page", per_page)), max_per_page))
    except (TypeError, ValueError):
        pass
    result = db.paginate(stmt, page=page_number(), per_page=per_page, error_out=False)
    return {
        "items": [serialize(item) for item in result.items],
        "page": result.page,
        "pages": max(result.pages, 1),
        "total": result.total,
    }
