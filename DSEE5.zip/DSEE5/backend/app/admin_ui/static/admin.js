/* DSEE5 admin helper script.
 *
 * - Buttons with data-action send an admin request (data-url, data-method, data-body).
 *   data-confirm asks first; data-reason opens a dialog that asks for a reason (saved in
 *   the activity log); data-minutes also asks for a duration.
 * - Forms with data-api are sent with fetch (multipart, or JSON with data-json) and the
 *   page reloads (or goes to data-redirect) when they succeed.
 * - URLs always come from data- attributes rendered by url_for(), so the secret admin
 *   prefix is never written inside this script.
 * - All user text is inserted with textContent, never innerHTML.
 */
(function () {
  'use strict';

  const MESSAGES = {
    session_expired: 'Your admin session ended. Reload the page and sign in again.',
    validation_failed: 'Please fix the highlighted fields.',
    csrf_failed: 'The form expired. Reload the page and try again.',
    file_missing: 'Choose a file first.',
    file_too_large: 'That file is too large.',
    bad_file_type: 'That type of file is not allowed.',
    bad_image: 'That image could not be read.',
    unsafe_pdf: 'The PDF contains JavaScript or launch actions and was refused.',
    virus_found: 'The virus scanner rejected this file.',
    scan_unavailable: 'The virus scanner is not reachable, so the file was not saved.',
    paper_exists: 'That paper (subject, year, paper and language) already exists.',
    bank_in_use: 'People have taken quizzes from this bank, so it cannot be deleted. Retire its questions instead.',
    no_certificate: 'This tutor has not uploaded a certificate yet.',
    csv_columns: 'The CSV needs at least the columns type, prompt and answer.',
    csv_not_utf8: 'Save the CSV as UTF-8 and try again.',
    action_invalid: 'That action is not possible for this report.',
    too_many_requests: 'Too many requests. Wait a moment and try again.',
    required: 'Required',
    subject_invalid: 'Choose a subject',
    year_invalid: 'Enter a year from 1990',
    paper_required: 'Enter the paper name',
    title_required: 'Enter a title',
    body_required: 'Write the note text',
    url_invalid: 'Use an https YouTube or Vimeo link',
    prompt_required: 'Write the question',
    options_required: 'Enter at least options A and B',
    answer_invalid: 'Choose or type the correct answer',
    number_invalid: 'Enter a valid number',
    marks_invalid: 'Marks must be 1 to 20',
    datetime_invalid: 'Enter a date and time',
    ip_invalid: 'Enter a valid IP address',
    name_required: 'Enter a name',
    bank_invalid: 'Choose a question bank',
    kind_invalid: 'Choose a type from the list',
    language_invalid: 'Choose a language',
    level_invalid: 'Choose a level',
    type_invalid: 'Choose a question type',
    not_a_tutor: 'Only tutor accounts can be verified.',
  };

  const csrf = () => document.querySelector('meta[name="csrf-token"]')?.content || '';

  async function adminFetch(url, { method = 'POST', body, form } = {}) {
    const headers = { 'X-CSRFToken': csrf(), Accept: 'application/json' };
    let payload;
    if (form) {
      payload = form;
    } else if (body !== undefined) {
      headers['Content-Type'] = 'application/json';
      payload = JSON.stringify(body);
    }
    const res = await fetch(url, { method, headers, body: payload, credentials: 'same-origin' });
    const type = res.headers.get('Content-Type') || '';
    let data;
    if (type.includes('application/json')) {
      data = await res.json();
    } else if (res.status === 404) {
      data = { ok: false, error: 'session_expired' };
    } else {
      data = { ok: res.ok, error: res.ok ? null : `HTTP ${res.status}` };
    }
    if (!res.ok || data.ok === false) {
      const err = new Error(data.error || 'failed');
      err.data = data;
      throw err;
    }
    return data;
  }

  const describe = (code) => MESSAGES[code] || code;

  function toast(message, kind = 'ok') {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = message;
    el.className = `toast ${kind === 'error' ? 'error' : ''}`;
    el.hidden = false;
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => { el.hidden = true; }, kind === 'error' ? 6000 : 2500);
  }

  // ------------------------------------------------------------ reason dialog
  function askReason({ title, text, minutes, okLabel }) {
    const dialog = document.getElementById('reason-dialog');
    if (!dialog || typeof dialog.showModal !== 'function') {
      const reason = window.prompt(text || title);
      return Promise.resolve(reason === null ? null : { reason });
    }
    const form = dialog.querySelector('form');
    form.reset();
    dialog.querySelector('#reason-title').textContent = title;
    dialog.querySelector('#reason-text').textContent = text || '';
    dialog.querySelector('#minutes-field').hidden = !minutes;
    dialog.querySelector('#penalty-field').hidden = true;
    dialog.querySelector('#reason-ok').textContent = okLabel || 'Confirm';
    dialog.showModal();
    dialog.querySelector('textarea').focus();
    return new Promise((resolve) => {
      dialog.addEventListener('close', function onClose() {
        dialog.removeEventListener('close', onClose);
        if (dialog.returnValue !== 'ok') return resolve(null);
        const result = { reason: form.reason.value.trim() };
        if (minutes) result.minutes = Number(form.minutes.value) || 1440;
        resolve(result);
      });
    });
  }

  function askDelete() {
    const dialog = document.getElementById('reason-dialog');
    const form = dialog.querySelector('form');
    form.reset();
    dialog.querySelector('#reason-title').textContent = 'Delete message';
    dialog.querySelector('#reason-text').textContent =
      'The message is hidden from everyone but kept for the audit log.';
    dialog.querySelector('#minutes-field').hidden = true;
    dialog.querySelector('#penalty-field').hidden = false;
    dialog.querySelector('#reason-ok').textContent = 'Delete';
    dialog.showModal();
    return new Promise((resolve) => {
      dialog.addEventListener('close', function onClose() {
        dialog.removeEventListener('close', onClose);
        if (dialog.returnValue !== 'ok') return resolve(null);
        resolve({ reason: form.reason.value.trim(), penalty: form.penalty.checked });
      });
    });
  }

  // ------------------------------------------------------------ action buttons
  document.addEventListener('click', async (event) => {
    const btn = event.target.closest('[data-action]');
    if (!btn) return;
    event.preventDefault();
    let body = {};
    try {
      body = btn.dataset.body ? JSON.parse(btn.dataset.body) : {};
    } catch {
      body = {};
    }
    if (btn.dataset.reason !== undefined) {
      const answer = await askReason({
        title: btn.textContent.trim(),
        text: btn.dataset.reason,
        minutes: btn.hasAttribute('data-minutes'),
        okLabel: btn.dataset.ok,
      });
      if (!answer) return;
      body = { ...body, ...answer };
    } else if (btn.dataset.confirm && !window.confirm(btn.dataset.confirm)) {
      return;
    }
    btn.disabled = true;
    try {
      const data = await adminFetch(btn.dataset.url, { method: btn.dataset.method || 'POST', body });
      toast(data.retired ? 'Kept for past results and hidden instead.' : 'Done');
      setTimeout(() => window.location.reload(), 500);
    } catch (err) {
      toast(describe(err.message), 'error');
      btn.disabled = false;
    }
  });

  // ------------------------------------------------------------ API forms
  function clearErrors(form) {
    form.querySelectorAll('.field-error').forEach((el) => el.remove());
    form.querySelectorAll('[aria-invalid]').forEach((el) => el.removeAttribute('aria-invalid'));
    const general = form.querySelector('[data-form-error]');
    if (general) {
      general.hidden = true;
      general.textContent = '';
    }
  }

  function showErrors(form, err) {
    const general = form.querySelector('[data-form-error]');
    const fields = err.data?.fields || {};
    let placed = 0;
    for (const [name, code] of Object.entries(fields)) {
      const input = form.querySelector(`[name="${CSS.escape(name)}"]`);
      if (!input) continue;
      input.setAttribute('aria-invalid', 'true');
      const note = document.createElement('span');
      note.className = 'field-error';
      note.textContent = describe(code);
      (input.closest('.field') || input.parentElement).appendChild(note);
      placed += 1;
    }
    if (general) {
      const extra = Object.keys(fields).length > placed
        ? ' ' + Object.entries(fields).map(([k, v]) => `${k}: ${describe(v)}`).join('; ')
        : '';
      general.textContent = describe(err.message) + extra;
      general.hidden = false;
    } else {
      toast(describe(err.message), 'error');
    }
  }

  function formToJson(form) {
    const data = {};
    for (const [key, value] of new FormData(form).entries()) data[key] = value;
    form.querySelectorAll('input[type="checkbox"][name]').forEach((cb) => {
      data[cb.name] = cb.checked;
    });
    return data;
  }

  document.addEventListener('submit', async (event) => {
    const form = event.target.closest('form[data-api]');
    if (!form) return;
    event.preventDefault();
    if (form.hasAttribute('data-csv-form')) {
      handleCsv(form, event.submitter);
      return;
    }
    clearErrors(form);
    const buttons = form.querySelectorAll('button');
    buttons.forEach((b) => { b.disabled = true; });
    const method = form.dataset.method || 'POST';
    try {
      if (form.hasAttribute('data-json')) {
        await adminFetch(form.dataset.api, { method, body: formToJson(form) });
      } else {
        await adminFetch(form.dataset.api, { method, form: new FormData(form) });
      }
      toast('Saved');
      setTimeout(() => {
        if (form.dataset.redirect) window.location.href = form.dataset.redirect;
        else window.location.reload();
      }, 400);
    } catch (err) {
      showErrors(form, err);
      buttons.forEach((b) => { b.disabled = false; });
    }
  });

  // ------------------------------------------------------------ CSV import
  async function handleCsv(form, submitter) {
    clearErrors(form);
    const out = form.parentElement.querySelector('[data-csv-result]');
    const fd = new FormData(form);
    const preview = submitter && submitter.hasAttribute('data-preview');
    if (preview) fd.set('preview', '1');
    else fd.delete('preview');
    try {
      const data = await adminFetch(form.dataset.api, { form: fd });
      out.replaceChildren();
      const summary = document.createElement('p');
      if (data.saved) {
        summary.textContent = `Imported ${data.saved} questions.`;
        out.append(summary);
        setTimeout(() => window.location.reload(), 800);
        return;
      }
      summary.textContent = `${data.valid} valid rows` +
        (data.problems.length ? `, ${data.problems.length} rows with problems (nothing saved).` : '. Press Import to save them.');
      out.append(summary);
      if (data.problems.length) {
        const list = document.createElement('ul');
        list.className = 'plain';
        data.problems.forEach((p) => {
          const li = document.createElement('li');
          li.textContent = `Line ${p.line}: ` +
            Object.entries(p.errors).map(([k, v]) => `${k} - ${describe(v)}`).join('; ');
          list.append(li);
        });
        out.append(list);
      }
      if (data.preview.length) {
        const table = document.createElement('table');
        const head = table.createTHead().insertRow();
        ['Topic', 'Type', 'Question', 'Answer', 'Options'].forEach((h) => {
          const th = document.createElement('th');
          th.textContent = h;
          head.append(th);
        });
        const body = table.createTBody();
        data.preview.forEach((r) => {
          const row = body.insertRow();
          [r.topic, r.type, r.prompt, r.answer, r.options].forEach((v) => {
            row.insertCell().textContent = String(v);
          });
        });
        out.append(table);
      }
    } catch (err) {
      showErrors(form, err);
    }
  }

  // ------------------------------------------------------------ dependent fields
  function toggleGroup(form, attr, value) {
    form.querySelectorAll(`[${attr}]`).forEach((el) => {
      const show = el.getAttribute(attr).split(' ').includes(value);
      el.hidden = !show;
      el.querySelectorAll('input, select, textarea').forEach((input) => { input.disabled = !show; });
    });
  }

  document.querySelectorAll('[data-kind-select]').forEach((select) => {
    const form = select.form;
    const update = () => toggleGroup(form, 'data-kind', select.value);
    select.addEventListener('change', update);
    update();
  });

  document.querySelectorAll('[data-qtype-select]').forEach((select) => {
    const form = select.form;
    const update = () => toggleGroup(form, 'data-qtype', select.value);
    select.addEventListener('change', update);
    update();
  });

  document.querySelectorAll('select[data-kind-defaults]').forEach((select) => {
    const rules = JSON.parse(select.dataset.kindDefaults);
    select.addEventListener('change', () => {
      const r = rules[select.value];
      if (!r) return;
      const form = select.form;
      form.question_count.value = r.questions;
      form.time_limit_min.value = r.minutes;
      form.points_base.value = r.base;
      form.points_bonus_max.value = r.bonus_max;
    });
  });

  document.querySelectorAll('[data-autosubmit]').forEach((select) => {
    select.addEventListener('change', () => select.form.submit());
  });

  // Bar widths come from data-pct (inline style attributes are blocked by the CSP).
  document.querySelectorAll('.bar[data-pct]').forEach((bar) => {
    bar.style.width = `${Math.max(1, Math.min(100, Number(bar.dataset.pct) || 0)) * 0.55}%`;
  });

  // ------------------------------------------------------------ chat moderation
  const chatBox = document.querySelector('[data-chat-admin]');
  if (chatBox) {
    const search = document.querySelector('[data-chat-search]');
    const reportedOnly = document.querySelector('[data-chat-reported]');
    const status = document.querySelector('[data-chat-status]');
    const withId = (template, id) => template.replace('/0/', `/${id}/`).replace(/\/0$/, `/${id}`);
    const hkTime = (iso) => new Date(iso).toLocaleString('en-GB', {
      timeZone: 'Asia/Hong_Kong', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit',
    });
    let lastJson = '';

    function badge(text, kind) {
      const span = document.createElement('span');
      span.className = `badge ${kind || ''}`;
      span.textContent = text;
      return span;
    }

    function actionButton(label, cls, handler) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = `btn small ${cls || ''}`;
      b.textContent = label;
      b.addEventListener('click', handler);
      return b;
    }

    async function run(fn) {
      try {
        await fn();
        toast('Done');
        load(true);
      } catch (err) {
        toast(describe(err.message), 'error');
      }
    }

    function render(messages) {
      chatBox.replaceChildren();
      if (!messages.length) {
        const p = document.createElement('p');
        p.className = 'empty';
        p.textContent = 'No messages in this room yet.';
        chatBox.append(p);
        return;
      }
      messages.slice().reverse().forEach((m) => {
        const item = document.createElement('article');
        item.className = 'chat-msg';
        if (m.deleted) item.classList.add('is-deleted');
        if (m.hidden) item.classList.add('is-hidden');
        if (m.pinned) item.classList.add('is-pinned');
        const meta = document.createElement('div');
        meta.className = 'chat-meta';
        const who = document.createElement('a');
        who.href = m.user_link;
        who.textContent = m.user.username || 'deleted user';
        meta.append(who, document.createTextNode(hkTime(m.created_at)));
        if (m.deleted) meta.append(badge(`deleted: ${m.delete_reason || ''}`, 'danger'));
        if (m.hidden) meta.append(badge('hidden by reports', 'warn'));
        if (m.report_count) meta.append(badge(`${m.report_count} reports`, 'warn'));
        if (m.shadow_banned) meta.append(badge('shadow-banned author', 'warn'));
        if (m.pinned) meta.append(badge('pinned', 'info'));
        const text = document.createElement('p');
        text.className = 'pre';
        text.style.margin = '0';
        text.textContent = m.text || '';
        item.append(meta, text);
        if (m.admin_image_url) {
          const link = document.createElement('a');
          link.href = m.admin_image_url;
          link.target = '_blank';
          link.rel = 'noopener';
          const img = document.createElement('img');
          img.src = m.admin_image_url;
          img.alt = 'Attached image';
          img.className = 'thumb';
          link.append(img);
          item.append(link);
        }
        const actions = document.createElement('div');
        actions.className = 'row-actions';
        if (!m.deleted) {
          actions.append(actionButton('Delete', 'danger', async () => {
            const answer = await askDelete();
            if (answer) run(() => adminFetch(withId(chatBox.dataset.deleteUrl, m.id), { method: 'DELETE', body: answer }));
          }));
          actions.append(actionButton(m.pinned ? 'Unpin' : 'Pin', '', () =>
            run(() => adminFetch(withId(chatBox.dataset.pinUrl, m.id), { body: { pinned: !m.pinned } }))));
        }
        if (m.hidden && !m.deleted) {
          actions.append(actionButton('Show again', '', () =>
            run(() => adminFetch(withId(chatBox.dataset.unhideUrl, m.id), { body: {} }))));
        }
        item.append(actions);
        chatBox.append(item);
      });
    }

    async function load(force) {
      const params = new URLSearchParams();
      if (search && search.value.trim()) params.set('q', search.value.trim());
      if (reportedOnly && reportedOnly.checked) params.set('filter', 'reported');
      try {
        const res = await fetch(`${chatBox.dataset.url}?${params}`, {
          credentials: 'same-origin', headers: { Accept: 'application/json' },
        });
        if (!res.ok) throw new Error(res.status === 404 ? 'session_expired' : `HTTP ${res.status}`);
        const data = await res.json();
        const json = JSON.stringify(data.messages);
        if (force || json !== lastJson) render(data.messages);
        lastJson = json;
        if (status) status.textContent = `Updated ${new Date().toLocaleTimeString('en-GB')}`;
      } catch (err) {
        if (status) status.textContent = describe(err.message);
      }
    }

    let timer;
    search?.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(() => load(true), 350);
    });
    reportedOnly?.addEventListener('change', () => load(true));
    document.getElementById('chat-filters')?.addEventListener('submit', (e) => {
      if (e.submitter == null) e.preventDefault();
    });
    load(true);
    setInterval(() => {
      if (!document.hidden) load(false);
    }, 10000);
  }
})();
