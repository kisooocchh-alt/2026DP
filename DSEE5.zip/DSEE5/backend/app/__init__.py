"""DSEE5 application factory. Everything is wired together here."""
import logging
import mimetypes
import os
import re

from flask import Flask
from werkzeug.middleware.proxy_fix import ProxyFix

from .config import BACKEND_DIR, ROOT_DIR, get_config
from .extensions import csrf, db, limiter, migrate, socketio

# Some Windows installs map .js to text/plain, which stops ES modules from loading.
mimetypes.add_type("text/javascript", ".js")
mimetypes.add_type("text/css", ".css")
mimetypes.add_type("image/svg+xml", ".svg")
mimetypes.add_type("font/woff", ".woff")
mimetypes.add_type("font/woff2", ".woff2")
mimetypes.add_type("application/manifest+json", ".webmanifest")

_PREFIX_RE = re.compile(r"^/[A-Za-z0-9_-]{8,64}$")


def create_app(config_name: str | None = None) -> Flask:
    config_name = config_name or os.getenv("APP_CONFIG", "development")
    app = Flask(
        __name__,
        static_folder=str(ROOT_DIR / "frontend"),   # public HTML/CSS/JS
        static_url_path="",                         # /css/base.css -> frontend/css/base.css
        instance_path=str(BACKEND_DIR / "instance"),
    )
    app.config.from_object(get_config(config_name))
    _check_config(app, config_name)
    os.makedirs(app.instance_path, exist_ok=True)
    app.json.ensure_ascii = False                   # keep Chinese readable in JSON
    app.json.sort_keys = False
    _configure_logging(app)

    db.init_app(app)
    migrate.init_app(app, db, render_as_batch=True)  # batch mode lets SQLite alter tables

    from . import models  # noqa: F401  - registers every table for migrations
    from .routes import register_blueprints
    from .security.headers import init_security_headers
    from .security.ip_tracker import init_ip_guard
    from .security.rate_limits import init_rate_limit_filters
    from .security.sessions import init_sessions
    from .services.upload_service import ensure_storage_dirs
    from .sockets import register_socket_events

    init_security_headers(app)   # HTTPS redirect, HSTS, CSP
    init_ip_guard(app)           # before_request 1: reject blocked IPs and attack probes
    init_sessions(app)           # before_request 2: load g.user / g.admin / g.device_id
    csrf.init_app(app)           # before_request 3: CSRF check on POST/PUT/PATCH/DELETE
    limiter.init_app(app)        # before_request 4: rate limits (can key on g.user)
    init_rate_limit_filters(app)
    register_socket_events(socketio)   # before init_app, so every app gets the handlers
    socketio.init_app(app, cors_allowed_origins=app.config["ALLOWED_ORIGINS"],
                      max_http_buffer_size=64 * 1024)
    ensure_storage_dirs(app)
    register_blueprints(app)

    # Behind nginx: use the real visitor IP. Applied last so it wraps everything,
    # including the Socket.IO middleware.
    if app.config["BEHIND_PROXY"]:
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
    return app


def _check_config(app: Flask, config_name: str) -> None:
    secret = app.config.get("SECRET_KEY") or ""
    if not secret:
        raise RuntimeError("SECRET_KEY is missing - copy .env.example to .env and fill it in")
    prefix = app.config["ADMIN_URL_PREFIX"]
    if not _PREFIX_RE.match(prefix) or prefix.lower().startswith(("/api", "/css", "/js")):
        raise RuntimeError("ADMIN_URL_PREFIX must look like /k3Jd9-xQ2aLm (a slash and "
                           "8-64 letters, digits, - or _)")
    if config_name == "production":
        if len(secret) < 32 or "replace" in secret:
            raise RuntimeError("Set a real random SECRET_KEY (64 hex characters) for production")
        if "replace" in prefix or prefix == "/change-this-admin-path":
            raise RuntimeError("Set a random ADMIN_URL_PREFIX for production")


def _configure_logging(app: Flask) -> None:
    level = logging.DEBUG if app.debug else logging.INFO
    logging.basicConfig(level=level, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger("werkzeug").setLevel(logging.INFO)
    logging.getLogger("apscheduler").setLevel(logging.WARNING)
    logging.getLogger("engineio.server").setLevel(logging.WARNING)
    logging.getLogger("socketio.server").setLevel(logging.WARNING)
