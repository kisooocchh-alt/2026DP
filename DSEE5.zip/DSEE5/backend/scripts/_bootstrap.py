"""Shared start-up for the scripts in this folder: makes `app` importable and checks
that the database tables exist."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))     # backend/

from sqlalchemy import inspect  # noqa: E402

from app import create_app  # noqa: E402
from app.extensions import db  # noqa: E402


def make_app():
    app = create_app()
    with app.app_context():
        if "users" not in inspect(db.engine).get_table_names():
            sys.exit("The database tables do not exist yet. From backend/ run:\n"
                     "  flask --app app db upgrade")
    return app
