"""Fill the subjects table from app/data/subjects.json.

    Run from backend/:  python scripts/seed_subjects.py

Safe to run again: existing subjects are updated, not duplicated.
"""
from _bootstrap import make_app

from app import constants as C
from app.extensions import db
from app.models.subject import Subject


def main() -> None:
    app = make_app()
    with app.app_context():
        for s in C.SUBJECTS:
            db.session.merge(Subject(code=s["code"], name_en=s["name_en"], name_zh=s["name_zh"],
                                     category=s["category"], sort_order=s["order"],
                                     is_active=True))
        db.session.commit()
        print(f"Saved {len(C.SUBJECTS)} subjects.")


if __name__ == "__main__":
    main()
