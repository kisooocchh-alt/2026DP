"""Check that every translation key used by the website exists in every locale file.

    python backend/scripts/check_locales.py

It looks at:
  * data-i18n, data-i18n-placeholder, -aria and -title attributes in the HTML pages,
  * string literals in the JavaScript that look like translation keys ("quiz.start"),
  * template keys such as t(`quiz.levels.${level}`) - the "quiz.levels" group must exist,
  * every error code the back end can send ("errors.<code>").

It also reports keys that exist in one language but not the other, and placeholders
({n}, {name}, ...) that differ between languages. English singular forms ("<key>_one",
used when n is 1) are optional in other languages. Exit code 1 means something is missing.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FRONTEND = ROOT / "frontend"
BACKEND = ROOT / "backend" / "app"
LOCALES = ["en", "zh-HK"]

ATTR = re.compile(r'data-i18n(?:-placeholder|-aria|-title)?\s*=\s*"([^"]+)"')
JS_ATTR = re.compile(r"""['"]data-i18n(?:-placeholder|-aria|-title)?['"]\s*:\s*['"]([^'"]+)['"]""")
LITERAL = re.compile(r"""(?<![\w$])['"]([a-z0-9_]+(?:\.[a-z0-9_]+)+)['"]""")
TEMPLATE = re.compile(r"`([a-z0-9_]+(?:\.[a-z0-9_]+)*)\.\$\{")
PLACEHOLDER = re.compile(r"\{(\w+)\}")
SINGULAR = "_one"            # English-only singular forms, see frontend/js/core/i18n.js

# Ways the back end produces an error code.
ERROR_PATTERNS = [
    re.compile(r"\b(?:error|AuthError|UploadError|ModerationError|QuizError|ChatError|FieldError)"
               r"\(\s*[\"']([a-z_]+)[\"']"),
    re.compile(r"\bcode\s*=\s*[\"']([a-z_]+)[\"']"),
    re.compile(r"[\"']error[\"']\s*:\s*[\"']([a-z_]+)[\"']"),
    re.compile(r"\berror(?:_code)?\s*=\s*[\"']([a-z_]+)[\"']"),
    re.compile(r"\berrors\[[^\]]+\]\s*=\s*[\"']([a-z_]+)[\"']"),
    re.compile(r"validation_error\(\{\s*[\"']\w+[\"']\s*:\s*[\"']([a-z_]+)[\"']"),
]
# The hidden admin area is English-only and has its own message table in admin.js.
ADMIN_MODULES = {"admin.py", "admin_auth.py"}
ADMIN_SCRIPT = BACKEND / "admin_ui" / "static" / "admin.js"
ADMIN_MESSAGE = re.compile(r"^\s{4}([a-z_]+):\s*'", re.M)
# Codes produced by the browser itself (api.js / socket.js).
FRONTEND_ERROR = re.compile(r"""(?:code|error)\s*[:=]\s*['"]([a-z_]+)['"]""")
# Words that match the patterns above but are not error codes.
NOT_ERROR_CODES = {"code", "image", "limit", "pdf"}


def flatten(data: dict, prefix: str = "") -> dict[str, str]:
    out: dict[str, str] = {}
    for key, value in data.items():
        path = f"{prefix}{key}"
        if isinstance(value, dict):
            out.update(flatten(value, path + "."))
        else:
            out[path] = value
    return out


def groups(flat: dict[str, str]) -> set[str]:
    found = set()
    for key in flat:
        parts = key.split(".")
        for i in range(1, len(parts)):
            found.add(".".join(parts[:i]))
    return found


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def main() -> int:
    locales = {code: flatten(json.loads(read(FRONTEND / "locales" / f"{code}.json")))
               for code in LOCALES}
    reference = locales["en"]
    namespaces = {key.split(".")[0] for key in reference}

    used: set[str] = set()
    prefixes: set[str] = set()
    for page in list(FRONTEND.glob("*.html")) + list(FRONTEND.glob("pages/*.html")):
        used.update(ATTR.findall(read(page)))
    for script in FRONTEND.glob("js/**/*.js"):
        if "vendor" in script.parts:
            continue
        source = read(script)
        used.update(JS_ATTR.findall(source))
        used.update(k for k in LITERAL.findall(source) if k.split(".")[0] in namespaces)
        prefixes.update(p for p in TEMPLATE.findall(source) if p.split(".")[0] in namespaces)

    error_codes: set[str] = set()
    admin_codes: set[str] = set()
    for module in BACKEND.rglob("*.py"):
        source = read(module)
        target = admin_codes if module.name in ADMIN_MODULES else error_codes
        for pattern in ERROR_PATTERNS:
            target.update(pattern.findall(source))
    for name in ("core/api.js", "core/socket.js"):
        error_codes.update(FRONTEND_ERROR.findall(read(FRONTEND / "js" / name)))
    error_codes -= NOT_ERROR_CODES
    used.update(f"errors.{code}" for code in error_codes)

    problems = 0
    admin_messages = set(ADMIN_MESSAGE.findall(read(ADMIN_SCRIPT)))
    # Shared codes (validation_failed, csrf_failed, ...) may come from the public table too.
    admin_missing = sorted(admin_codes - NOT_ERROR_CODES - admin_messages - error_codes)
    if admin_missing:
        problems += len(admin_missing)
        print(f"[admin.js] {len(admin_missing)} admin error codes have no message:")
        for key in admin_missing:
            print(f"    {key}")

    for code, flat in locales.items():
        missing = sorted(k for k in used if k not in flat)
        known_groups = groups(flat)
        missing_groups = sorted(p for p in prefixes if p not in known_groups)
        if missing:
            problems += len(missing)
            print(f"[{code}] {len(missing)} keys used by the site are missing:")
            for key in missing:
                print(f"    {key}")
        if missing_groups:
            problems += len(missing_groups)
            print(f"[{code}] {len(missing_groups)} key groups used in templates are missing:")
            for key in missing_groups:
                print(f"    {key}.*")

    # English singular forms ("points_one") need their base key and no new placeholders.
    for key in (k for k in reference if k.endswith(SINGULAR)):
        base = key[: -len(SINGULAR)]
        extra = set(PLACEHOLDER.findall(reference[key])) - set(PLACEHOLDER.findall(
            reference.get(base, "")))
        if base not in reference or extra:
            problems += 1
            print(f"[en] {key}: needs the key {base} and no placeholders it does not have")

    for code, flat in locales.items():
        if code == "en":
            continue
        only_en = sorted(k for k in set(reference) - set(flat) if not k.endswith(SINGULAR))
        only_here = sorted(set(flat) - set(reference))
        if only_en:
            problems += len(only_en)
            print(f"[{code}] {len(only_en)} keys exist in en but not here:")
            for key in only_en:
                print(f"    {key}")
        if only_here:
            problems += len(only_here)
            print(f"[{code}] {len(only_here)} keys exist here but not in en:")
            for key in only_here:
                print(f"    {key}")
        for key in sorted(set(reference) & set(flat)):
            want = set(PLACEHOLDER.findall(reference[key]))
            have = set(PLACEHOLDER.findall(flat[key]))
            if want != have:
                problems += 1
                print(f"[{code}] placeholders differ for {key}: "
                      f"en {sorted(want)}, {code} {sorted(have)}")

    unused = sorted(k for k in reference
                    if k not in used and not k.endswith(SINGULAR)
                    and not any(k.startswith(p + ".") for p in prefixes))
    print(f"{len(used)} keys used, {len(prefixes)} template groups, "
          f"{len(error_codes)} public error codes, {len(admin_codes)} admin error codes, "
          f"{len(reference)} keys in en.json.")
    if unused:
        print(f"Note: {len(unused)} keys in en.json are not referenced directly "
              f"(they may be built at run time): {', '.join(unused[:40])}"
              + (" ..." if len(unused) > 40 else ""))
    if problems:
        print(f"FAILED: {problems} problems.")
        return 1
    print("OK: every key exists in every language.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
