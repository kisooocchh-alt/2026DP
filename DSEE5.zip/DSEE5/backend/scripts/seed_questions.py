"""Create sample question banks and published quizzes so the quiz pages work straight
away. Add real questions later in the admin quiz bank (one by one or by CSV import).

    Run from backend/:  python scripts/seed_questions.py

The sample questions are original practice items written for DSEE5 - do not paste
HKEAA paper questions here, they are copyrighted. Safe to run again: banks that
already exist (same subject, level and name) are left alone.
"""
from _bootstrap import make_app

from app import constants as C
from app.extensions import db
from app.models.quiz import Assessment, Question, QuestionBank


def mcq(topic, prompt, options, answer, explanation, marks=1):
    return {"topic": topic, "qtype": "mcq", "prompt": prompt, "marks": marks,
            "options": [{"id": k, "text": v} for k, v in zip("abcdef", options, strict=False)],
            "answer": answer, "explanation": explanation}


def short(topic, prompt, answer, explanation, marks=1):
    return {"topic": topic, "qtype": "short", "prompt": prompt, "options": None,
            "answer": answer, "explanation": explanation, "marks": marks}


BANKS = [
    {
        "subject": "MATH", "level": "foundation", "name": "Core skills (Level 2-3)",
        "description": "Number, algebra, measures and data - the foundation of Paper 1.",
        "questions": [
            mcq("Algebra", "Simplify 3x + 5x − 2x.", ["6x", "10x", "6", "8x − 2"], "a",
                "Add the like terms: 3 + 5 − 2 = 6, so the answer is 6x."),
            mcq("Percentages", "A $400 bag is sold at a 15% discount. What is the selling price?",
                ["$340", "$385", "$60", "$345"], "a",
                "The discount is 15% × $400 = $60, so the price is $400 − $60 = $340."),
            mcq("Equations", "Solve 2x − 7 = 9.", ["x = 1", "x = 8", "x = 16", "x = −1"], "b",
                "Add 7 to both sides: 2x = 16, then divide by 2: x = 8."),
            mcq("Mensuration", "What is the area of a rectangle 12 cm long and 7.5 cm wide?",
                ["39 cm²", "90 cm²", "84 cm²", "19.5 cm²"], "b",
                "Area = length × width = 12 × 7.5 = 90 cm²."),
            mcq("Indices", "Simplify a³ × a⁴.", ["a¹²", "a⁷", "2a⁷", "a"], "b",
                "When multiplying powers of the same base, add the indices: 3 + 4 = 7."),
            mcq("Coordinates", "Find the distance between (1, 2) and (4, 6).",
                ["3", "4", "5", "7"], "c",
                "√[(4 − 1)² + (6 − 2)²] = √(9 + 16) = √25 = 5."),
            mcq("Statistics", "Find the mean of 4, 7, 9, 12 and 8.", ["7", "8", "9", "40"], "b",
                "The sum is 40 and there are 5 numbers, so the mean is 40 ÷ 5 = 8."),
            mcq("Ratio", "$360 is shared in the ratio 2 : 3. What is the larger share?",
                ["$144", "$180", "$216", "$240"], "c",
                "There are 5 parts of $72 each. The larger share is 3 × $72 = $216."),
            short("Algebra", "Factorise x² − 9.", "(x+3)(x-3)|(x-3)(x+3)",
                  "x² − 9 is a difference of two squares: (x + 3)(x − 3)."),
            short("Functions", "If f(x) = 2x + 1, find f(3).", "7",
                  "Substitute x = 3: f(3) = 2(3) + 1 = 7."),
        ],
        "assessments": [("Core skills warm-up", "quiz", 10, 15)],
    },
    {
        "subject": "MATH", "level": "standard", "name": "Compulsory Part (Level 4)",
        "description": "Quadratics, sequences, logarithms, trigonometry and probability.",
        "questions": [
            mcq("Quadratics", "Solve x² − 5x + 6 = 0.",
                ["x = 2 or x = 3", "x = −2 or x = −3", "x = 1 or x = 6", "x = −1 or x = −6"],
                "a", "x² − 5x + 6 = (x − 2)(x − 3) = 0, so x = 2 or x = 3."),
            mcq("Quadratics", "For which value of k does x² + 4x + k = 0 have equal roots?",
                ["2", "4", "8", "16"], "b",
                "Equal roots need Δ = 0: 4² − 4(1)(k) = 0, so k = 4."),
            mcq("Logarithms", "Find log₂ 32.", ["4", "5", "6", "16"], "b",
                "2⁵ = 32, so log₂ 32 = 5."),
            mcq("Trigonometry", "What is sin 30°?", ["1/2", "√3/2", "√2/2", "1"], "a",
                "sin 30° = 1/2 (from the 30°-60°-90° triangle)."),
            mcq("Sequences", "Find the 20th term of the arithmetic sequence 3, 7, 11, ...",
                ["77", "79", "80", "83"], "b",
                "a = 3 and d = 4, so T(20) = 3 + 19 × 4 = 79."),
            mcq("Sequences", "Find the sum of the first 5 terms of 2, 6, 18, ...",
                ["162", "242", "244", "486"], "b",
                "a = 2 and r = 3: S(5) = 2(3⁵ − 1)/(3 − 1) = 242."),
            mcq("Probability", "Two fair coins are tossed. Find P(at least one head).",
                ["1/4", "1/2", "3/4", "1"], "c",
                "P(no heads) = 1/4, so P(at least one head) = 1 − 1/4 = 3/4."),
            mcq("Coordinate geometry", "Find the centre of the circle x² + y² − 6x + 8y = 0.",
                ["(3, −4)", "(−3, 4)", "(6, −8)", "(−6, 8)"], "a",
                "Centre = (−D/2, −E/2) = (6/2, −8/2) = (3, −4)."),
            mcq("Inequalities", "Solve 5 − 2x > 1.", ["x > 2", "x < 2", "x > −2", "x < −2"],
                "b", "−2x > −4. Dividing by −2 reverses the sign: x < 2."),
            mcq("Variations", "y varies directly as x². When x = 2, y = 12. Find y when x = 3.",
                ["18", "27", "36", "9"], "b",
                "y = kx² with k = 12/4 = 3, so y = 3 × 9 = 27."),
            short("Exponents", "Solve 3ˣ = 81.", "4", "81 = 3⁴, so x = 4."),
            short("Coordinate geometry", "Find the slope of the line through (2, 3) and (6, 11).",
                  "2", "Slope = (11 − 3)/(6 − 2) = 8/4 = 2."),
        ],
        "assessments": [("Algebra and functions check", "quiz", 10, 15),
                        ("Compulsory Part mini test", "test", 25, 40)],
    },
    {
        "subject": "MATH", "level": "advanced", "name": "Challenge (Level 5-5**)",
        "description": "Harder Paper 1 and Paper 2 style reasoning.",
        "questions": [
            mcq("Quadratics", "α and β are the roots of x² − 3x − 5 = 0. Find α² + β².",
                ["−1", "19", "9", "14"], "b",
                "α + β = 3 and αβ = −5, so α² + β² = (α + β)² − 2αβ = 9 + 10 = 19."),
            mcq("Trigonometry", "How many solutions does sin x = 0.3 have for 0° ≤ x < 360°?",
                ["1", "2", "3", "4"], "b",
                "sin x is positive in quadrants I and II, giving two solutions."),
            mcq("Logarithms", "Solve log₃ x + log₃ (x − 8) = 2.",
                ["x = 9", "x = −1", "x = 9 or x = −1", "x = 3"], "a",
                "x(x − 8) = 9 gives x = 9 or x = −1. A logarithm needs x > 8, so x = 9."),
            mcq("Complex numbers", "Simplify (1 + i)².", ["2", "2i", "0", "−2i"], "b",
                "(1 + i)² = 1 + 2i + i² = 1 + 2i − 1 = 2i."),
            mcq("Probability",
                "3 people are chosen at random from 5 boys and 4 girls. "
                "Find P(exactly 2 girls).", ["5/14", "3/14", "10/21", "1/6"], "a",
                "C(4,2) × C(5,1) / C(9,3) = 6 × 5 / 84 = 30/84 = 5/14."),
            short("Sequences", "Find the sum to infinity of 12 + 6 + 3 + ...", "24",
                  "a = 12 and r = 1/2, so S = 12 / (1 − 1/2) = 24."),
        ],
        "assessments": [("Challenge set", "quiz", 6, 15)],
    },
    {
        "subject": "PHY", "level": "standard", "name": "Physics core ideas",
        "description": "Motion, heat, electricity and waves.",
        "questions": [
            mcq("Motion", "A car accelerates uniformly from rest to 20 m/s in 5 s. "
                "Find its acceleration.", ["4 m/s²", "5 m/s²", "100 m/s²", "0.25 m/s²"], "a",
                "a = (v − u)/t = (20 − 0)/5 = 4 m/s²."),
            mcq("Energy", "What is the SI unit of power?", ["joule", "watt", "newton", "pascal"],
                "b", "Power is energy per unit time: 1 W = 1 J/s."),
            mcq("Heat", "How much energy heats 2 kg of water by 10 °C? "
                "(c = 4200 J kg⁻¹ °C⁻¹)", ["8 400 J", "84 000 J", "42 000 J", "840 000 J"], "b",
                "E = mcΔT = 2 × 4200 × 10 = 84 000 J."),
            mcq("Electricity", "A 12 V supply is connected across a 4 Ω resistor. "
                "Find the current.", ["48 A", "3 A", "0.33 A", "16 A"], "b",
                "I = V/R = 12/4 = 3 A."),
            mcq("Waves", "A sound wave has speed 340 m/s and frequency 170 Hz. "
                "Find its wavelength.", ["0.5 m", "2 m", "57 800 m", "510 m"], "b",
                "λ = v/f = 340/170 = 2 m."),
            short("Forces", "Find the weight of a 5 kg mass in newtons (g = 9.81 m/s²).",
                  "49.05|49.1|49", "W = mg = 5 × 9.81 = 49.05 N."),
        ],
        "assessments": [("Physics quick check", "quiz", 6, 10)],
    },
    {
        "subject": "ICT", "level": "standard", "name": "ICT essentials",
        "description": "Data representation, hardware, networks and spreadsheets.",
        "questions": [
            mcq("Data representation", "What is binary 1011 in denary?",
                ["9", "10", "11", "13"], "c", "1011₂ = 8 + 0 + 2 + 1 = 11."),
            mcq("Hardware", "Which of these is an input device?",
                ["Monitor", "Printer", "Scanner", "Speaker"], "c",
                "A scanner sends data into the computer; the others are output devices."),
            mcq("Data representation", "How many bits are there in one byte?",
                ["4", "8", "16", "1024"], "b", "One byte is 8 bits."),
            mcq("Networks", "Which protocol encrypts web traffic between browser and server?",
                ["FTP", "HTTP", "HTTPS", "SMTP"], "c",
                "HTTPS is HTTP over TLS, which encrypts the connection."),
            mcq("Spreadsheets", "Which spreadsheet function returns the largest value in a range?",
                ["SUM", "MAX", "COUNT", "AVERAGE"], "b", "MAX returns the largest value."),
            short("Data representation", "Convert denary 255 to hexadecimal.", "FF",
                  "255 = 15 × 16 + 15, and 15 is F in hexadecimal, so 255 = FF."),
        ],
        "assessments": [("ICT basics", "quiz", 6, 10)],
    },
]


def main() -> None:
    app = make_app()
    with app.app_context():
        created_banks = created_q = created_a = 0
        for spec in BANKS:
            bank = db.session.execute(db.select(QuestionBank).where(
                QuestionBank.subject_code == spec["subject"], QuestionBank.level == spec["level"],
                QuestionBank.name == spec["name"])).scalar_one_or_none()
            if bank is not None:
                continue
            bank = QuestionBank(subject_code=spec["subject"], level=spec["level"],
                                name=spec["name"], description=spec["description"])
            db.session.add(bank)
            db.session.flush()
            created_banks += 1
            for q in spec["questions"]:
                db.session.add(Question(bank_id=bank.id, **q))
                created_q += 1
            for title, kind, count, minutes in spec["assessments"]:
                rules = C.ASSESSMENT_RULES[kind]
                db.session.add(Assessment(
                    title=title, bank_id=bank.id, subject_code=bank.subject_code,
                    level=bank.level, kind=kind, question_count=count, time_limit_min=minutes,
                    points_base=rules["base"], points_bonus_max=rules["bonus_max"],
                    is_published=True))
                created_a += 1
        db.session.commit()
        print(f"Created {created_banks} question banks, {created_q} questions and "
              f"{created_a} published assessments.")


if __name__ == "__main__":
    main()
