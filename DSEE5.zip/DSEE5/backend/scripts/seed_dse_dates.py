"""Load app/data/dse_dates.json into the DSE countdown.

    Run from backend/:  python scripts/seed_dse_dates.py

Hong Kong times are converted to UTC before saving. Events that already exist with the
same title and time are skipped, so it is safe to run again after editing the file.
"""
import json
from pathlib import Path

from _bootstrap import make_app

from app import constants as C
from app.extensions import db
from app.models.dse_event import DseEvent
from app.utils.time_utils import parse_datetime

DATA = Path(__file__).resolve().parents[1] / "app" / "data" / "dse_dates.json"


def main() -> None:
    app = make_app()
    raw = json.loads(DATA.read_text(encoding="utf-8"))
    events = raw["events"] if isinstance(raw, dict) else raw
    with app.app_context():
        added = skipped = 0
        for item in events:
            subject = item.get("subject")
            if subject and subject not in C.SUBJECT_CODES:
                print(f"Skipping unknown subject {subject!r} in {item.get('title_en')}")
                continue
            starts_at = parse_datetime(item["starts_at"])
            exists = db.session.execute(db.select(DseEvent.id).where(
                DseEvent.title_en == item["title_en"], DseEvent.starts_at == starts_at)).first()
            if exists:
                skipped += 1
                continue
            db.session.add(DseEvent(title_en=item["title_en"], title_zh=item["title_zh"],
                                    subject_code=subject, kind=item.get("kind", "exam"),
                                    starts_at=starts_at,
                                    is_published=item.get("published", True)))
            added += 1
        db.session.commit()
        print(f"Added {added} DSE dates, skipped {skipped} that already existed.")


if __name__ == "__main__":
    main()
