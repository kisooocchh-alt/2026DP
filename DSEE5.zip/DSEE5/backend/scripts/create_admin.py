"""Create or reset the hidden admin account.

    Run from backend/:  python scripts/create_admin.py
    Options:            --username NAME   (otherwise you are asked)
                        --no-qr           (do not draw the QR code in the terminal)

This is the ONLY way an admin account is ever created. The password is typed with
getpass (not shown, not saved in terminal history) and must be at least 16 characters.
Store it in a password manager - never in code, Git, chats or documents.
"""
import argparse
import getpass
import sys

from _bootstrap import make_app

from app.extensions import db
from app.models.admin import AdminAccount
from app.security import totp
from app.security.passwords import ADMIN_MIN_LENGTH, hash_password, password_problems


def main() -> None:
    parser = argparse.ArgumentParser(description="Create or reset the DSEE5 admin account")
    parser.add_argument("--username")
    parser.add_argument("--no-qr", action="store_true")
    args = parser.parse_args()

    app = make_app()
    with app.app_context():
        username = (args.username or input("Admin username: ")).strip()
        if not (3 <= len(username) <= 40):
            sys.exit("The username must be 3-40 characters.")
        password = getpass.getpass(f"Admin password (min {ADMIN_MIN_LENGTH} characters): ")
        if password != getpass.getpass("Type it again: "):
            sys.exit("Passwords do not match.")
        problems = password_problems(password, username, min_length=ADMIN_MIN_LENGTH)
        if problems:
            sys.exit("Weak password: " + ", ".join(problems))

        admin = db.session.execute(
            db.select(AdminAccount).where(AdminAccount.username == username)
        ).scalar_one_or_none()
        created = admin is None
        if created:
            admin = AdminAccount(username=username)
            db.session.add(admin)
        admin.password_hash = hash_password(password)
        admin.totp_secret = totp.new_secret()
        admin.totp_last_timecode = None
        admin.failed_attempts = 0
        admin.locked_until = None
        db.session.commit()

        uri = totp.provisioning_uri(admin.totp_secret, username)
        print(f"\nAdmin account {'created' if created else 'reset'}: {username}")
        print("\nAdd this to your authenticator app (Google / Microsoft Authenticator):")
        print(f"  Secret key: {admin.totp_secret}")
        print(f"  Setup link: {uri}")
        if not args.no_qr:
            import qrcode
            qr = qrcode.QRCode(border=1)
            qr.add_data(uri)
            print("\nOr scan this QR code:")
            qr.print_ascii(invert=True)
        print(f"\nHidden login page: http://127.0.0.1:5000{app.config['ADMIN_URL_PREFIX']}/login")
        print("(On the real server, use your domain instead of 127.0.0.1:5000.)")


if __name__ == "__main__":
    main()
