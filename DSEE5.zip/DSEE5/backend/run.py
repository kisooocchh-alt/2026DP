"""Start the development server:  python run.py  (or press F5 in VS Code).

Open http://127.0.0.1:5000 in your browser. The server restarts by itself when you
save a Python file.
"""
import os

from app import create_app
from app.extensions import socketio
from app.tasks.scheduler import start_scheduler

app = create_app(os.getenv("APP_CONFIG", "development"))

if __name__ == "__main__":
    # With the auto-reloader Flask runs this file twice; start background jobs only once.
    if os.environ.get("WERKZEUG_RUN_MAIN") == "true":
        start_scheduler(app)
    socketio.run(app, host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=True)
