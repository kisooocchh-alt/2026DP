"""The protections: hidden admin, IP blocks, uploads, headers, privacy and CSRF."""
import io

from PIL import Image

from app.extensions import db
from app.models import ActivityLog, BlockedIP, User
from app.security import ip_tracker
from conftest import PDF_BYTES, png_bytes, register


def test_admin_area_is_a_normal_404(client, app):
    prefix = app.config["ADMIN_URL_PREFIX"]
    for path in (f"{prefix}/", f"{prefix}/users", f"{prefix}/assets/admin.css",
                 f"{prefix}/api/papers"):
        res = client.get(path)
        assert res.status_code == 404
        assert b"Page not found" in res.data or b"404" in res.data
    assert client.get(f"{prefix}/login").status_code == 200


def test_user_login_gives_no_admin_access(student, app):
    prefix = app.config["ADMIN_URL_PREFIX"]
    assert student.get(f"{prefix}/").status_code == 404
    assert student.post(f"{prefix}/api/users/1/block", json={}).status_code == 404


def test_blocked_ip_is_rejected(client, app):
    with app.app_context():
        db.session.add(BlockedIP(ip="127.0.0.1", reason="test", created_by="test"))
        db.session.commit()
        ip_tracker.invalidate_block_cache()
    res = client.get("/api/subjects")
    assert res.status_code == 403
    assert res.get_json()["error"] == "ip_blocked"


def test_blocked_user_is_logged_out(student, app, admin_client):
    with app.app_context():
        user_id = db.session.execute(db.select(User.id)).scalar_one()
    prefix = app.config["ADMIN_URL_PREFIX"]
    res = admin_client.post(f"{prefix}/api/users/{user_id}/block", json={"reason": "spam"})
    assert res.status_code == 200
    assert student.get("/api/auth/me").get_json()["user"] is None
    assert student.get("/api/score").status_code == 401


def test_renamed_file_is_refused(student):
    fake = io.BytesIO(b"MZ\x90\x00 this is really a program")
    res = student.post("/api/profile/avatar", data={"avatar": (fake, "cute.png")},
                       content_type="multipart/form-data")
    assert res.status_code == 400
    assert res.get_json()["error"] == "bad_file_type"


def test_uploaded_photo_loses_exif(student, app):
    res = student.post("/api/profile/avatar", data={"avatar": (png_bytes(exif=True), "me.jpg")},
                       content_type="multipart/form-data")
    assert res.status_code == 200
    url = res.get_json()["avatar_url"]
    img = student.get(url)
    assert img.status_code == 200
    saved = Image.open(io.BytesIO(img.data))
    assert saved.format == "WEBP"
    assert not saved.getexif()


def test_pdf_with_javascript_is_refused(app):
    from werkzeug.datastructures import FileStorage

    from app.services import upload_service
    bad = PDF_BYTES.replace(b"/Type /Catalog", b"/Type /Catalog /OpenAction << /JavaScript >>")
    with app.test_request_context():
        try:
            upload_service.save_pdf(FileStorage(io.BytesIO(bad), "x.pdf"), "papers")
            raise AssertionError("should have refused")
        except upload_service.UploadError as e:
            assert e.code == "unsafe_pdf"


def test_hidden_pdf_actions_are_found():
    import zlib

    from app.services.upload_service import _pdf_has_danger
    escaped = PDF_BYTES.replace(b"/Type /Catalog", b"/Type /Catalog /S /Java#53cript")
    packed = PDF_BYTES + (b"5 0 obj << /Type /ObjStm /Filter /FlateDecode >>\nstream\n"
                          + zlib.compress(b"<< /S /Launch /F (cmd.exe) >>")
                          + b"\nendstream\nendobj\n")
    assert not _pdf_has_danger(PDF_BYTES)
    assert _pdf_has_danger(escaped)
    assert _pdf_has_danger(packed)


def test_security_headers(client):
    res = client.get("/")
    assert res.status_code == 200
    csp = res.headers["Content-Security-Policy"]
    assert "default-src 'self'" in csp and "frame-ancestors 'none'" in csp
    assert res.headers["X-Frame-Options"] == "DENY"
    assert res.headers["X-Content-Type-Options"] == "nosniff"
    assert "dsee5_did" in res.headers.get("Set-Cookie", "")


def test_privacy_settings_filter_profile(app, student, student2):
    student.put("/api/profile", json={"contact": "WhatsApp 9123 4567"})
    student.put("/api/profile/privacy", json={"show_age": "nobody", "show_school": "everyone",
                                              "show_contact": "nobody"})
    seen = student2.get("/api/users/student1").get_json()["profile"]
    assert "age" not in seen and "contact" not in seen
    assert seen["school"] == "Test College"
    anonymous = app.test_client().get("/api/users/student1").get_json()["profile"]
    assert "contact" not in anonymous
    own = student.get("/api/users/student1").get_json()["profile"]
    assert own["contact"].startswith("WhatsApp")


def test_attack_probe_is_logged(client, app):
    res = client.get("/wp-admin/install.php")
    assert res.status_code == 404
    with app.app_context():
        assert db.session.execute(
            db.select(ActivityLog).where(ActivityLog.action == "security.probe")).first()


def test_csrf_is_required_when_enabled(app, client):
    app.config["WTF_CSRF_ENABLED"] = True
    res = client.post("/api/auth/login", json={"username": "a", "password": "b"})
    assert res.status_code == 400
    assert res.get_json()["error"] == "csrf_failed"
    token = client.get("/api/auth/csrf").get_json()["csrf_token"]
    res = client.post("/api/auth/login", json={"username": "a", "password": "b"},
                      headers={"X-CSRFToken": token})
    assert res.get_json()["error"] == "invalid_credentials"


def test_minor_cannot_post_contact_details(app, client):
    from app.utils.time_utils import hk_today
    register(client, "student", "teen_user", birth_year=hk_today().year - 15)
    from app.services import moderation_service
    assert moderation_service.contains_contact_info("call me 9123 4567")
    assert moderation_service.contains_contact_info("my ig: abc")
    assert not moderation_service.contains_contact_info("the answer is 12345678")


def test_banned_words(app):
    from app.services import moderation_service
    assert moderation_service.contains_banned_words("you are a b1tch")
    assert moderation_service.contains_banned_words("仆街啦")
    assert not moderation_service.contains_banned_words("Physics paper 2 was hard")
    assert not moderation_service.contains_banned_words("Find the shift in the graph")


def test_signup_limit_per_network(app):
    codes = []
    for i in range(4):
        c = app.test_client()
        codes.append(register(c, "student", f"same_net_{i}").status_code)
    assert codes == [201, 201, 201, 429]
