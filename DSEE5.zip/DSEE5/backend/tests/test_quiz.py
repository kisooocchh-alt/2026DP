"""Timed quizzes, tests and exams."""
from datetime import timedelta

from app.extensions import db
from app.models import Attempt
from app.services import quiz_service
from app.utils.time_utils import utcnow


def _start(client, assessment_id):
    return client.post(f"/api/quizzes/{assessment_id}/start")


def test_start_hides_answers(student, quiz):
    res = _start(student, quiz.id)
    assert res.status_code == 201
    attempt = res.get_json()["attempt"]
    assert len(attempt["questions"]) == 5
    for q in attempt["questions"]:
        assert "correct_answer" not in q and "explanation" not in q
    assert attempt["expires_at"] and attempt["server_now"]


def test_only_one_attempt_at_a_time(student, quiz):
    first = _start(student, quiz.id).get_json()["attempt"]
    second = _start(student, quiz.id)
    assert second.status_code == 409
    assert second.get_json()["attempt_id"] == first["id"]


def _answer_all(attempt, correct=True):
    answers = {}
    for q in attempt["questions"]:
        if q["type"] == "mcq":
            answers[str(q["id"])] = "a" if correct else "b"
        else:
            answers[str(q["id"])] = "(x + 3)(x − 3)" if correct else "no idea"
    return answers


def test_submit_marks_and_awards_points(app, student, quiz):
    attempt = _start(student, quiz.id).get_json()["attempt"]
    with app.app_context():                       # pretend 5 minutes have passed
        row = db.session.get(Attempt, attempt["id"])
        row.started_at -= timedelta(minutes=5)
        row.expires_at -= timedelta(minutes=5)
        db.session.commit()
    answers = _answer_all(attempt)
    saved = student.patch(f"/api/attempts/{attempt['id']}/answers", json={"answers": answers})
    assert saved.get_json()["saved"] == 5
    res = student.post(f"/api/attempts/{attempt['id']}/submit")
    summary = res.get_json()["attempt"]
    assert summary["raw_score"] == 5 and summary["percent"] == 100
    assert summary["points_awarded"] == 15               # 5 base + 10 bonus
    assert res.get_json()["score"] == 35
    result = student.get(f"/api/attempts/{attempt['id']}/result").get_json()["result"]
    topics = {t["topic"]: t for t in result["topics"]}
    assert topics["Algebra"]["correct"] == 3 and topics["Geometry"]["total"] == 2
    assert all("explanation" in q for q in result["questions"])


def test_rushing_with_wrong_answers_gives_no_points(student, quiz):
    attempt = _start(student, quiz.id).get_json()["attempt"]
    res = student.post(f"/api/attempts/{attempt['id']}/submit",
                       json={"answers": _answer_all(attempt, correct=False)})
    summary = res.get_json()["attempt"]
    assert summary["points_awarded"] == 0
    result = student.get(f"/api/attempts/{attempt['id']}/result").get_json()["result"]
    assert result["points_reason"] == "too_fast"


def test_answers_after_the_deadline_are_refused(app, student, quiz):
    attempt = _start(student, quiz.id).get_json()["attempt"]
    with app.app_context():
        row = db.session.get(Attempt, attempt["id"])
        row.expires_at = utcnow() - timedelta(minutes=2)
        db.session.commit()
    res = student.patch(f"/api/attempts/{attempt['id']}/answers",
                        json={"answers": _answer_all(attempt)})
    assert res.status_code == 409 and res.get_json()["error"] == "time_up"


def test_overdue_attempts_are_submitted_automatically(app, student, quiz):
    attempt = _start(student, quiz.id).get_json()["attempt"]
    with app.app_context():
        row = db.session.get(Attempt, attempt["id"])
        row.expires_at = utcnow() - timedelta(minutes=2)
        db.session.commit()
        assert quiz_service.expire_overdue() == 1
        assert db.session.get(Attempt, attempt["id"]).status == "expired"


def test_cannot_see_someone_elses_attempt(student, student2, quiz):
    attempt = _start(student, quiz.id).get_json()["attempt"]
    assert student2.get(f"/api/attempts/{attempt['id']}").status_code == 404


def test_short_answer_marking(app):
    from app.models import Question
    q = Question(qtype="short", prompt="?", answer="0.5|1/2")
    assert quiz_service.is_correct(q, "1/2")
    assert quiz_service.is_correct(q, " 0.50 ")
    assert quiz_service.is_correct(q, "0.5000")
    assert not quiz_service.is_correct(q, "0.6")
    text = Question(qtype="short", prompt="?", answer="FF")
    assert quiz_service.is_correct(text, "ff")
