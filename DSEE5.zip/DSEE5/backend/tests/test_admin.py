"""Admin powers and the hidden admin login."""
import io

import pyotp

from app.extensions import db
from app.models import ActivityLog, Material, PastPaper, Report, User
from conftest import ADMIN_PASSWORD, ADMIN_SECRET, PDF_BYTES, png_bytes


def test_admin_login_needs_password_and_code(app, client, admin_account):
    prefix = app.config["ADMIN_URL_PREFIX"]
    no_code = client.post(f"{prefix}/login", data={"username": "boss",
                                                   "password": ADMIN_PASSWORD, "code": ""})
    assert no_code.status_code == 400
    ok = client.post(f"{prefix}/login", data={"username": "boss", "password": ADMIN_PASSWORD,
                                              "code": pyotp.TOTP(ADMIN_SECRET).now()})
    assert ok.status_code == 302
    assert client.get(f"{prefix}/").status_code == 200


def test_admin_locks_after_three_failures(app, client, admin_account):
    prefix = app.config["ADMIN_URL_PREFIX"]
    for _ in range(3):
        client.post(f"{prefix}/login", data={"username": "boss", "password": "wrong",
                                             "code": "123456"})
    res = client.post(f"{prefix}/login", data={"username": "boss", "password": ADMIN_PASSWORD,
                                               "code": pyotp.TOTP(ADMIN_SECRET).now()})
    assert res.status_code == 400


def test_every_admin_page_renders(app, admin_client, student, quiz):
    prefix = app.config["ADMIN_URL_PREFIX"]
    for page in ("/", "/users", "/users/1", "/papers", "/materials", "/quiz-bank",
                 f"/quiz-bank/{quiz.bank_id}", "/chat", "/reports", "/security", "/dse-dates"):
        res = admin_client.get(prefix + page)
        assert res.status_code == 200, page
        assert b"<main" in res.data


def test_upload_and_delete_paper(app, admin_client, student):
    prefix = app.config["ADMIN_URL_PREFIX"]
    res = admin_client.post(f"{prefix}/api/papers", data={
        "subject": "MATH", "year": "2024", "paper": "Paper 1", "language": "en",
        "file": (io.BytesIO(PDF_BYTES), "p1.pdf")}, content_type="multipart/form-data")
    assert res.status_code == 201, res.get_json()
    paper_id = res.get_json()["id"]
    listed = student.get("/api/papers?subject=MATH").get_json()
    assert listed["papers"][0]["year"] == 2024 and listed["years"] == [2024]
    dl = student.get(f"/api/papers/{paper_id}/download")
    assert dl.status_code == 200 and dl.data.startswith(b"%PDF")
    assert "attachment" in dl.headers["Content-Disposition"]
    dup = admin_client.post(f"{prefix}/api/papers", data={
        "subject": "MATH", "year": "2024", "paper": "Paper 1", "language": "en",
        "file": (io.BytesIO(PDF_BYTES), "p1.pdf")}, content_type="multipart/form-data")
    assert dup.status_code == 409
    assert admin_client.delete(f"{prefix}/api/papers/{paper_id}").status_code == 200
    with app.app_context():
        assert db.session.get(PastPaper, paper_id) is None


def test_materials_lifecycle(app, admin_client, student):
    prefix = app.config["ADMIN_URL_PREFIX"]
    res = admin_client.post(f"{prefix}/api/materials", data={
        "subject": "PHY", "topic": "Waves", "title": "Wave basics", "kind": "image",
        "language": "en", "allow_download": "true", "published": "false",
        "file": (png_bytes(), "waves.png")}, content_type="multipart/form-data")
    assert res.status_code == 201, res.get_json()
    material_id = res.get_json()["id"]
    assert student.get("/api/materials").get_json()["items"] == []
    admin_client.post(f"{prefix}/api/materials/{material_id}/publish", json={"published": True})
    items = student.get("/api/materials?subject=PHY").get_json()["items"]
    assert items[0]["title"] == "Wave basics"
    assert student.get(f"/api/materials/{material_id}/file").status_code == 200
    video = admin_client.post(f"{prefix}/api/materials", data={
        "subject": "PHY", "title": "Bad link", "kind": "video_link", "language": "en",
        "url": "http://evil.example.com/x"}, content_type="multipart/form-data")
    assert video.get_json()["fields"]["url"] == "url_invalid"
    assert admin_client.delete(f"{prefix}/api/materials/{material_id}").status_code == 200
    with app.app_context():
        assert db.session.get(Material, material_id) is None


def test_block_unblock_and_points(app, admin_client, student):
    prefix = app.config["ADMIN_URL_PREFIX"]
    with app.app_context():
        user_id = db.session.execute(db.select(User.id)).scalar_one()
    assert admin_client.post(f"{prefix}/api/users/{user_id}/points",
                             json={"amount": 30, "reason": "Contest prize"}).status_code == 200
    assert student.get("/api/score").get_json()["score"] == 50
    admin_client.post(f"{prefix}/api/users/{user_id}/block", json={"reason": "spam"})
    login = student.post("/api/auth/login", json={"username": "student1",
                                                  "password": "Correct-horse-42"})
    assert login.get_json()["error"] == "account_blocked"
    admin_client.post(f"{prefix}/api/users/{user_id}/unblock")
    login = student.post("/api/auth/login", json={"username": "student1",
                                                  "password": "Correct-horse-42"})
    assert login.status_code == 200


def test_report_action_mutes_user(app, admin_client, student, student2):
    with app.app_context():
        target = db.session.execute(db.select(User).where(User.username == "student1")).scalar_one()
        target_id = target.id
    res = student2.post("/api/reports", json={"target_type": "user", "target_id": target_id,
                                              "reason": "harassment", "details": "rude"})
    report_id = res.get_json()["report_id"]
    prefix = app.config["ADMIN_URL_PREFIX"]
    res = admin_client.post(f"{prefix}/api/reports/{report_id}/action",
                            json={"action": "mute", "reason": "Rude in chat", "minutes": 60})
    assert res.status_code == 200 and res.get_json()["closed"] == 1
    with app.app_context():
        assert db.session.get(Report, report_id).status == "actioned"
        assert db.session.get(User, target_id).is_muted


def test_quiz_bank_and_csv_import(app, admin_client):
    prefix = app.config["ADMIN_URL_PREFIX"]
    bank = admin_client.post(f"{prefix}/api/banks", json={
        "subject": "ICT", "level": "foundation", "name": "Imported"}).get_json()["id"]
    csv_text = ("topic,type,prompt,option_a,option_b,option_c,option_d,answer,explanation,marks\n"
                "Binary,mcq,What is 10 in binary?,1010,1001,1100,1110,a,8+2,1\n"
                "Hex,short,Write 15 in hex,,,,,F,15 = F,1\n")
    preview = admin_client.post(f"{prefix}/api/banks/{bank}/import", data={
        "preview": "1", "file": (io.BytesIO(csv_text.encode()), "q.csv")},
        content_type="multipart/form-data").get_json()
    assert preview["valid"] == 2 and preview["saved"] == 0
    saved = admin_client.post(f"{prefix}/api/banks/{bank}/import", data={
        "file": (io.BytesIO(csv_text.encode()), "q.csv")},
        content_type="multipart/form-data").get_json()
    assert saved["saved"] == 2
    res = admin_client.post(f"{prefix}/api/assessments", json={
        "bank_id": bank, "kind": "quiz", "title": "Binary quiz", "published": True})
    assert res.status_code == 201


def test_admin_actions_are_logged(app, admin_client):
    prefix = app.config["ADMIN_URL_PREFIX"]
    admin_client.post(f"{prefix}/api/ips/block", json={"ip": "203.0.113.9", "hours": 2,
                                                       "reason": "scanner"})
    with app.app_context():
        actions = set(db.session.execute(db.select(ActivityLog.action)).scalars())
    assert {"admin.login", "admin.block_ip", "security.ip_blocked"} <= actions


def test_dse_events(app, admin_client, client):
    prefix = app.config["ADMIN_URL_PREFIX"]
    res = admin_client.post(f"{prefix}/api/dse-events", json={
        "title_en": "Physics", "title_zh": "物理", "subject": "PHY", "kind": "exam",
        "starts_at": "2099-04-21T08:30", "published": True})
    assert res.status_code == 201
    events = client.get("/api/countdown/events").get_json()["events"]
    assert events[0]["starts_at"] == "2099-04-21T08:30:00+08:00"
