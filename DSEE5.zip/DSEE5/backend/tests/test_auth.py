"""Sign-up, login, logout, two-factor login and password changes."""
import pyotp

from app.extensions import db
from app.models import User
from conftest import PASSWORD, register


def test_register_student_logs_in_and_gives_bonus(client):
    res = register(client, "student", "Amy_Chan")
    assert res.status_code == 201
    user = res.get_json()["user"]
    assert user["username"] == "Amy_Chan"
    assert user["role"] == "student"
    assert user["score"] == 20
    assert user["student"]["school"] == "Test College"
    me = client.get("/api/auth/me").get_json()
    assert me["user"]["username"] == "Amy_Chan"


def test_register_tutor_needs_subjects_and_results(client):
    res = register(client, "tutor", "tutor_x", teaching_subjects=[], dse_results=[])
    assert res.status_code == 400
    fields = res.get_json()["fields"]
    assert fields["teaching_subjects"] == "subjects_required"
    assert fields["dse_results"] == "dse_results_required"
    ok = register(client, "tutor", "tutor_y")
    assert ok.status_code == 201
    assert ok.get_json()["user"]["tutor"]["dse_results"][0]["grade"] == "5**"


def test_register_reports_every_bad_field(client):
    res = client.post("/api/auth/register", json={"role": "student", "username": "x"})
    assert res.status_code == 400
    fields = res.get_json()["fields"]
    for name in ("username", "password", "birth_year", "accept_terms", "dse_goal", "school"):
        assert name in fields


def test_duplicate_username_ignores_case(client, app):
    assert register(client, "student", "Peter").status_code == 201
    other = app.test_client()
    res = register(other, "student", "peter")
    assert res.status_code == 400
    assert res.get_json()["fields"]["username"] == "username_taken"


def test_reserved_username_refused(client):
    res = register(client, "student", "admin")
    assert res.get_json()["fields"]["username"] == "username_taken"


def test_weak_and_common_passwords_refused(client):
    for password, code in (("short1", "password_too_short"),
                           ("onlyletterspassword", "password_needs_letter_and_number"),
                           ("password123", "password_too_common")):
        res = register(client, "student", "newuser", password=password)
        assert res.get_json()["fields"]["password"] == code


def test_login_same_error_for_unknown_user_and_wrong_password(client, app):
    register(client, "student", "real_user")
    client.post("/api/auth/logout")
    wrong = client.post("/api/auth/login",
                        json={"username": "real_user", "password": "Nope-123456"})
    unknown = client.post("/api/auth/login",
                          json={"username": "ghost", "password": "Nope-123456"})
    assert wrong.status_code == unknown.status_code == 400
    assert wrong.get_json()["error"] == unknown.get_json()["error"] == "invalid_credentials"
    good = client.post("/api/auth/login", json={"username": "REAL_USER", "password": PASSWORD})
    assert good.status_code == 200


def test_account_locks_after_five_failures(client):
    register(client, "student", "lockme")
    client.post("/api/auth/logout")
    for _ in range(5):
        client.post("/api/auth/login", json={"username": "lockme", "password": "Wrong-12345"})
    res = client.post("/api/auth/login", json={"username": "lockme", "password": PASSWORD})
    assert res.get_json()["error"] == "account_locked"


def test_logout_ends_session(student):
    assert student.get("/api/auth/me").get_json()["user"] is not None
    student.post("/api/auth/logout")
    assert student.get("/api/auth/me").get_json()["user"] is None
    assert student.get("/api/score").status_code == 401


def test_two_factor_login_and_recovery_code(student):
    setup = student.post("/api/auth/2fa/setup").get_json()
    assert setup["qr_data_uri"].startswith("data:image/png;base64,")
    totp = pyotp.TOTP(setup["secret"])
    res = student.post("/api/auth/2fa/enable", json={"code": totp.now()})
    codes = res.get_json()["recovery_codes"]
    assert len(codes) == 8
    student.post("/api/auth/logout")

    first = student.post("/api/auth/login", json={"username": "student1", "password": PASSWORD})
    assert first.get_json()["error"] == "totp_required"
    bad = student.post("/api/auth/login", json={"username": "student1", "password": PASSWORD,
                                                "totp_code": "000000"})
    assert bad.get_json()["error"] == "totp_invalid"
    good = student.post("/api/auth/login", json={"username": "student1", "password": PASSWORD,
                                                 "totp_code": codes[0]})
    assert good.status_code == 200
    student.post("/api/auth/logout")
    reuse = student.post("/api/auth/login", json={"username": "student1", "password": PASSWORD,
                                                  "totp_code": codes[0]})
    assert reuse.get_json()["error"] == "totp_invalid"


def test_password_change_logs_out_other_devices(app, student):
    other = app.test_client()
    other.post("/api/auth/login", json={"username": "student1", "password": PASSWORD})
    assert other.get("/api/auth/me").get_json()["user"] is not None
    res = student.post("/api/auth/password", json={"old_password": PASSWORD,
                                                   "new_password": "Brand-new-pass-77"})
    assert res.status_code == 200
    assert student.get("/api/auth/me").get_json()["user"] is not None
    assert other.get("/api/auth/me").get_json()["user"] is None


def test_under_18_gets_private_defaults(client, app):
    from app.utils.time_utils import hk_today
    res = register(client, "student", "young_one", birth_year=hk_today().year - 15)
    user = res.get_json()["user"]
    assert user["is_minor"] is True
    assert user["privacy"]["age"] == "nobody"
    assert user["privacy"]["contact"] == "nobody"
    res = client.put("/api/profile/privacy", json={"show_age": "everyone",
                                                    "show_school": "members",
                                                    "show_contact": "everyone"})
    privacy = res.get_json()["user"]["privacy"]
    assert privacy["contact"] == "members" and privacy["age"] == "members"


def test_delete_account_removes_personal_data(app, student):
    res = student.post("/api/profile/delete", json={"password": PASSWORD})
    assert res.status_code == 200
    with app.app_context():
        user = db.session.execute(db.select(User)).scalars().first()
        assert user.is_deleted and user.username.startswith("deleted_")
        assert user.contact is None
    assert student.get("/api/auth/me").get_json()["user"] is None


def test_sign_up_keeps_the_page_language(client, app):
    res = register(client, "student", "chinese_reader", language="zh-HK")
    assert res.status_code == 201
    assert res.get_json()["user"]["language"] == "zh-HK"
    other = app.test_client()
    other.environ_base["REMOTE_ADDR"] = "10.0.0.9"
    res = register(other, "student", "odd_language", language="fr")
    assert res.get_json()["user"]["language"] == "en"
