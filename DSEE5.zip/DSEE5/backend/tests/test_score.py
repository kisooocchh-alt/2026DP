"""The points economy."""
from datetime import timedelta

import pytest

from app.extensions import db
from app.models import User
from app.services import score_service
from app.utils.time_utils import hk_today


def _user(app):
    return db.session.execute(db.select(User)).scalars().first()


def test_daily_reward_once_per_day(student):
    first = student.post("/api/score/daily")
    assert first.status_code == 200
    assert first.get_json()["amount"] == 10
    assert first.get_json()["score"] == 30
    again = student.post("/api/score/daily")
    assert again.status_code == 409
    assert again.get_json()["error"] == "already_claimed"
    summary = student.get("/api/score").get_json()
    assert summary["claimed_today"] is True


def test_streak_grows_and_is_capped(app, student):
    with app.app_context():
        user = _user(app)
        user.last_daily_claim = hk_today() - timedelta(days=1)
        user.login_streak = 3
        db.session.commit()
    res = student.post("/api/score/daily").get_json()
    assert res["streak"] == 4 and res["amount"] == 16
    with app.app_context():
        user = _user(app)
        user.last_daily_claim = hk_today() - timedelta(days=1)
        user.login_streak = 30
        db.session.commit()
    assert score_service.daily_amount_for_streak(31) == 20


def test_missed_day_resets_streak(app, student):
    with app.app_context():
        user = _user(app)
        user.last_daily_claim = hk_today() - timedelta(days=3)
        user.login_streak = 9
        db.session.commit()
    assert student.post("/api/score/daily").get_json()["streak"] == 1


def test_spending_needs_enough_points(app, student):
    with app.app_context():
        user = _user(app)
        with pytest.raises(score_service.NotEnoughPoints):
            score_service.spend_points(user.id, 999, "chat_message")
        db.session.rollback()
        score_service.spend_points(user.id, 5, "chat_message")
        db.session.commit()
        db.session.refresh(user)
        assert user.score == 15


def test_penalty_never_goes_below_zero(app, student):
    with app.app_context():
        user = _user(app)
        taken = score_service.take_points(user.id, 500, "penalty")
        db.session.commit()
        db.session.refresh(user)
        assert taken == 20 and user.score == 0


def test_history_records_every_change(student):
    student.post("/api/score/daily")
    items = student.get("/api/score/history").get_json()["items"]
    reasons = {i["reason"] for i in items}
    assert {"signup_bonus", "daily_reward"} <= reasons
