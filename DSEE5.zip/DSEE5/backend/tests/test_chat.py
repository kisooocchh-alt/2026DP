"""Real-time chat through Flask-SocketIO's test client."""
from app.extensions import db, socketio
from app.models import Message, User
from conftest import png_bytes

NS = "/chat"


def connect(app, http_client):
    return socketio.test_client(app, namespace=NS, flask_test_client=http_client)


def test_connection_refused_without_login(app, client):
    sio = connect(app, client)
    assert not sio.is_connected(NS)


def test_join_unknown_subject(app, student):
    sio = connect(app, student)
    assert sio.is_connected(NS)
    reply = sio.emit("join", {"subject": "MAGIC"}, namespace=NS, callback=True)
    assert reply == {"ok": False, "error": "unknown_subject"}


def test_message_costs_points_and_reaches_the_room(app, student, student2):
    a, b = connect(app, student), connect(app, student2)
    assert a.emit("join", {"subject": "MATH"}, namespace=NS, callback=True)["ok"]
    assert b.emit("join", {"subject": "MATH"}, namespace=NS, callback=True)["ok"]
    b.get_received(NS)
    reply = a.emit("send_message", {"subject": "MATH", "text": "How do I factorise x^2 - 9?"},
                   namespace=NS, callback=True)
    assert reply["ok"] is True and reply["score"] == 18
    received = [e for e in b.get_received(NS) if e["name"] == "message_new"]
    assert received and received[0]["args"][0]["text"].startswith("How do I")
    history = student2.get("/api/chat/MATH/messages").get_json()["messages"]
    assert len(history) == 1 and history[0]["user"]["username"] == "student1"


def test_message_rules(app, student):
    sio = connect(app, student)
    sio.emit("join", {"subject": "PHY"}, namespace=NS, callback=True)

    def send(text, **extra):
        return sio.emit("send_message", {"subject": "PHY", "text": text, **extra},
                        namespace=NS, callback=True)

    assert send("")["error"] == "empty_message"
    assert send("x" * 1001)["error"] == "message_too_long"
    assert send("what the fuck")["error"] == "blocked_words"
    assert sio.emit("send_message", {"subject": "MATH", "text": "hi"}, namespace=NS,
                    callback=True)["error"] == "join_room_first"
    with app.app_context():
        user = db.session.execute(db.select(User)).scalars().first()
        user.score = 1
        db.session.commit()
    assert send("Is light a wave?")["error"] == "not_enough_points"
    with app.app_context():
        assert db.session.execute(db.select(Message)).first() is None


def test_image_message_costs_five(app, student):
    up = student.post("/api/chat/images", data={"image": (png_bytes(), "graph.png")},
                      content_type="multipart/form-data")
    assert up.status_code == 201
    image_id = up.get_json()["image_id"]
    sio = connect(app, student)
    sio.emit("join", {"subject": "MATH"}, namespace=NS, callback=True)
    reply = sio.emit("send_message", {"subject": "MATH", "text": "", "image_id": image_id},
                     namespace=NS, callback=True)
    assert reply["ok"] and reply["score"] == 15
    url = reply["message"]["image_url"]
    assert student.get(url).status_code == 200
    again = sio.emit("send_message", {"subject": "MATH", "text": "again", "image_id": image_id},
                     namespace=NS, callback=True)
    assert again["error"] == "bad_image"


def test_shadow_banned_messages_only_reach_the_sender(app, student, student2):
    with app.app_context():
        user = db.session.execute(db.select(User).where(User.username == "student1")).scalar_one()
        user.is_shadow_banned = True
        db.session.commit()
    a, b = connect(app, student), connect(app, student2)
    a.emit("join", {"subject": "BIO"}, namespace=NS, callback=True)
    b.emit("join", {"subject": "BIO"}, namespace=NS, callback=True)
    b.get_received(NS)
    assert a.emit("send_message", {"subject": "BIO", "text": "buy my notes"}, namespace=NS,
                  callback=True)["ok"]
    assert not [e for e in b.get_received(NS) if e["name"] == "message_new"]
    assert student2.get("/api/chat/BIO/messages").get_json()["messages"] == []
    assert len(student.get("/api/chat/BIO/messages").get_json()["messages"]) == 1


def test_admin_delete_reaches_the_room(app, student, admin_client):
    sio = connect(app, student)
    sio.emit("join", {"subject": "MATH"}, namespace=NS, callback=True)
    msg = sio.emit("send_message", {"subject": "MATH", "text": "spam spam"}, namespace=NS,
                   callback=True)["message"]
    sio.get_received(NS)
    prefix = app.config["ADMIN_URL_PREFIX"]
    res = admin_client.delete(f"{prefix}/api/messages/{msg['id']}",
                              json={"reason": "spam", "penalty": True})
    assert res.status_code == 200
    events = [e for e in sio.get_received(NS) if e["name"] == "message_deleted"]
    assert events and events[0]["args"][0]["id"] == msg["id"]
    shown = student.get("/api/chat/MATH/messages").get_json()["messages"][0]
    assert shown["deleted"] is True and shown["text"] is None
    assert student.get("/api/score").get_json()["score"] == 8      # 20 - 2 - 10 penalty


def test_three_reports_hide_a_message(app, student, student2):
    sio = connect(app, student)
    sio.emit("join", {"subject": "CHEM"}, namespace=NS, callback=True)
    msg = sio.emit("send_message", {"subject": "CHEM", "text": "rude stuff"}, namespace=NS,
                   callback=True)["message"]
    from conftest import register
    reporters = [student2]
    for i, name in enumerate(("student3", "student4")):
        c = app.test_client()
        c.environ_base["REMOTE_ADDR"] = f"10.0.0.{i + 1}"     # different networks
        assert register(c, "student", name).status_code == 201
        reporters.append(c)
    for c in reporters:
        res = c.post("/api/reports", json={"target_type": "message", "target_id": msg["id"],
                                           "reason": "harassment"})
        assert res.status_code == 201
    again = student2.post("/api/reports", json={"target_type": "message",
                                                "target_id": msg["id"], "reason": "spam"})
    assert again.status_code == 409
    shown = student2.get("/api/chat/CHEM/messages").get_json()["messages"][0]
    assert shown["hidden"] is True and shown["text"] is None


def test_mention_creates_notification(app, student, student2):
    sio = connect(app, student)
    sio.emit("join", {"subject": "MATH"}, namespace=NS, callback=True)
    sio.emit("send_message", {"subject": "MATH", "text": "@student2 can you help?"},
             namespace=NS, callback=True)
    items = student2.get("/api/notifications").get_json()["items"]
    assert items and items[0]["kind"] == "mention"
