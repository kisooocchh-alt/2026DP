"""Shared test set-up: a fresh in-memory database for every test, a test client, and
helpers that create logged-in students, tutors and an admin."""
import io

import pyotp
import pytest
from PIL import Image

from app import constants as C
from app import create_app
from app.extensions import db as _db
from app.models import AdminAccount, Assessment, Question, QuestionBank, Subject
from app.security import abuse_detector, ip_tracker
from app.security.passwords import hash_password
from app.services import analytics_service

PASSWORD = "Correct-horse-42"
ADMIN_PASSWORD = "Admin-password-1234567"
ADMIN_SECRET = pyotp.random_base32()


@pytest.fixture()
def app(tmp_path):
    app = create_app("testing")
    app.config["STORAGE_DIR"] = tmp_path / "storage"
    app.config["BACKUP_DIR"] = tmp_path / "backups"
    from app.services.upload_service import ensure_storage_dirs
    ensure_storage_dirs(app)
    with app.app_context():
        _db.create_all()
        for s in C.SUBJECTS:
            _db.session.add(Subject(code=s["code"], name_en=s["name_en"], name_zh=s["name_zh"],
                                    category=s["category"], sort_order=s["order"]))
        _db.session.commit()
        abuse_detector.reset_chat_state()
        ip_tracker.invalidate_block_cache()
        analytics_service._cache.update(at=0.0, data=None)
        yield app
        _db.session.remove()
        _db.drop_all()


@pytest.fixture()
def client(app):
    return app.test_client()


def register(client, role="student", username="student1", **extra):
    body = {"role": role, "username": username, "password": PASSWORD, "birth_year": 2000,
            "accept_terms": True, "captcha_token": "test"}
    if role == "student":
        body.update(dse_goal="5** in Maths", school="Test College", subjects=["MATH", "PHY"])
    else:
        body.update(teaching_subjects=["MATH", "M2"],
                    dse_results=[{"subject": "MATH", "grade": "5**"}])
    body.update(extra)
    return client.post("/api/auth/register", json=body)


@pytest.fixture()
def student(app):
    c = app.test_client()
    res = register(c, "student", "student1")
    assert res.status_code == 201, res.get_json()
    return c


@pytest.fixture()
def student2(app):
    c = app.test_client()
    assert register(c, "student", "student2").status_code == 201
    return c


@pytest.fixture()
def tutor(app):
    c = app.test_client()
    res = register(c, "tutor", "tutor1")
    assert res.status_code == 201, res.get_json()
    return c


@pytest.fixture()
def admin_account(app):
    admin = AdminAccount(username="boss", password_hash=hash_password(ADMIN_PASSWORD),
                         totp_secret=ADMIN_SECRET)
    _db.session.add(admin)
    _db.session.commit()
    return admin


@pytest.fixture()
def admin_client(app, admin_account):
    c = app.test_client()
    prefix = app.config["ADMIN_URL_PREFIX"]
    res = c.post(f"{prefix}/login", data={"username": "boss", "password": ADMIN_PASSWORD,
                                          "code": pyotp.TOTP(ADMIN_SECRET).now()})
    assert res.status_code == 302, res.data
    return c


@pytest.fixture()
def quiz(app):
    bank = QuestionBank(subject_code="MATH", level="standard", name="Test bank")
    _db.session.add(bank)
    _db.session.flush()
    for i in range(4):
        _db.session.add(Question(
            bank_id=bank.id, topic="Algebra" if i < 2 else "Geometry", qtype="mcq",
            prompt=f"Question {i}", options=[{"id": "a", "text": "right"},
                                             {"id": "b", "text": "wrong"}],
            answer="a", explanation="Because."))
    _db.session.add(Question(bank_id=bank.id, topic="Algebra", qtype="short",
                             prompt="Factorise x^2 - 9", answer="(x+3)(x-3)|(x-3)(x+3)"))
    assessment = Assessment(title="Test quiz", bank_id=bank.id, subject_code="MATH",
                            level="standard", kind="quiz", question_count=5, time_limit_min=10,
                            points_base=5, points_bonus_max=10, is_published=True)
    _db.session.add(assessment)
    _db.session.commit()
    return assessment


def png_bytes(size=(40, 30), color=(200, 30, 60), exif=False) -> io.BytesIO:
    img = Image.new("RGB", size, color)
    buf = io.BytesIO()
    if exif:
        ex = Image.Exif()
        ex[0x010F] = "SecretCameraMaker"              # Make
        img.save(buf, "JPEG", exif=ex.tobytes())
    else:
        img.save(buf, "PNG")
    buf.seek(0)
    return buf


PDF_BYTES = (b"%PDF-1.4\n1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n"
             b"2 0 obj << /Type /Pages /Kids [] /Count 0 >> endobj\ntrailer << /Root 1 0 R >>\n"
             b"%%EOF\n")
