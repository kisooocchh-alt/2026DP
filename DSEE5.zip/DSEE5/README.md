# DSEE5

A bilingual (English / 繁體中文) study website for Hong Kong HKDSE candidates and tutors:
past papers, learning materials, timed quizzes and mock exams, subject discussion rooms with
images, a tutor finder with bookings, points, profiles and a DSE countdown with reminders -
run by a hidden admin area and protected by layered security.

| For students | For tutors | For the admin |
|---|---|---|
| Download past papers and marking schemes | Public tutor profile with wage and DSE results | Upload papers and materials |
| Learning materials, also offline | "Verified" badge after a certificate check | Build question banks and quizzes (CSV import) |
| Quizzes, tests and mock exams at 3 levels, server-timed | Booking requests and ratings | Moderate rooms, handle reports |
| Discussion room per subject, with photos | Help students in the rooms | Warn, mute, block, shadow-ban users |
| Points, daily streak, countdown, notifications | | Security log, IP blocks, related accounts |

**Stack:** Python 3.12, Flask 3, SQLAlchemy 2, Flask-SocketIO, PostgreSQL (SQLite for
development), Redis, nginx. The front end is plain HTML, CSS and JavaScript modules - no build
step - served by the same app.

## Run it on your computer (VS Code)

You need **Python 3.12 or newer** and **VS Code** with the recommended extensions (VS Code
offers them when you open the folder). Node.js is optional (only for linting).

1. **Open the folder** `DSEE5` in VS Code, then open a terminal (*Terminal > New Terminal*).

2. **Create a virtual environment and install packages**

   ```bash
   cd backend
   python -m venv .venv
   # Windows:        .venv\Scripts\activate
   # macOS / Linux:  source .venv/bin/activate
   pip install -r requirements-dev.txt
   ```

   Then choose that interpreter in VS Code (*Python: Select Interpreter* >
   `backend/.venv`), so F5 and the tasks use it.

3. **Create your settings file.** Copy `.env.example` (project root) to `.env` and fill in
   at least these two values:

   ```bash
   python -c "import secrets; print(secrets.token_hex(32))"          # -> SECRET_KEY
   python -c "import secrets; print('/' + secrets.token_urlsafe(12))" # -> ADMIN_URL_PREFIX
   ```

   The CAPTCHA keys in the example are Cloudflare's official test keys: they always pass,
   which is what you want while developing.

4. **Create the database and add starting data** (still in `backend/`):

   ```bash
   flask --app app db upgrade          # creates backend/instance/dsee5.db
   python scripts/seed_subjects.py     # the HKDSE subjects
   python scripts/seed_dse_dates.py    # 2027 HKDSE dates for the countdown
   python scripts/seed_questions.py    # sample Maths, Physics and ICT quizzes
   ```

5. **Create the admin account.** You need an authenticator app on your phone (Google
   Authenticator, Microsoft Authenticator, 1Password...).

   ```bash
   python scripts/create_admin.py
   ```

   Choose a password of at least 16 characters and scan the QR code it prints.

6. **Start the site:** press **F5** (*DSEE5: Flask dev server*) or run `python run.py`, then
   open <http://127.0.0.1:5000>. The admin sign-in page is
   `http://127.0.0.1:5000<ADMIN_URL_PREFIX>/login`. Every other admin address shows the
   normal "page not found" until you sign in.

Most of these steps are also VS Code tasks (*Terminal > Run Task*): "Seed: all", "Create
admin account", "Run tests", "Lint: all", "Check translations".

### Tests and checks

```bash
pytest                                   # from the project root: 60+ tests
ruff check backend                       # Python style and security lint
python backend/scripts/check_locales.py  # every text exists in English and Chinese
npm install && npm run lint              # optional: JavaScript lint
```

## Project layout

```
DSEE5/
├── backend/
│   ├── app/
│   │   ├── models/        database tables
│   │   ├── routes/        pages, JSON API and the hidden admin
│   │   ├── services/      the rules: points, quizzes, chat, moderation, uploads...
│   │   ├── security/      sessions, passwords, 2FA, rate limits, IP tracking, headers
│   │   ├── sockets/       real-time chat
│   │   ├── tasks/         backups, DSE reminders, clean-up
│   │   ├── admin_ui/      admin templates, CSS and JS (served only under the secret path)
│   │   └── data/          subjects, DSE dates, banned words, common passwords
│   ├── migrations/        database changes (Alembic)
│   ├── scripts/           seeding, admin creation, VAPID keys, translation check
│   ├── tests/
│   └── run.py / wsgi.py   development / production entry points
├── frontend/              the public website (pages, css, js, locales, assets)
├── deploy/                nginx, Gunicorn, Dockerfile, docker-compose
└── docs/                  API, database, scoring, security, moderation
```

## Going live

The `deploy/` folder runs DSEE5 on any Linux server with Docker: nginx (HTTPS) in front of
Gunicorn, with PostgreSQL and Redis.

1. Point your domain's DNS at the server and open ports 80 and 443 only.
2. Replace `dsee5.example.com` in `deploy/nginx.conf` with your domain.
3. Get a certificate (port 80 must be free the first time):
   `sudo certbot certonly --standalone -d your.domain`
4. Copy the project to the server and create `.env` from `.env.example` with production
   values: `APP_CONFIG=production`, new `SECRET_KEY`, new `ADMIN_URL_PREFIX`,
   `ALLOWED_ORIGINS=https://your.domain`, a strong `POSTGRES_PASSWORD`, your real Turnstile
   keys, `TRUST_LOCALHOST=false`, and VAPID keys from `python scripts/generate_vapid_keys.py`
   if you want push notifications.
5. Start everything (the app applies database migrations when it starts):

   ```bash
   docker compose --env-file .env -f deploy/docker-compose.yml up -d --build
   docker compose --env-file .env -f deploy/docker-compose.yml exec app python scripts/seed_subjects.py
   docker compose --env-file .env -f deploy/docker-compose.yml exec app python scripts/seed_dse_dates.py
   docker compose --env-file .env -f deploy/docker-compose.yml exec -it app python scripts/create_admin.py
   ```

6. Renew certificates automatically (cron or systemd timer):
   `certbot renew --webroot -w /var/www/certbot --deploy-hook "docker compose -f /path/to/DSEE5/deploy/docker-compose.yml exec nginx nginx -s reload"`
7. Work through the checklist at the top of [docs/SECURITY.md](docs/SECURITY.md).

Optional: download the free GeoLite2-City database from MaxMind and put it in the `instance`
volume (`GEOIP_DB_PATH`) to see visitors' country and city in the security log; set
`CLAMAV_ENABLED=true` and start with `--profile clamav` to virus-scan uploaded PDFs.

**Scaling note:** chat rooms live in memory, so the app runs one Gunicorn process with many
threads (see `deploy/gunicorn.conf.py`). That comfortably serves a few hundred people chatting
at once; beyond that, move Socket.IO to a Redis message queue.

## Every year

- **New HKDSE timetable** (usually published in the autumn): update
  `backend/app/data/dse_dates.json` from the HKEAA timetable and run
  `python scripts/seed_dse_dates.py`, or edit the dates on the admin's *DSE dates* page.
- **Past papers:** upload the new year's papers once you have permission to share them.
- **Restore test:** restore one backup on another machine to make sure backups work.

## Documentation

- [docs/API.md](docs/API.md) - every endpoint and the chat events
- [docs/DATABASE.md](docs/DATABASE.md) - tables, migrations, retention
- [docs/SCORING.md](docs/SCORING.md) - how points are earned and spent
- [docs/SECURITY.md](docs/SECURITY.md) - protections and the go-live checklist
- [docs/MODERATION.md](docs/MODERATION.md) - automatic filters, reports and admin actions

## Credits

- **Archivo** (Omnibus-Type) and **Atkinson Hyperlegible Next** (Braille Institute of
  America) fonts - SIL Open Font License 1.1; licence texts in `frontend/assets/fonts/`.
- **Socket.IO** client - MIT License (`frontend/js/vendor/socket.io.min.js`).
- **Cloudflare Turnstile** for the privacy-friendly CAPTCHA.
- IP locations: this product can include GeoLite2 data created by MaxMind, available from
  <https://www.maxmind.com>.
- HKDSE dates are taken from the HKEAA examination timetable
  (<https://www.hkeaa.edu.hk/doclibrary/hkdse/exam_timetable/2027_dse_timetable.pdf>). DSEE5 is not connected with the
  Hong Kong Examinations and Assessment Authority; past papers are HKEAA copyright.
