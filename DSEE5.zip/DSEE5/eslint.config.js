import js from '@eslint/js';
import globals from 'globals';

export default [
  { ignores: ['frontend/js/vendor/**', 'node_modules/**', 'backend/**'] },
  js.configs.recommended,
  {
    files: ['frontend/**/*.js'],
    languageOptions: {
      ecmaVersion: 2023,
      sourceType: 'module',
      globals: { ...globals.browser, io: 'readonly', turnstile: 'readonly' },
    },
    rules: {
      'no-eval': 'error',
      'no-implied-eval': 'error',
      'no-new-func': 'error',
      eqeqeq: ['error', 'always', { null: 'ignore' }],
      'no-unused-vars': ['warn', { argsIgnorePattern: '^_' }],
      'no-restricted-properties': [
        'warn',
        { property: 'innerHTML', message: 'Use textContent or el() for user data (XSS risk).' },
        { property: 'outerHTML', message: 'Use DOM methods instead (XSS risk).' },
      ],
    },
  },
  {
    files: ['frontend/service-worker.js'],
    languageOptions: { sourceType: 'script', globals: { ...globals.serviceworker } },
  },
  {
    files: ['backend/app/admin_ui/static/*.js'],
    languageOptions: { sourceType: 'script', globals: { ...globals.browser } },
  },
];
