# DSEE5 API

Every address below starts with `/api` and answers in JSON. The website's own pages are
the only intended client; this document is for the people who maintain it.

## Conventions

**Answer shape.** Success: `{"ok": true, ...data}`. Failure: `{"ok": false, "error": "<code>"}`,
sometimes with `"fields": {"<field>": "<code>"}` for form errors. The browser translates every
code with `errors.<code>` in `frontend/locales/*.json`; `python backend/scripts/check_locales.py`
checks that each code the server can send has a translation.

**Login.** Logging in sets an `HttpOnly`, `Secure`, `SameSite=Lax` cookie (`dsee5_auth`). The
server keeps only a SHA-256 hash of its token, so a stolen database cannot be used to log in.
Endpoints marked *login* answer `401 login_required` without it; *student* / *tutor* need that
role (`403 forbidden` otherwise).

**CSRF.** Every `POST`, `PUT`, `PATCH` and `DELETE` needs the header `X-CSRFToken`, taken from
`GET /api/auth/csrf`. After login or logout the token changes; `frontend/js/core/api.js`
fetches a new one and retries once when it sees `csrf_failed`.

**Lists** that can grow take `?page=` (from 1) and `?per_page=` (max 50) and answer
`{"items": [...], "page", "pages", "total"}`.

**Times** are sent as ISO 8601 with a time zone (`2027-04-21T00:30:00Z`, or
`2027-04-21T08:30:00+08:00` for DSE dates); the browser shows them in Hong Kong time.

**Rate limits.** Every API group allows 120 requests a minute per IP. Stricter limits are
listed with each endpoint. Going over answers `429 too_many_requests`. On a development
computer with `TRUST_LOCALHOST=true`, requests from 127.0.0.1 are never limited.

## Health

| Method | Path | Notes |
|---|---|---|
| GET | `/api/health` | `{"ok": true}` when the app and database answer. Used by Docker. |

## Accounts - `/api/auth`

| Method | Path | Access | Body / query | Answer |
|---|---|---|---|---|
| GET | `/csrf` | anyone | | `csrf_token` |
| GET | `/captcha-key` | anyone | | `enabled`, `site_key` (Cloudflare Turnstile) |
| POST | `/register` | anyone; 10/hour, 50/day per IP | see below | `201`, `user`; logged in |
| POST | `/login` | anyone; 20/min, 200/hour per IP | `username`, `password`, `totp_code?`, `captcha_token?` | `user` |
| POST | `/logout` | anyone | | |
| GET | `/me` | anyone | | `user` (private view), or `null` for a guest |
| POST | `/password` | login; 5/hour | `old_password`, `new_password` | other devices are logged out |
| POST | `/2fa/setup` | login; 10 per 10 min | | `secret`, `otpauth_uri`, `qr_data_uri` (QR code image) |
| POST | `/2fa/enable` | login | `code` | `recovery_codes` (shown once) |
| POST | `/2fa/disable` | login | `password`, `code` | |
| POST | `/2fa/recovery-codes` | login | `code` | new `recovery_codes` |
| GET | `/sessions` | login | | `sessions` (device, IP, last active, `current`) |
| DELETE | `/sessions/<id>` | login | | ends one session |
| POST | `/sessions/revoke-others` | login | | `ended` (count) |

**Register body.** Everyone: `role` (`student`/`tutor`), `username` (3-20 of `A-Z a-z 0-9 _`),
`password` (10-128, letters and numbers, not a common password), `birth_year` (age 10-90),
`gender?`, `guardian_email?`, `language?` (`en`/`zh-HK`, used for notifications), `accept_terms: true`,
`captcha_token`.
Students add `dse_goal`, `school`, `exam_year`, `subjects?` (codes). Tutors add
`teaching_subjects` (at least one) and `dse_results` (`[{"subject": "MATH", "grade": "5**"}]`).
Validation errors answer `validation_failed` with `fields`. A network that already created
`SIGNUP_LIMIT_PER_IP` accounts today gets `signup_limited`.

**Login errors** are the same for an unknown user and a wrong password
(`invalid_credentials`). Other codes: `account_locked` (5 wrong passwords, 15 minutes),
`account_blocked`, `totp_required`, `totp_invalid`, `captcha_required` (after repeated
failures; the answer then includes `"captcha_required": true`).

## Profiles - `/api`

| Method | Path | Access | Notes |
|---|---|---|---|
| GET | `/subjects` | anyone | all subjects with English and Chinese names |
| GET | `/users/<username>` | anyone | public profile; age, school and contact follow the owner's privacy settings |
| GET | `/profile` | login | own full profile |
| PUT | `/profile` | login | `display_name`, `gender`, `bio`, `contact`, `subjects`, `student: {dse_goal, school, exam_year}`, `tutor: {hourly_wage, short_description, dse_results}` |
| PUT | `/profile/language` | login | `language`: `en` or `zh-HK` |
| PUT | `/profile/privacy` | login | `show_age`, `show_school`, `show_contact`: `everyone` / `members` / `nobody`; under-18s cannot choose `everyone` for age or contact |
| POST | `/profile/avatar` | login; 10/hour | multipart `file`; re-encoded to WebP, location data removed |
| DELETE | `/profile/avatar` | login | |
| POST | `/profile/certificate` | tutor; 10/hour | multipart `file` (image or PDF); only the admin can open it |
| GET | `/profile/export` | login | downloads everything stored about the user (JSON) |
| POST | `/profile/delete` | login | `password`; personal data removed, messages kept as "deleted user" |
| GET | `/files/avatar/<name>` | anyone | profile pictures |

## Tutors and bookings

| Method | Path | Access | Notes |
|---|---|---|---|
| GET | `/tutors` | anyone | `subject`, `min_wage`, `max_wage`, `gender`, `verified_only`, `q`, `sort` (`rating`, `wage_low`, `wage_high`, `newest`), `page`; 12 per page |
| GET | `/tutors/<id>` | anyone | `tutor`, the latest 20 `ratings`, and for a logged-in student `my_bookings` with this tutor |
| POST | `/tutors/<id>/ratings` | student | `booking_id`, `stars` 1-5, `comment?`; only after a completed booking, once per booking |
| GET | `/bookings` | login | `sent`, `received` |
| POST | `/bookings` | student; 10/day | `tutor_id`, `subject`, `message`, `preferred_times?` |
| PATCH | `/bookings/<id>` | login | `action`: `accept`/`decline` (tutor, pending), `cancel` (either side, pending or accepted), `complete` (student, accepted) |

Contact details of the other side appear in a booking only after the tutor accepts.

## Past papers, materials, bookmarks

| Method | Path | Access | Notes |
|---|---|---|---|
| GET | `/papers` | anyone | `subject`, `year`, `language` (`en`/`zh`) |
| GET | `/papers/<id>/download` | login; 60/hour | `file=paper` or `file=marking`; counted and logged |
| GET | `/materials` | login | `subject`, `topic`, `kind` (`pdf`, `image`, `video_link`, `note`), `q`, `page` |
| GET | `/materials/<id>` | login | full material, including note text |
| GET | `/materials/<id>/file` | login | shown inline (may be framed by DSEE5's own viewer); `?download=1` only if the admin allowed downloads |
| GET | `/bookmarks` | login | `items` with titles |
| POST | `/bookmarks` | login | `item_type` (`paper`/`material`), `item_id` |
| DELETE | `/bookmarks/<id>` | login | |

## Discussion rooms

| Method | Path | Access | Notes |
|---|---|---|---|
| GET | `/chat/rooms` | login | subjects with online count, last message time and `captcha_needed` |
| GET | `/chat/<code>/messages` | login | latest 50, older with `?before=<message id>`; `has_more` |
| GET | `/chat/<code>/pinned` | login | pinned messages |
| GET | `/chat/<code>/search` | login; 30/min | `q` (2+ characters) |
| POST | `/chat/images` | login; 20/hour | multipart `file`; answer `image_id` to attach to the next message |
| GET | `/chat/images/<name>` | login | |

Messages are sent over **Socket.IO** (namespace `/chat`, same cookie login):

| Event (browser to server) | Data | Reply |
|---|---|---|
| `join` | `{subject}` | `{ok, online}` |
| `leave` | | `{ok}` |
| `send_message` | `{subject, text, image_id?, captcha_token?}` | `{ok, score, message}` or `{ok: false, error}` |

| Event (server to browser) | Data |
|---|---|
| `message_new` | a message |
| `message_deleted` | `{id}` |
| `message_hidden` / `message_restored` | `{id}` / a message |
| `message_pinned` | `{id, pinned}` |
| `online_count` | `{subject, count}` |

`send_message` errors: `not_enough_points`, `empty_message`, `message_too_long`,
`blocked_words`, `no_contact_info_minor`, `muted`, `slow_down`, `captcha_required`,
`join_room_first`. The first message of each Hong Kong day needs a CAPTCHA token.

## Quizzes, tests and mock exams

| Method | Path | Access | Notes |
|---|---|---|---|
| GET | `/quizzes` | login | `subject`, `level`, `kind`; each item has `best_percent` and `attempts`, plus `current_attempt` |
| POST | `/quizzes/<id>/start` | login | `201`, `attempt` with questions (no answers) and `expires_at`; one attempt at a time |
| GET | `/attempts/current` | login | the running attempt, if any |
| GET | `/attempts/history` | login | finished attempts |
| GET | `/attempts/<id>` | owner | running attempt with saved answers |
| PATCH | `/attempts/<id>/answers` | owner | `answers: {"<attempt question id>": "B"}`; autosave; `server_now` keeps the timer honest |
| POST | `/attempts/<id>/submit` | owner | `answers?`; marks it, gives points (see SCORING.md) |
| GET | `/attempts/<id>/result` | owner | score, topic breakdown, correct answers and explanations |
| GET | `/files/question/<name>` | login | question diagrams |

The timer runs on the server. Answers saved after `expires_at` are refused (`time_up`), and
attempts left open are closed automatically every minute.

## Points

| Method | Path | Access | Notes |
|---|---|---|---|
| GET | `/score` | login | `score`, `login_streak`, `claimed_today`, `daily_amount`, `next_daily_amount`, today's quiz points and caps, message `costs` |
| POST | `/score/daily` | login | claim the daily reward once per Hong Kong day (`already_claimed`) |
| GET | `/score/history` | login | the last transactions |

## DSE countdown

| Method | Path | Access | Notes |
|---|---|---|---|
| GET | `/countdown/events` | anyone | published HKDSE dates, `server_now` |
| GET | `/countdown/following` | login | subject codes the user follows |
| PUT | `/countdown/following` | login | `subjects: ["MATH", "PHY"]`; reminders 100, 30, 7 and 1 day before |

## Reports and notifications

| Method | Path | Access | Notes |
|---|---|---|---|
| POST | `/reports` | login; 20/day | `target_type` (`message`/`user`), `target_id`, `reason`, `details?` |
| GET | `/notifications` | login | the latest 50, newest first, and the `unread` count |
| GET | `/notifications/unread` | login | `unread` count |
| POST | `/notifications/read` | login | `ids?` (none = all) |
| GET | `/notifications/vapid-key` | anyone | `enabled`, `key` for web push |
| POST | `/notifications/subscribe` | login | `subscription` from `PushManager.subscribe()` |
| DELETE | `/notifications/subscribe` | login | `endpoint` |

## The hidden admin area

The admin pages and their JSON API live under the secret `ADMIN_URL_PREFIX` from `.env` and
are deliberately not listed here. Without a valid admin session every admin address answers
the normal 404 page, so the area cannot be discovered. Admins sign in with a separate
account, password and authenticator code; see SECURITY.md.
