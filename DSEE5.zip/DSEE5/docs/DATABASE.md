# DSEE5 database

The tables are defined as SQLAlchemy models in `backend/app/models/`. Development uses a
SQLite file (`backend/instance/dsee5.db`); production uses PostgreSQL. Both are created and
changed only through migrations in `backend/migrations/` (Flask-Migrate / Alembic).

## Changing the database

1. Edit or add a model in `backend/app/models/` (and import new models in `models/__init__.py`).
2. From `backend/`: `flask --app app db migrate -m "describe the change"`
3. Read the new file in `migrations/versions/`. Autogenerate misses some things (renamed
   columns look like drop + add, which loses data); fix it by hand if needed.
4. `flask --app app db upgrade`, then run the tests.
5. Commit the model and the migration together. The Docker image runs `db upgrade` on start.

Constraint names follow the naming convention in `extensions.py`, so migrations behave the
same on SQLite and PostgreSQL.

## Conventions

- Times are stored in UTC (`utcnow()` in `utils/time_utils.py`). "Today" for daily rewards,
  quiz caps and CAPTCHA checks means the Hong Kong day (`hk_day_start_utc()`).
- Uploaded files are not stored in the database. Tables keep only a random file name; the
  files live in `backend/storage/<folder>/`, outside the public folder.
- Users are never hard-deleted: `is_deleted` keeps foreign keys valid while their personal
  data is wiped (see `auth_service.delete_account`).
- Secrets are stored as hashes: passwords (Argon2id), session tokens and 2FA recovery codes
  (SHA-256 - they are long random values, so a fast hash is safe).

## Tables

### People and sign-in

| Table | Purpose | Key columns |
|---|---|---|
| `users` | Every student and tutor | `username` / `username_lower` (unique), `password_hash`, `role`, `birth_year`, privacy (`show_age`, `show_school`, `show_contact`), points (`score`, `lifetime_points`, `login_streak`, `last_daily_claim`), 2FA (`totp_secret`, `totp_last_timecode`, `recovery_codes`), moderation (`is_blocked`, `is_shadow_banned`, `muted_until`), lock-out (`failed_logins`, `locked_until`), `is_deleted` |
| `student_profiles` | One per student | `dse_goal`, `school`, `exam_year` |
| `tutor_profiles` | One per tutor | `hourly_wage`, `short_description`, `dse_results` (JSON list), `certificate_file` (private), `is_verified`, `rating_avg`, `rating_count`, `students_helped` |
| `user_subjects` | Electives (students) or taught subjects (tutors) | `user_id`, `subject_code` |
| `user_sessions` | Logged-in devices | `token_hash` (unique), `ip`, `user_agent`, `last_seen_at`, `expires_at`, `revoked` |
| `admin_accounts` | Admins - separate from users, created only by `scripts/create_admin.py` | `username`, `password_hash`, `totp_secret`, `totp_last_timecode`, `failed_attempts`, `locked_until` |
| `admin_sessions` | Admin logins (2 hours, 30 minutes idle) | as `user_sessions` |

### Content

| Table | Purpose | Key columns |
|---|---|---|
| `subjects` | The HKDSE subjects (seeded from `app/data/subjects.json`) | `code` (primary key, e.g. `MATH`), `name_en`, `name_zh`, `category`, `sort_order` |
| `past_papers` | Paper and marking-scheme files | `subject_code`, `year`, `paper`, `language` - unique together; `file_name`, `marking_file`, `download_count` |
| `materials` | Notes, PDFs, images, video links | `subject_code`, `topic`, `kind`, `body` (notes), `file_name` or `url`, `allow_download`, `is_published` |
| `bookmarks` | Saved papers and materials | `user_id`, `item_type`, `item_id` - unique together |
| `dse_events` | HKDSE dates for the countdown | `title_en`, `title_zh`, `subject_code` (empty = everyone), `kind`, `starts_at`, `is_published` |
| `countdown_follows` | Which subjects' dates a user follows | `user_id`, `subject_code` |

### Discussion rooms

| Table | Purpose | Key columns |
|---|---|---|
| `messages` | Chat messages | `subject_code`, `user_id`, `text`, `is_hidden` (3 reports), `report_count`, `is_deleted` + `deleted_by`, `delete_reason` |
| `chat_images` | Images attached to messages | `owner_id`, `file_name`, `width`, `height`, `message_id` (set when sent) |
| `pinned_messages` | Messages pinned by an admin | `subject_code`, `message_id` |
| `reports` | Reports on messages or users | `reporter_id`, `target_type`, `target_id` (one report per reporter and target), `reason`, `status` (`open`, `actioned`, `dismissed`), `action_taken`, `handled_by` |

### Practice and points

| Table | Purpose | Key columns |
|---|---|---|
| `question_banks` | Groups of questions per subject and level | `subject_code`, `level`, `name` |
| `questions` | One question | `qtype` (`mcq` or `short`), `prompt`, `image_file`, `options` (JSON), `answer`, `explanation`, `marks`, `topic`, `is_active` |
| `assessments` | A published quiz, test or mock exam drawing from one bank | `kind`, `level`, `question_count`, `time_limit_min`, `points_base`, `points_bonus_max`, `is_published` |
| `attempts` | One person taking one assessment | `started_at`, `expires_at` (server timer), `submitted_at`, `status` (`in_progress`, `submitted`, `expired`), `raw_score`, `max_score`, `points_awarded`, `points_reason` |
| `attempt_questions` | The questions drawn for an attempt | `position`, `option_order` (shuffled per attempt), `answer`, `is_correct`, `marks_awarded` |
| `score_transactions` | Every change to a balance | `amount` (+/-), `reason` (`signup_bonus`, `daily_reward`, `quiz`, `test`, `exam`, `chat_message`, `penalty`, `admin_adjust`), `ref_id`, `note` |
| `daily_claims` | One row per user per Hong Kong day | `user_id`, `claim_date` - unique together, so a double click cannot claim twice |

### Tutoring

| Table | Purpose | Key columns |
|---|---|---|
| `booking_requests` | A student asking a tutor for lessons | `student_id`, `tutor_id`, `subject_code`, `message`, `preferred_times`, `status` (`pending`, `accepted`, `declined`, `cancelled`, `completed`) |
| `tutor_ratings` | Stars after completed lessons | `booking_id` (unique), `stars`, `comment` |

### Notifications and security

| Table | Purpose | Key columns |
|---|---|---|
| `notifications` | In-app notifications | `kind`, `title`, `body`, `link`, `is_read` |
| `push_subscriptions` | Browsers that accepted push notifications | `endpoint` (unique), `p256dh`, `auth` |
| `activity_logs` | Security and audit log (logins, sign-ups, downloads, admin actions) | `action`, `user_id` / `admin_id`, `ip`, `device_id`, `country`, `city`, `success`, `meta` (JSON) |
| `blocked_ips` | Blocked addresses (automatic or by the admin) | `ip` (unique), `reason`, `created_by`, `expires_at` (empty = permanent) |

## Keeping data tidy

The background jobs in `backend/app/tasks/` run every day (Hong Kong time):

| Time | Job |
|---|---|
| every minute | close quiz attempts whose time ran out |
| 03:30 | back up the database (and uploaded files on Sundays); keep 14 days |
| 04:00 | delete sessions 30 days after they expire, expired IP blocks, read notifications older than 90 days, activity logs older than 180 days and chat images never attached to a message |
| 08:00 | send DSE countdown reminders (100, 30, 7 and 1 day before) |

Copy the files in `backend/backups/` to another machine or cloud storage regularly, and
test a restore: `pg_restore --clean -d dsee5 dsee5-YYYYMMDD-HHMM.dump`, or for SQLite stop
the app and copy the `.db` file back to `backend/instance/dsee5.db`.
