# DSEE5 security

DSEE5 holds data about teenagers, so it is built to be safe by default. This page lists
what protects what, where the code is, and what you must do when you deploy.

## Checklist before going live

- [ ] `.env` has a random `SECRET_KEY` (64 hex characters) and a random `ADMIN_URL_PREFIX`.
      The app refuses to start in production with the example values.
- [ ] `.env` is not in Git (it is in `.gitignore`) and is readable only by the server user.
- [ ] HTTPS works and `http://` redirects to `https://` (nginx + Let's Encrypt).
- [ ] `ALLOWED_ORIGINS` is exactly your site, e.g. `https://dsee5.example.com`.
- [ ] Real Cloudflare Turnstile keys replace the test keys.
- [ ] `REDIS_URL` is set, so rate limits survive restarts.
- [ ] The admin account was made with `scripts/create_admin.py`, and its authenticator
      secret and recovery plan are stored somewhere safe (not on the server).
- [ ] Optional: `ADMIN_IP_ALLOWLIST` lists the admin's own IP addresses.
- [ ] Backups in `backend/backups/` are copied off the server, and a restore was tested.
- [ ] The server's firewall allows only ports 22 (SSH, with keys only), 80 and 443.

## Accounts and passwords

| Protection | Details | Code |
|---|---|---|
| Password hashing | Argon2id (argon2-cffi defaults); hashes are upgraded automatically when settings change | `security/passwords.py` |
| Password rules | 10-128 characters, letters and numbers, not one of 10,000 common passwords, not the username; the sign-up form shows a strength meter | `passwords.password_problems` |
| Same answer for unknown user and wrong password | prevents finding out which usernames exist; a dummy hash keeps the timing equal | `auth_service.authenticate` |
| Account lock | 5 wrong passwords lock the account for 15 minutes | `auth_service` |
| CAPTCHA on login | required after 3 failures from an IP or on an account | `auth_service._captcha_needed` |
| Two-step login (optional for users) | TOTP codes (RFC 6238) with replay protection: each code works once; 8 one-time recovery codes, stored hashed | `security/totp.py` |
| Password change | logs out every other device | `auth_service.change_password` |

## Sessions and cookies

- Login creates a random 256-bit token. The browser gets it in an `HttpOnly`, `Secure`,
  `SameSite=Lax` cookie; the database stores only its SHA-256 hash.
- User sessions last 7 days and end after 24 hours without use. Users can see every
  logged-in device and end any of them (Settings, Security).
- Admin sessions are separate (own cookie, own table), last 2 hours and end after
  30 minutes without use.
- Every state-changing request needs a CSRF token (Flask-WTF), sent in the `X-CSRFToken`
  header. Together with `SameSite` cookies this stops cross-site request forgery.

## Robots and attackers

| Rule | Action | Code |
|---|---|---|
| Sign-up | Cloudflare Turnstile CAPTCHA; at most `SIGNUP_LIMIT_PER_IP` new accounts per IP or device per day | `services/captcha_service.py`, `abuse_detector.signup_allowed` |
| 10 failed logins from one IP in 10 minutes | IP blocked for 1 hour | `abuse_detector.after_login_failure` |
| 5 requests for attack paths (`/.env`, `/wp-admin`, `/phpmyadmin`, ...) in an hour | IP blocked for 24 hours | `ip_tracker.PROBE_PATTERN` |
| Chat flooding | more than 10 messages a minute: "slow down"; 20 a minute or the same text 5 times: muted 10 minutes | `abuse_detector.check_chat_flood` |
| First chat message of each day | needs a CAPTCHA, which stops scripted posting | `chat_service.needs_captcha` |
| Rate limits | per IP for anonymous requests, per user once logged in (students at one school share an IP); see `security/rate_limits.py` and API.md | Flask-Limiter + Redis |
| nginx limits | a second wall in front of the app for login, sign-up and the API | `deploy/nginx.conf` |

Every automatic block expires on its own, and the admin can see and lift blocks on the
Security page.

## IP tracking

Every important action (login, sign-up, download, report, admin action, block) is written
to `activity_logs` with the IP address, browser, a random device id (`dsee5_did` cookie)
and, if the free GeoLite2 database is installed, country and city. The admin's Security
page shows failed logins, blocked IPs and, for each user, other accounts that used the same
IP or device - useful for spotting someone who keeps making new accounts after a block.
Logs are deleted after 180 days.

Behind nginx, the real visitor IP comes from `X-Forwarded-For`, which nginx overwrites, so it
cannot be faked by the visitor. If you put Cloudflare in front, follow the note at the top of
`deploy/nginx.conf`.

## Man-in-the-middle protection

- nginx serves only TLS 1.2 and 1.3 with modern ciphers; port 80 only redirects.
- HSTS (`max-age` one year, `includeSubDomains`, `preload`) tells browsers never to use plain
  HTTP again. After checking everything works, submit the domain at hstspreload.org.
- Every cookie is `Secure`, so it is never sent without encryption.
- In production the app itself also redirects any plain HTTP request (flask-talisman).

## Cross-site scripting and injection

- **Content-Security-Policy** (`security/headers.py`): scripts, styles, fonts and
  connections only from DSEE5 itself (plus Cloudflare's CAPTCHA). No inline scripts, no
  `onclick=` and no `style=` attributes anywhere, so injected HTML cannot run code.
- The front end never puts user text into `innerHTML`: `el()` in `js/core/ui.js` builds every
  element with `textContent` and refuses `on...` attributes and `style`.
- `frame-ancestors 'none'` and `X-Frame-Options: DENY` stop click-jacking; only learning
  material files may be framed, and only by DSEE5's own viewer.
- All database access goes through SQLAlchemy with bound parameters, never string-built SQL.
- Every input is checked on the server (`security/validators.py`): length, allowed values,
  Unicode normalisation and removal of control characters. The browser's checks are only
  for convenience.

## Uploaded files

| Step | Details |
|---|---|
| Size | images 5 MB, PDFs 30 MB, CSV 2 MB; nginx and Flask refuse anything over 32 MB |
| Real type | detected from the file's bytes, not its name or the browser's claim |
| Images | opened and re-encoded to WebP with Pillow: anything hidden in the file is dropped, and EXIF data, including GPS location, is removed |
| PDFs | refused if they contain JavaScript, launch actions, embedded files or Flash - also when hidden in compressed streams or written with `#xx` escapes |
| Viruses | optional ClamAV scan (`CLAMAV_ENABLED=true`) |
| Storage | random file names in `backend/storage/`, outside the public folder; served only through checked routes with `X-Content-Type-Options: nosniff` |
| Certificates | tutors' DSE certificates can only be opened by the admin |

## The hidden admin

- The admin area exists only under the random `ADMIN_URL_PREFIX`. It is never linked from
  the site, never listed in `robots.txt`, and every admin address answers the normal 404
  page unless an admin is logged in, so it cannot be discovered by scanning.
- Admins are not users: a separate table, created only from the server's command line
  (`scripts/create_admin.py`). There is no sign-up and no password reset by email.
- Sign-in always needs the password (at least 16 characters) **and** a code from an
  authenticator app. 3 failures lock the admin account for 30 minutes.
- Optional `ADMIN_IP_ALLOWLIST`: admin addresses then return 404 for every other IP.
- Every admin action (deleting a post, blocking a user, uploading a paper...) is written to
  the activity log with the admin's name, IP and reason.

## Young users and privacy

Most users are under 18, and Hong Kong's Personal Data (Privacy) Ordinance applies.

- Age, school and contact details are hidden by default. Under-18s cannot show their age or
  contact to everyone, only to logged-in members at most.
- Under-18s cannot post phone numbers, emails or messaging handles in public rooms.
- Contact details are shared between a student and a tutor only after the tutor accepts a
  booking; the booking page shows safety advice.
- Users can download all their data and close their account themselves (Settings, Your data).
- Data that is no longer needed is deleted on a schedule (see DATABASE.md).

## Reporting a security problem

If you find a weakness, do not post it in a discussion room. Email the site owner (the
contact in the footer) with the details, and give them time to fix it before telling others.
