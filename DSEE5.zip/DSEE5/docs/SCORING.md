# DSEE5 points

Points reward studying and make posting in the discussion rooms cost something, which keeps
the rooms useful and makes spam expensive. All numbers live in `backend/app/constants.py`
("Scoring economy"); the logic is in `backend/app/services/score_service.py`.

## Earning

| How | Points | Rule |
|---|---|---|
| Creating an account | 20 | once, so a new user can post straight away |
| Daily reward | 10 to 20 | claimed by pressing the button once per Hong Kong day (resets at 00:00 HKT) |
| Finishing a quiz | 5 + up to 10 | base + bonus x share of marks |
| Finishing a test | 15 + up to 15 | |
| Finishing a mock exam | 30 + up to 30 | |
| Admin adjustment | any | with a note; recorded in the activity log |

**Daily streak.** Day 1 gives 10 points, and each extra day in a row adds 2, up to 20 points
(day 6 onwards). Missing a day starts the streak again at day 1.

| Streak day | 1 | 2 | 3 | 4 | 5 | 6+ |
|---|---|---|---|---|---|---|
| Points | 10 | 12 | 14 | 16 | 18 | 20 |

**Assessment points** = `points_base + round(points_bonus_max x marks / max marks)`. The
admin can change the base and bonus for each assessment; the table above shows the defaults.
A quiz with 7 of 10 marks gives 5 + round(10 x 0.7) = 12 points.

## Limits that stop farming

Checked in this order when an attempt is submitted; the first that applies decides, and the
reason is shown on the result page (`quiz.no_points.*` in the locale files).

1. **Rushing** (`too_fast`): finished in under 20% of the time limit *and* under 50% of the
   marks gives 0 points. Fast and correct is still rewarded.
2. **Repeats** (`already_rewarded_today`): only the first rewarded attempt of the same
   assessment each day gives points.
3. **Attempts per day** (`daily_attempt_limit`): at most 5 rewarded attempts per day.
4. **Daily cap** (`daily_cap`, `daily_cap_partial`): at most 120 assessment points per day;
   the attempt that crosses the cap gets only what is left.

The timer runs on the server, so changing the computer's clock does not add time. An
attempt that runs out of time is submitted automatically with the saved answers and marked
the same way.

## Spending

| Action | Cost |
|---|---|
| Text message in a discussion room | 2 |
| Message with an image | 5 |

Spending is atomic (`UPDATE users SET score = score - cost WHERE score >= cost`), so two
messages sent at the same instant can never take a balance below zero. With too few points
the message is refused with `not_enough_points`, and the chat page links to the dashboard to
claim the daily reward or take a quiz.

## Penalties

| Event | Change |
|---|---|
| Admin removes a message for breaking the rules | -10 (never below 0) |
| Admin adjustment | any amount, with a note |

## Records

Every change is a row in `score_transactions` (amount, reason, linked attempt or message),
so a balance can always be explained. `users.score` is the current balance and
`users.lifetime_points` counts everything ever earned. `daily_claims` has one row per user per
day with a unique constraint, so a double click or two open tabs cannot claim twice.

## Changing the numbers

Edit the constants and restart the app. The front end reads costs and caps from
`GET /api/score`, but some explanatory text in `frontend/locales/*.json` (for example the
home page and `score.claim_hint`) mentions the numbers too - update it at the same time.
