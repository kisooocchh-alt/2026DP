# DSEE5 moderation

How the discussion rooms and profiles are kept safe, what happens automatically, and what
the admin does. Code: `backend/app/services/moderation_service.py`,
`backend/app/services/chat_service.py`, `backend/app/security/abuse_detector.py`, and the
admin pages *Reports*, *Chat* and *Users*.

## Community rules (section 3 of the Terms of Service)

1. Be respectful. No insults, harassment, hate speech, threats or bullying.
2. No sexual, violent or illegal content, in words or images.
3. No spam, advertising, scams or links to unsafe sites.
4. Do not share other people's personal information. Under-18 users cannot post phone
   numbers, emails or messaging accounts in public rooms.
5. No cheating: do not share leaked exam content or offer to sit exams for others.
6. Stay on topic for the subject room.

If you change the rules, change `frontend/pages/terms.html` (English and Chinese) too.

## What happens automatically

| Check | When | Result |
|---|---|---|
| Banned words | every message, bio, booking message and rating comment | refused with `blocked_words` |
| Contact details from under-18s | every chat message | refused with `no_contact_info_minor` |
| Message cost | every message (2 points, 5 with an image) | spam costs points |
| CAPTCHA | first message of each Hong Kong day | scripted posting is stopped |
| Flood | more than 10 messages a minute | "slow down" |
| Heavy flood | 20 a minute, or the same text 5 times | muted for 10 minutes |
| Reports | 3 different users report one message | the message is hidden until the admin decides |

**Banned words** are in `backend/app/data/banned_words_en.txt` (whole words, or phrases with
a space) and `banned_words_zh.txt` (matched anywhere, because Chinese has no spaces). English
words are also checked after undoing common letter swaps (`0`->o, `1`->i, `3`->e, `@`->a,
`$`->s ...). One entry per line; lines starting with `#` are comments. Restart the app after
editing. Keep the Chinese list to clearly offensive terms: short or common characters cause
false alarms in normal sentences.

**Contact details** means emails, Hong Kong phone numbers (`+852`, `9123 4567`, "tel ...
12345678") and messaging apps (WhatsApp, WeChat, Telegram, Signal, Instagram, Snapchat,
LINE, Discord, "IG:"). The patterns are in `_CONTACT_PATTERNS`.

## Reports

Any logged-in user can report a message or a profile (reasons: spam, harassment,
inappropriate image, personal information, cheating, other). The reported person is never
told who reported them. Each user can report the same thing only once, and at most 20 times
a day.

The admin's *Reports* page lists open reports grouped by target, with the message, its
image and the reporter's details. Actions:

| Action | Effect |
|---|---|
| Delete message | removed for everyone in real time, shown as "removed by a moderator"; the author loses 10 points |
| Warn | the user gets a notification quoting the reason |
| Mute | the user cannot post for the chosen time (default 24 hours) |
| Block | the user is logged out everywhere and cannot log in; the reported message is removed |
| Dismiss | the report is closed; a hidden message becomes visible again |

Every action closes all open reports on the same message or user and is recorded in the
activity log with the admin's reason.

## Other admin tools

- **Chat page:** read any room live (refreshes every 10 seconds), delete, pin or unhide
  messages, and open the author's account.
- **Shadow ban:** for persistent spammers who would just make new accounts after a block.
  Their messages are still accepted and shown to themselves, but nobody else sees them.
- **Points:** add or remove points with a note.
- **Logout everywhere:** ends every session of a user, for example after their account was
  stolen.
- **Related accounts:** on a user's page, other accounts that used the same IP or device.
- **IP blocks:** on the Security page, block an address for a number of hours or
  permanently, and lift automatic blocks.

## Guidance for moderators

- Prefer the lightest action that solves the problem: warn, then mute, then block.
- Write a clear reason: the user sees it in warnings and mutes, and other admins see it in
  the activity log.
- Treat reports about leaked exam papers during the HKDSE examination period as urgent.
- If a message suggests a young person is in danger or being groomed, do not just delete
  it: keep the evidence (the activity log and a screenshot), block the other account, and
  contact the school or the police. In an emergency call 999.
