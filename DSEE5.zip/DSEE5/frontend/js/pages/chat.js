// js/pages/chat.js - the subject-divided discussion rooms (real time over Socket.IO).
import { api } from '../core/api.js';
import { updateCachedScore } from '../core/auth.js';
import { CONFIG } from '../core/config.js';
import { initPage } from '../core/page.js';
import { currentLanguage, t } from '../core/i18n.js';
import { connectChat, emitWithAck } from '../core/socket.js';
import { storage } from '../core/storage.js';
import {
  avatarImg, el, errorMessage, fill, icon, openModal, setLoading, toast, userBadges,
} from '../core/ui.js';
import {
  formatDate,
  formatTime,
  getQueryParam,
  joinParts,
  setQueryParams,
  subjectName,
} from '../core/utils.js';
import { renderCaptcha } from '../components/captcha.js';
import { createImageUploader } from '../components/image-uploader.js';
import { reportButton } from '../components/report-button.js';
import { mountScoreBadge } from '../components/score-badge.js';

const me = await initPage({ requireLogin: true });

const els = {
  roomPanel: document.getElementById('room-panel'),
  roomList: document.getElementById('room-list'),
  roomFilter: document.getElementById('room-filter'),
  roomsToggle: document.getElementById('rooms-toggle'),
  title: document.getElementById('room-title'),
  meta: document.getElementById('room-meta'),
  messages: document.getElementById('messages'),
  banner: document.getElementById('connection-banner'),
  composer: document.getElementById('composer'),
  input: document.getElementById('msg-input'),
  send: document.getElementById('send-btn'),
  cost: document.getElementById('cost-hint'),
  chars: document.getElementById('char-count'),
  pointsWarning: document.getElementById('points-warning'),
  captchaBox: document.getElementById('chat-captcha'),
  side: document.getElementById('side-results'),
  sideTitle: document.getElementById('side-title'),
  sideList: document.getElementById('side-list'),
};

els.roomsToggle.append(icon('menu'));
els.send.append(icon('send'), el('span', { class: 'send-label' }, t('chat.send')));
document.getElementById('attach-label').append(icon('image'));
document.getElementById('side-close').append(icon('close'));
mountScoreBadge(document.getElementById('chat-score'), me.score);

let rooms = [];
let room = null;
let oldestId = null;
let hasMore = false;
let loadingOlder = false;
let captcha = null;
let score = me.score;
const shown = new Map(); // message id -> element
const messageData = new Map(); // message id -> message object

// ---------------------------------------------------------------- rooms
const roomName = (r) => (currentLanguage() === 'zh-HK' ? r.name_zh : r.name_en);

function renderRooms() {
  const q = els.roomFilter.value.trim().toLowerCase();
  fill(els.roomList, ...rooms
    .filter((r) => !q || r.code.toLowerCase().includes(q) || r.name_en.toLowerCase().includes(q) || r.name_zh.includes(q))
    .map((r) => el('li', {},
      el('a', {
        class: 'room-link', href: `/chat?room=${r.code}`, 'aria-current': r.code === room ? 'page' : null,
        onclick: (e) => {
          e.preventDefault();
          openRoom(r.code);
        },
      },
      el('img', { src: `/assets/images/subjects/${r.code}.svg`, alt: '', width: 28, height: 28 }),
      el('span', { class: 'room-name' }, roomName(r)),
      r.online ? el('span', { class: 'room-online', title: t('chat.online', { n: r.online }) }, String(r.online)) : null))));
}

function updateMeta(count) {
  const r = rooms.find((x) => x.code === room);
  if (r && typeof count === 'number') r.online = count;
  els.meta.textContent = t('chat.online', { n: r?.online || 0 });
}

// ---------------------------------------------------------------- messages
function textWithMentions(text) {
  const parts = text.split(/(@[A-Za-z0-9_]{3,20})/g);
  return parts.map((part) => (/^@[A-Za-z0-9_]{3,20}$/.test(part)
    ? el('a', { class: 'mention', href: `/profile?u=${encodeURIComponent(part.slice(1))}` }, part)
    : part));
}

function messageNode(m) {
  const mine = m.user.id === me.id;
  const node = el('article', {
    class: `msg ${mine ? 'is-mine' : ''} ${m.deleted || m.hidden ? 'is-removed' : ''}`,
    id: `m${m.id}`, dataset: { id: m.id, day: formatDate(m.created_at, { weekday: 'long' }) },
  });
  const who = m.user.username
    ? el('a', { class: 'msg-author', href: `/profile?u=${encodeURIComponent(m.user.username)}` }, m.user.display_name)
    : el('span', { class: 'msg-author' }, t('common.deleted_user'));
  const body = [];
  if (m.deleted) body.push(el('p', { class: 'msg-placeholder' }, t('chat.deleted')));
  else if (m.hidden) body.push(el('p', { class: 'msg-placeholder' }, t('chat.hidden')));
  else {
    if (m.text) body.push(el('p', { class: 'msg-text' }, textWithMentions(m.text)));
    if (m.image_url) {
      body.push(el('button', {
        class: 'msg-image', type: 'button', 'aria-label': t('chat.open_image'),
        onclick: () => openModal(el('img', { src: m.image_url, alt: t('chat.image_alt') }), { image: true }),
      }, el('img', { src: m.image_url, alt: t('chat.image_alt'), loading: 'lazy' })));
    }
  }
  node.append(
    el('a', { class: 'msg-avatar', href: m.user.username ? `/profile?u=${encodeURIComponent(m.user.username)}` : '#',
      tabindex: '-1', 'aria-hidden': 'true' }, avatarImg(m.user, 'sm')),
    el('div', { class: 'msg-bubble' },
      el('header', { class: 'msg-head' }, who, userBadges(m.user),
        el('time', { datetime: m.created_at, class: 'msg-time' }, formatTime(m.created_at))),
      body,
      !mine && !m.deleted && !m.hidden ? el('div', { class: 'msg-actions' }, reportButton('message', m.id, { compact: true })) : null));
  return node;
}

function daySeparator(label) {
  return el('div', { class: 'day-sep', role: 'separator' }, el('span', {}, label));
}

function nearBottom() {
  const box = els.messages;
  return box.scrollHeight - box.scrollTop - box.clientHeight < 120;
}

function scrollToBottom() {
  els.messages.scrollTop = els.messages.scrollHeight;
}

function buildList(list) {
  const nodes = [];
  let lastDay = null;
  for (const m of list) {
    const node = messageNode(m);
    shown.set(m.id, node);
    messageData.set(m.id, m);
    if (node.dataset.day !== lastDay) {
      nodes.push(daySeparator(node.dataset.day));
      lastDay = node.dataset.day;
    }
    nodes.push(node);
  }
  return nodes;
}

function appendMessage(m) {
  if (shown.has(m.id)) return;
  const stick = nearBottom() || m.user.id === me.id;
  const empty = els.messages.querySelector('.chat-empty');
  if (empty) empty.remove();
  const node = messageNode(m);
  const last = [...els.messages.querySelectorAll('.msg')].pop();
  if (!last || last.dataset.day !== node.dataset.day) els.messages.append(daySeparator(node.dataset.day));
  els.messages.append(node);
  shown.set(m.id, node);
  messageData.set(m.id, m);
  if (stick) scrollToBottom();
}

function replaceMessage(id, changes) {
  const old = shown.get(id);
  const data = messageData.get(id);
  if (!old || !data) return;
  const updated = { ...data, ...changes };
  messageData.set(id, updated);
  const fresh = messageNode(updated);
  old.replaceWith(fresh);
  shown.set(id, fresh);
}

async function loadHistory() {
  shown.clear();
  messageData.clear();
  fill(els.messages, el('div', { class: 'chat-loading' }, el('div', { class: 'spinner' })));
  const data = await api(`/chat/${room}/messages`);
  hasMore = data.has_more;
  oldestId = data.messages[0]?.id || null;
  if (!data.messages.length) {
    fill(els.messages, el('div', { class: 'chat-empty' },
      el('h3', {}, t('chat.empty_title', { room: subjectName(room) })),
      el('p', {}, t('chat.empty_text'))));
    return;
  }
  fill(els.messages, ...buildList(data.messages));
  const target = location.hash.match(/^#m(\d+)$/);
  const node = target && shown.get(Number(target[1]));
  if (node) {
    node.scrollIntoView({ block: 'center' });
    node.classList.add('is-highlighted');
  } else {
    scrollToBottom();
  }
}

async function loadOlder() {
  if (!hasMore || loadingOlder || !oldestId) return;
  loadingOlder = true;
  const box = els.messages;
  const before = box.scrollHeight;
  try {
    const data = await api(`/chat/${room}/messages?before=${oldestId}`);
    hasMore = data.has_more;
    if (data.messages.length) {
      oldestId = data.messages[0].id;
      const firstSep = box.querySelector('.day-sep');
      const nodes = buildList(data.messages);
      // avoid a double separator when the older page ends on the same day
      if (firstSep && nodes.length && nodes[0].classList.contains('day-sep')) {
        const lastOlder = nodes[nodes.length - 1];
        if (lastOlder.dataset.day === firstSep.textContent) firstSep.remove();
      }
      box.prepend(...nodes);
      box.scrollTop = box.scrollHeight - before;
    }
  } finally {
    loadingOlder = false;
  }
}

// ---------------------------------------------------------------- socket
const socket = connectChat();

async function joinCurrent() {
  if (!room || !socket.connected) return;
  const reply = await emitWithAck(socket, 'join', { subject: room }).catch(() => null);
  if (reply?.ok) updateMeta(reply.online);
}

socket.on('connect', () => {
  els.banner.hidden = true;
  joinCurrent();
});
socket.on('disconnect', () => { els.banner.hidden = false; });
socket.on('connect_error', (err) => {
  els.banner.hidden = false;
  if (err?.message === 'login_required') location.href = '/login?next=/chat';
});
socket.on('message_new', (m) => {
  if (m.subject === room) appendMessage(m);
});
socket.on('message_deleted', ({ id }) => replaceMessage(id, { deleted: true, text: null, image_url: null }));
socket.on('message_hidden', ({ id }) => replaceMessage(id, { hidden: true, text: null, image_url: null }));
socket.on('message_restored', (m) => {
  if (m.subject === room) replaceMessage(m.id, { ...m, hidden: false });
});
socket.on('message_pinned', () => {
  if (!els.side.hidden && els.side.dataset.mode === 'pinned') showPinned();
});
socket.on('online_count', ({ subject, count }) => {
  const r = rooms.find((x) => x.code === subject);
  if (r) r.online = count;
  if (subject === room) updateMeta(count);
  renderRooms();
});

// ---------------------------------------------------------------- open a room
async function openRoom(code) {
  if (!rooms.some((r) => r.code === code)) code = 'MATH';
  room = code;
  storage.set('lastRoom', code);
  setQueryParams({ room: code });
  els.title.textContent = subjectName(code);
  document.title = `${subjectName(code)} - ${t('page.chat')}`;
  closeSide();
  renderRooms();
  updateMeta();
  els.roomPanel.classList.remove('is-open');
  els.roomsToggle.setAttribute('aria-expanded', 'false');
  await joinCurrent();
  try {
    await loadHistory();
  } catch (err) {
    toast(errorMessage(err), 'error');
  }
}

// ---------------------------------------------------------------- pinned & search
function closeSide() {
  els.side.hidden = true;
  els.side.dataset.mode = '';
}

function showResults(title, messages, mode) {
  els.side.hidden = false;
  els.side.dataset.mode = mode;
  els.sideTitle.textContent = title;
  fill(els.sideList, ...(messages.length ? messages.map((m) => el('button', {
    class: 'side-item', type: 'button',
    onclick: () => {
      const node = shown.get(m.id);
      if (node) {
        node.scrollIntoView({ block: 'center', behavior: 'smooth' });
        node.classList.add('is-highlighted');
        setTimeout(() => node.classList.remove('is-highlighted'), 2000);
      } else {
        toast(t('chat.older_message'));
      }
    },
  }, el('span', { class: 'text-xs text-muted' }, joinParts(m.user.display_name, formatDate(m.created_at))),
  el('span', { class: 'side-text' }, m.text || t('chat.image_alt')))) : [el('p', { class: 'text-sm text-muted' }, t('chat.no_results'))]));
}

async function showPinned() {
  const { messages } = await api(`/chat/${room}/pinned`);
  showResults(t('chat.pinned'), messages, 'pinned');
}

document.getElementById('pinned-btn').addEventListener('click', () => {
  if (!els.side.hidden && els.side.dataset.mode === 'pinned') closeSide();
  else showPinned().catch((err) => toast(errorMessage(err), 'error'));
});
document.getElementById('side-close').addEventListener('click', closeSide);
document.getElementById('search-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const q = document.getElementById('search-input').value.trim();
  if (q.length < 2) return;
  try {
    const { messages } = await api(`/chat/${room}/search?q=${encodeURIComponent(q)}`);
    showResults(t('chat.results_for', { q }), messages, 'search');
  } catch (err) {
    toast(errorMessage(err), 'error');
  }
});

// ---------------------------------------------------------------- composer
const uploader = createImageUploader({
  input: document.getElementById('image-input'),
  preview: document.getElementById('image-preview'),
  dropZone: els.composer,
  maxSide: 1600,
  onChange: (file) => {
    document.getElementById('image-preview-wrap').hidden = !file;
    updateComposer();
  },
  onError: (code) => toast(t(`errors.${code}`), 'error'),
});
document.getElementById('image-remove').addEventListener('click', () => uploader.clear());

function currentCost() {
  return uploader.file() ? CONFIG.MESSAGE_COST_IMAGE : CONFIG.MESSAGE_COST_TEXT;
}

function updateComposer() {
  const length = els.input.value.length;
  els.chars.textContent = length > CONFIG.MAX_MESSAGE_LENGTH * 0.8 ? `${length} / ${CONFIG.MAX_MESSAGE_LENGTH}` : '';
  els.cost.textContent = t('chat.cost', { cost: currentCost() });
  els.pointsWarning.hidden = score >= currentCost();
  els.input.style.height = 'auto';
  els.input.style.height = `${Math.min(els.input.scrollHeight, 180)}px`;
}

document.addEventListener('dsee5:score', (e) => {
  score = e.detail.score;
  updateComposer();
});
els.input.addEventListener('input', updateComposer);
els.input.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
    e.preventDefault();
    els.composer.requestSubmit();
  }
});

els.composer.addEventListener('submit', async (e) => {
  e.preventDefault();
  const text = els.input.value.trim();
  if (!text && !uploader.file()) return;
  if (!socket.connected) {
    toast(t('chat.reconnecting'), 'error');
    return;
  }
  setLoading(els.send, true);
  try {
    let imageId = null;
    if (uploader.file()) imageId = (await uploader.upload('/chat/images', 'image')).image_id;
    const reply = await emitWithAck(socket, 'send_message', {
      subject: room, text, image_id: imageId, captcha_token: captcha?.getToken() || null,
    });
    if (!reply?.ok) {
      if (reply?.error === 'captcha_required') {
        if (!captcha) captcha = await renderCaptcha(els.captchaBox);
        else captcha.reset();
        els.captchaBox.hidden = false;
        toast(t('errors.captcha_required'), 'error');
      } else if (reply?.error === 'not_enough_points') {
        els.pointsWarning.hidden = false;
        toast(t('errors.not_enough_points'), 'error');
      } else {
        toast(t(`errors.${reply?.error || 'server_error'}`), 'error');
      }
      return;
    }
    els.input.value = '';
    uploader.clear();
    els.captchaBox.hidden = true;
    updateCachedScore(reply.score);
    if (reply.message) appendMessage(reply.message);
  } catch (err) {
    toast(err.message === 'timeout' ? t('errors.network_error') : errorMessage(err), 'error');
  } finally {
    setLoading(els.send, false);
    updateComposer();
    els.input.focus();
  }
});

// ---------------------------------------------------------------- start
els.messages.addEventListener('scroll', () => {
  if (els.messages.scrollTop < 80) loadOlder();
});
els.roomFilter.addEventListener('input', renderRooms);
els.roomsToggle.addEventListener('click', () => {
  const open = els.roomPanel.classList.toggle('is-open');
  els.roomsToggle.setAttribute('aria-expanded', String(open));
});

const data = await api('/chat/rooms');
rooms = data.rooms;
const preferred = getQueryParam('room') || storage.get('lastRoom') || me.subjects[0] || 'MATH';
updateComposer();
await openRoom(preferred.toUpperCase());
