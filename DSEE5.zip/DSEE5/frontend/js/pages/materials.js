// js/pages/materials.js - find learning materials; shows which ones are saved offline.
import { api } from '../core/api.js';
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import { el, emptyState, errorMessage, fill, icon, skeletons } from '../core/ui.js';
import {
  debounce,
  formatDate,
  getSubjects,
  joinParts,
  setQueryParams,
  subjectName,
  subjectOptions,
} from '../core/utils.js';
import { renderPagination } from '../components/pagination.js';

await initPage({ requireLogin: true });
const form = document.getElementById('material-filters');
const grid = document.getElementById('materials-grid');
const pager = document.getElementById('pagination');
const params = new URLSearchParams(location.search);
const KIND_ICON = { pdf: 'file', image: 'image', video_link: 'video', note: 'note' };

fill(form.subject, ...subjectOptions(await getSubjects(), params.get('subject') || '', { includeAll: true }));
form.q.value = params.get('q') || '';
let topic = params.get('topic') || '';
let page = Number(params.get('page')) || 1;

async function offlineIds() {
  if (!('caches' in window)) return new Set();
  try {
    const cache = await caches.open('dsee5-materials');
    const keys = await cache.keys();
    return new Set(keys.map((r) => Number((new URL(r.url).pathname.match(/materials\/(\d+)\/file/) || [])[1])));
  } catch {
    return new Set();
  }
}

function card(m, offline) {
  return el('a', { class: 'material-card', href: `/material?id=${m.id}` },
    el('span', { class: `material-kind kind-${m.kind}` }, icon(KIND_ICON[m.kind] || 'file'), t(`materials.kinds.${m.kind}`)),
    el('h2', { class: 'material-title' }, m.title),
    m.description && el('p', { class: 'text-sm text-muted material-desc' }, m.description),
    el('p', { class: 'row-meta' }, joinParts(subjectName(m.subject), m.topic, t(`papers.lang_${m.language}`))),
    el('div', { class: 'cluster' },
      offline.has(m.id) && el('span', { class: 'badge badge-ok' }, t('materials.offline_badge')),
      m.bookmark_id && el('span', { class: 'badge' }, t('materials.bookmarked')),
      el('span', { class: 'text-xs text-muted' }, t('materials.updated', { date: formatDate(m.updated_at) }))));
}

async function load() {
  const query = { subject: form.subject.value, topic, q: form.q.value.trim(), page: page > 1 ? page : '' };
  setQueryParams(query);
  fill(grid, ...skeletons(6));
  try {
    const [data, offline] = await Promise.all([
      api(`/materials?${new URLSearchParams(Object.entries(query).filter(([, v]) => v))}`), offlineIds()]);
    fill(form.topic, el('option', { value: '' }, t('materials.all_topics')),
      data.topics.map((name) => el('option', { value: name, selected: name === topic }, name)));
    if (!data.items.length) {
      fill(grid, emptyState({ title: t('materials.none'), text: t('materials.none_text') }));
    } else {
      fill(grid, ...data.items.map((m) => card(m, offline)));
    }
    renderPagination(pager, data, (p) => {
      page = p;
      load();
    });
  } catch (err) {
    fill(grid, emptyState({ title: errorMessage(err) }));
  }
}

form.subject.addEventListener('change', () => {
  topic = '';
  page = 1;
  load();
});
form.topic.addEventListener('change', () => {
  topic = form.topic.value;
  page = 1;
  load();
});
form.q.addEventListener('input', debounce(() => {
  page = 1;
  load();
}, 350));
form.addEventListener('submit', (e) => e.preventDefault());
load();
