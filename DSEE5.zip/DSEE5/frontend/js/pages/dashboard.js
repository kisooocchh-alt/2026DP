// js/pages/dashboard.js - today's reward, the countdown for the subjects you follow,
// a quiz in progress, recent results, notifications and bookmarks.
import { api } from '../core/api.js';
import { updateCachedScore } from '../core/auth.js';
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import { el, errorMessage, fill, setLoading, toast } from '../core/ui.js';
import { formatRelative, getQueryParam, joinParts, subjectName } from '../core/utils.js';
import { mountCountdown } from '../components/countdown.js';
import { mountScoreBadge } from '../components/score-badge.js';

const user = await initPage({ requireLogin: true });

const hour = Number(new Intl.DateTimeFormat('en-GB', { hour: 'numeric', hourCycle: 'h23',
  timeZone: 'Asia/Hong_Kong' }).format(new Date()));
const part = hour < 12 ? 'morning' : hour < 18 ? 'afternoon' : 'evening';
document.getElementById('greeting').textContent = t(`dashboard.greeting_${part}`, { name: user.display_name });
document.getElementById('greeting-sub').textContent = user.role === 'tutor'
  ? t('dashboard.sub_tutor')
  : t('dashboard.sub_student', { goal: user.student?.dse_goal || '' });
document.getElementById('welcome-notice').hidden = getQueryParam('welcome') !== '1';

mountScoreBadge(document.getElementById('dash-score'), user.score);

function emptyRow(text) {
  return el('li', { class: 'mini-empty' }, text);
}

// ---------------------------------------------------------------- countdown
const following = await api('/countdown/following').then((d) => d.subjects).catch(() => []);
mountCountdown(document.getElementById('dash-countdown'), { subjects: following, listSize: 3 });

// ---------------------------------------------------------------- daily reward
const dailyBtn = document.getElementById('daily-btn');

function renderScore(summary) {
  const claimed = summary.claimed_today;
  dailyBtn.disabled = claimed;
  dailyBtn.textContent = claimed ? t('score.claimed_today') : t('score.claim_amount', { n: summary.daily_amount });
  document.getElementById('daily-text').textContent = claimed
    ? t('score.come_back', { n: summary.next_daily_amount })
    : t('score.claim_hint');
  document.getElementById('streak-line').textContent = t('score.streak', { n: summary.login_streak });
  document.getElementById('quiz-points-line').textContent = t('score.quiz_today', {
    n: summary.assessment_points_today, cap: summary.assessment_daily_cap,
  });
  updateCachedScore(summary.score);
}

let summary = await api('/score');
renderScore(summary);

dailyBtn.addEventListener('click', async () => {
  setLoading(dailyBtn, true);
  try {
    const result = await api('/score/daily', { method: 'POST' });
    toast(t('score.claimed', { n: result.amount, streak: result.streak }), 'success');
    summary = await api('/score');
    renderScore(summary);
  } catch (err) {
    toast(errorMessage(err), 'error');
  } finally {
    setLoading(dailyBtn, false);
    dailyBtn.disabled = summary.claimed_today;
  }
});

// ---------------------------------------------------------------- quiz in progress
api('/attempts/current').then(({ attempt }) => {
  if (!attempt) return;
  document.getElementById('continue-card').hidden = false;
  document.getElementById('continue-text').textContent = t('dashboard.continue_text', {
    title: attempt.title, subject: subjectName(attempt.subject),
  });
  document.getElementById('continue-link').href = `/quiz-take?attempt=${attempt.id}`;
}).catch(() => {});

// ---------------------------------------------------------------- recent results
api('/attempts/history').then(({ items }) => {
  const list = document.getElementById('recent-results');
  if (!items.length) {
    fill(list, emptyRow(t('dashboard.no_results')));
    return;
  }
  fill(list, ...items.slice(0, 4).map((a) => el('li', {},
    el('a', { href: `/quiz-result?attempt=${a.id}` }, a.title),
    el('span', { class: 'mini-meta' }, joinParts(subjectName(a.subject), formatRelative(a.submitted_at))),
    el('span', { class: 'mini-value num' }, `${a.percent}%`))));
}).catch(() => {});

// ---------------------------------------------------------------- notifications
api('/notifications').then(({ items }) => {
  const list = document.getElementById('dash-notifications');
  if (!items.length) {
    fill(list, emptyRow(t('notifications.none')));
    return;
  }
  fill(list, ...items.slice(0, 5).map((n) => el('li', { class: n.is_read ? '' : 'is-unread' },
    el('a', { href: n.link || '/notifications' }, n.title),
    el('span', { class: 'mini-meta' }, formatRelative(n.created_at)))));
}).catch(() => {});

// ---------------------------------------------------------------- bookmarks
api('/bookmarks').then(({ items }) => {
  const list = document.getElementById('dash-bookmarks');
  if (!items.length) {
    fill(list, emptyRow(t('dashboard.no_bookmarks')));
    return;
  }
  fill(list, ...items.slice(0, 6).map((b) => el('li', {},
    el('a', { href: b.link }, b.title),
    el('span', { class: 'mini-meta' },
      joinParts(t(`bookmarks.${b.item_type}`), subjectName(b.subject))))));
}).catch(() => {});
