// js/pages/home.js - the public home page: countdown, subject rooms, and buttons that
// change when you are logged in.
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import { el, fill } from '../core/ui.js';
import { getSubjects, subjectName } from '../core/utils.js';
import { mountCountdown } from '../components/countdown.js';

const user = await initPage();

if (user) {
  fill(document.getElementById('hero-actions'),
    el('a', { class: 'btn btn-primary btn-lg', href: '/dashboard' }, t('home.cta_dashboard')),
    el('a', { class: 'btn btn-lg', href: '/quizzes' }, t('home.cta_practice')));
}

mountCountdown(document.getElementById('countdown'), { listSize: 5 });

const subjects = await getSubjects();
fill(document.getElementById('subject-grid'), ...subjects.map((s) =>
  el('li', {},
    el('a', { class: 'subject-tile', href: `/chat?room=${s.code}` },
      el('img', { src: `/assets/images/subjects/${s.code}.svg`, alt: '', width: 40, height: 40,
        loading: 'lazy' }),
      el('span', { class: 'subject-tile-name' }, subjectName(s.code)),
      el('span', { class: 'subject-tile-code' }, s.code)))));
