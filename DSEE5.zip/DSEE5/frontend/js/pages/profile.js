// js/pages/profile.js - a user's public profile at /profile?u=username (your own without ?u).
// The server decides which fields are visible (privacy settings); this page only shows them.
import { api } from '../core/api.js';
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import { avatarImg, el, emptyState, fill, gradeStamp, starRating, userBadges } from '../core/ui.js';
import { formatDate, formatHKD, getQueryParam, subjectName } from '../core/utils.js';
import { reportButton } from '../components/report-button.js';

const viewer = await initPage();
const root = document.getElementById('profile-root');
const username = getQueryParam('u') || viewer?.username;

if (!username) {
  location.href = '/login?next=/profile';
}

function fact(label, value) {
  if (value === undefined || value === null || value === '') return null;
  return [el('dt', {}, label), el('dd', {}, value)];
}

function render(p) {
  document.title = `${p.display_name} - DSEE5`;
  const actions = el('div', { class: 'cluster' });
  if (p.is_me) {
    actions.append(el('a', { class: 'btn btn-primary', href: '/profile/edit' }, t('profile.edit')),
      el('a', { class: 'btn', href: '/settings#privacy' }, t('profile.privacy')));
  } else {
    if (p.role === 'tutor' && viewer?.role === 'student') {
      actions.append(el('a', { class: 'btn btn-primary', href: `/tutor?id=${p.id}` }, t('profile.book_tutor')));
    } else if (p.role === 'tutor') {
      actions.append(el('a', { class: 'btn', href: `/tutor?id=${p.id}` }, t('profile.tutor_page')));
    }
    if (viewer) actions.append(reportButton('user', p.id));
  }

  const facts = el('dl', { class: 'facts' },
    fact(t('profile.age'), p.age != null ? String(p.age) : null),
    fact(t('profile.gender'), p.gender ? t(`genders.${p.gender}`) : null),
    fact(t('profile.school'), p.school),
    fact(t('profile.dse_goal'), p.dse_goal),
    fact(t('profile.exam_year'), p.exam_year ? String(p.exam_year) : null),
    fact(t('profile.contact'), p.contact),
    fact(t('profile.joined'), formatDate(p.created_at)));

  const sections = [
    el('section', { class: 'card' },
      el('h2', {}, t('profile.about')),
      p.bio ? el('p', { class: 'pre-wrap' }, p.bio) : el('p', { class: 'text-muted' }, t('profile.no_bio')),
      facts),
    el('section', { class: 'card' },
      el('h2', {}, p.role === 'tutor' ? t('profile.teaches') : t('profile.subjects')),
      p.subjects.length
        ? el('ul', { class: 'chip-list', role: 'list' }, p.subjects.map((c) => el('li', { class: 'chip' }, subjectName(c))))
        : el('p', { class: 'text-muted' }, t('profile.no_subjects'))),
  ];

  if (p.tutor) {
    const tp = p.tutor;
    sections.unshift(el('section', { class: 'card tutor-panel' },
      el('h2', {}, t('profile.tutor_details')),
      el('div', { class: 'tutor-stats' },
        el('div', {}, el('span', { class: 'stat-value' }, tp.hourly_wage ? formatHKD(tp.hourly_wage) : t('tutors.wage_ask')),
          el('span', { class: 'stat-label' }, t('tutors.wage_label'))),
        el('div', {}, el('span', { class: 'stat-value' }, tp.rating_count ? tp.rating_avg.toFixed(1) : '-'),
          el('span', { class: 'stat-label' }, tp.rating_count ? t('tutors.ratings', { n: tp.rating_count }) : t('tutors.no_ratings'))),
        el('div', {}, el('span', { class: 'stat-value' }, String(tp.students_helped)),
          el('span', { class: 'stat-label' }, t('tutors.students_helped')))),
      tp.rating_count ? starRating(tp.rating_avg) : null,
      tp.short_description && el('p', {}, tp.short_description),
      el('h3', { class: 'mt-4' }, t('tutors.dse_results')),
      tp.dse_results.length
        ? el('ul', { class: 'chip-list', role: 'list' }, tp.dse_results.map((r) => el('li', {}, gradeStamp(r, subjectName(r.subject)))))
        : el('p', { class: 'text-muted' }, t('tutors.no_results')),
      el('p', { class: 'text-xs text-muted mt-2' }, tp.is_verified ? t('tutors.verified_hint') : t('tutors.unverified_hint')),
      p.is_me && tp.certificate_status !== 'verified'
        ? el('p', { class: 'notice mt-2' }, t(`profile.certificate_${tp.certificate_status}`))
        : null));
  }

  fill(root,
    el('header', { class: 'profile-head' },
      avatarImg(p, 'xl'),
      el('div', { class: 'profile-title' },
        el('h1', {}, p.display_name),
        el('p', { class: 'text-muted' }, `@${p.username}`),
        el('div', { class: 'cluster' }, userBadges(p),
          el('span', { class: 'score-pill', title: t('score.points', { n: p.score }) }, `★ ${p.score}`))),
      actions),
    el('div', { class: 'profile-grid' }, sections));
}

try {
  const { profile } = await api(`/users/${encodeURIComponent(username)}`, { redirectOn401: false });
  render(profile);
} catch {
  fill(root, emptyState({
    title: t('profile.not_found'), text: t('profile.not_found_text'),
    actionLabel: t('common.go_home'), actionHref: '/',
  }));
}
