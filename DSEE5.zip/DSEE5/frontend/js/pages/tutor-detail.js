// js/pages/tutor-detail.js - one tutor at /tutor?id=123, with ratings and a booking form.
import { api } from '../core/api.js';
import { CONFIG } from '../core/config.js';
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import {
  avatarImg,
  el,
  emptyState,
  errorMessage,
  fill,
  gradeStamp,
  setLoading,
  showFieldErrors,
  showFormError,
  starRating,
  toast,
  userBadges,
} from '../core/ui.js';
import { formatDate, formatHKD, getQueryParam, subjectName } from '../core/utils.js';
import { reportButton } from '../components/report-button.js';

const viewer = await initPage();
const root = document.getElementById('tutor-root');
const tutorId = Number(getQueryParam('id'));

function bookingSection(tutor, myBookings) {
  if (!viewer) {
    return el('section', { class: 'card stack-sm' },
      el('h2', {}, t('booking.title')),
      el('p', {}, t('booking.login_first')),
      el('a', { class: 'btn btn-primary', href: `/login?next=${encodeURIComponent(location.pathname + location.search)}` },
        t('nav.login')));
  }
  if (viewer.role !== 'student' || tutor.is_me) return null;
  const pending = myBookings.find((b) => b.status === 'pending');
  const accepted = myBookings.find((b) => b.status === 'accepted');
  const section = el('section', { class: 'card stack', id: 'booking' }, el('h2', {}, t('booking.title')));
  if (accepted) {
    section.append(el('p', { class: 'form-success' }, t('booking.accepted_contact'),
      ' ', el('strong', {}, accepted.other_contact || t('booking.no_contact'))));
  }
  if (pending) {
    section.append(el('p', { class: 'notice' }, t('booking.pending')),
      el('a', { class: 'btn', href: '/bookings' }, t('booking.view_mine')));
    return section;
  }
  const subjectSelect = el('select', { id: 'b-subject', name: 'subject', required: true },
    tutor.subjects.map((code) => el('option', { value: code }, subjectName(code))));
  const form = el('form', { class: 'stack', novalidate: true },
    el('p', { class: 'form-error', 'data-form-error': '', hidden: true }),
    el('div', { class: 'field' }, el('label', { for: 'b-subject' }, t('common.subject')), subjectSelect),
    el('div', { class: 'field' }, el('label', { for: 'b-message' }, t('booking.message')),
      el('textarea', { id: 'b-message', name: 'message', rows: 4, maxlength: CONFIG.BOOKING_MESSAGE_MAX,
        required: true, placeholder: t('booking.message_placeholder') })),
    el('div', { class: 'field' }, el('label', { for: 'b-times' }, t('booking.times')),
      el('input', { id: 'b-times', name: 'preferred_times', maxlength: 200, placeholder: t('booking.times_placeholder') })),
    el('p', { class: 'notice notice-warn safety-tip' }, viewer.is_minor ? t('booking.safety_minor') : t('booking.safety')),
    el('div', { class: 'form-actions' }, el('button', { class: 'btn btn-primary', type: 'submit' }, t('booking.send'))));
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    showFormError(form, '');
    const button = form.querySelector('button[type="submit"]');
    setLoading(button, true);
    try {
      await api('/bookings', {
        method: 'POST',
        body: { tutor_id: tutor.id, subject: form.subject.value, message: form.message.value.trim(),
          preferred_times: form.preferred_times.value.trim() },
      });
      toast(t('booking.sent'), 'success');
      load();
    } catch (err) {
      if (err.fields) showFieldErrors(form, err.fields);
      showFormError(form, errorMessage(err));
      setLoading(button, false);
    }
  });
  section.append(form);
  return section;
}

function render({ tutor, ratings, my_bookings: myBookings }) {
  document.title = `${tutor.display_name} - DSEE5`;
  const tp = tutor.tutor || {};
  const header = el('header', { class: 'profile-head' },
    avatarImg(tutor, 'xl'),
    el('div', { class: 'profile-title' },
      el('h1', {}, tutor.display_name),
      el('p', { class: 'text-muted' }, [`@${tutor.username}`,
        tutor.age != null ? t('tutors.age', { n: tutor.age }) : null,
        tutor.gender ? t(`genders.${tutor.gender}`) : null].filter(Boolean).join(', ')),
      el('div', { class: 'cluster' }, userBadges({ ...tutor, verified: tp.is_verified }))),
    el('div', { class: 'cluster' },
      tutor.is_me && el('a', { class: 'btn', href: '/profile/edit' }, t('profile.edit')),
      viewer && !tutor.is_me && reportButton('user', tutor.id)));

  const details = el('section', { class: 'card tutor-panel stack-sm' },
    el('div', { class: 'tutor-stats' },
      el('div', {}, el('span', { class: 'stat-value' }, tp.hourly_wage ? formatHKD(tp.hourly_wage) : t('tutors.wage_ask')),
        el('span', { class: 'stat-label' }, t('tutors.wage_label'))),
      el('div', {}, el('span', { class: 'stat-value' }, tp.rating_count ? tp.rating_avg.toFixed(1) : '-'),
        el('span', { class: 'stat-label' }, tp.rating_count ? t('tutors.ratings', { n: tp.rating_count }) : t('tutors.no_ratings'))),
      el('div', {}, el('span', { class: 'stat-value' }, String(tp.students_helped || 0)),
        el('span', { class: 'stat-label' }, t('tutors.students_helped')))),
    tp.short_description && el('p', { class: 'tutor-lead' }, tp.short_description),
    tutor.bio && el('p', { class: 'pre-wrap' }, tutor.bio),
    el('h2', { class: 'mt-4' }, t('tutors.dse_results')),
    (tp.dse_results || []).length
      ? el('ul', { class: 'chip-list', role: 'list' }, tp.dse_results.map((r) => el('li', {}, gradeStamp(r, subjectName(r.subject)))))
      : el('p', { class: 'text-muted' }, t('tutors.no_results')),
    el('p', { class: 'text-xs text-muted' }, tp.is_verified ? t('tutors.verified_hint') : t('tutors.unverified_hint')),
    el('h2', { class: 'mt-4' }, t('profile.teaches')),
    el('ul', { class: 'chip-list', role: 'list' }, tutor.subjects.map((c) => el('li', { class: 'chip' }, subjectName(c)))),
    tutor.contact && el('p', { class: 'mt-4' }, el('strong', {}, `${t('profile.contact')}: `), tutor.contact));

  const ratingList = el('section', { class: 'card stack-sm' },
    el('h2', {}, t('tutors.reviews')),
    ratings.length
      ? el('ul', { class: 'rating-list', role: 'list' }, ratings.map((r) => el('li', {},
        avatarImg(r.student, 'sm'),
        el('div', { class: 'cluster' }, starRating(r.stars), el('span', { class: 'text-xs text-muted' }, formatDate(r.created_at))),
        r.comment && el('p', { class: 'text-sm' }, r.comment),
        el('p', { class: 'text-xs text-muted' }, r.student.display_name || t('common.deleted_user')))))
      : el('p', { class: 'text-muted' }, t('tutors.no_reviews')));

  fill(root, header,
    el('div', { class: 'tutor-layout' },
      el('div', { class: 'stack' }, details, ratingList),
      el('div', { class: 'stack' }, bookingSection(tutor, myBookings))));
}

async function load() {
  if (!tutorId) {
    fill(root, emptyState({ title: t('profile.not_found'), actionLabel: t('tutors.back'), actionHref: '/tutors' }));
    return;
  }
  try {
    render(await api(`/tutors/${tutorId}`, { redirectOn401: false }));
  } catch {
    fill(root, emptyState({ title: t('profile.not_found'), text: t('profile.not_found_text'),
      actionLabel: t('tutors.back'), actionHref: '/tutors' }));
  }
}

load();
