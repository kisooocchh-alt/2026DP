// js/pages/tutors.js - tutor search with filters kept in the address bar.
import { api } from '../core/api.js';
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import {
  avatarImg, el, emptyState, errorMessage, fill, gradeStamp, icon, skeletons, starRating,
} from '../core/ui.js';
import { debounce, formatHKD, getSubjects, setQueryParams, subjectName, subjectOptions } from '../core/utils.js';
import { renderPagination } from '../components/pagination.js';

await initPage();

const form = document.getElementById('tutor-filters');
const list = document.getElementById('tutor-list');
const count = document.getElementById('result-count');
const pager = document.getElementById('pagination');
const params = new URLSearchParams(location.search);

fill(form.subject, ...subjectOptions(await getSubjects(), params.get('subject') || '', { includeAll: true }));
for (const name of ['q', 'min_wage', 'max_wage', 'gender', 'sort']) {
  if (params.get(name)) form[name].value = params.get(name);
}
form.verified_only.checked = params.get('verified_only') === '1';
let page = Number(params.get('page')) || 1;

function card(tutor) {
  return el('article', { class: 'tutor-card' },
    el('div', { class: 'tutor-card-head' },
      avatarImg(tutor, 'lg'),
      el('div', {},
        el('h3', {}, el('a', { href: `/tutor?id=${tutor.id}` }, tutor.display_name)),
        el('p', { class: 'text-xs text-muted' },
          [tutor.age != null ? t('tutors.age', { n: tutor.age }) : null,
            tutor.gender ? t(`genders.${tutor.gender}`) : null].filter(Boolean).join(', ')),
        tutor.verified && el('span', { class: 'badge badge-verified' }, icon('check'), t('tutors.verified')))),
    el('p', { class: 'tutor-wage' }, tutor.hourly_wage ? formatHKD(tutor.hourly_wage) : t('tutors.wage_ask'),
      tutor.hourly_wage && el('span', {}, ` / ${t('tutors.hour')}`)),
    tutor.short_description && el('p', { class: 'tutor-desc' }, tutor.short_description),
    tutor.dse_results.length > 0 && el('ul', { class: 'chip-list', role: 'list', 'aria-label': t('tutors.dse_results') },
      tutor.dse_results.slice(0, 4).map((r) => el('li', {}, gradeStamp(r, r.subject)))),
    el('div', { class: 'tutor-card-foot' },
      tutor.rating_count
        ? el('span', { class: 'cluster' }, starRating(tutor.rating_avg),
          el('span', { class: 'text-xs text-muted' }, t('tutors.ratings', { n: tutor.rating_count })))
        : el('span', { class: 'text-xs text-muted' }, t('tutors.no_ratings')),
      el('a', { class: 'btn btn-sm', href: `/tutor?id=${tutor.id}` }, t('tutors.view'))),
    el('p', { class: 'text-xs text-muted' }, tutor.subjects.map(subjectName).join(', ')));
}

async function load() {
  const data = new FormData(form);
  const query = {
    q: data.get('q')?.trim(), subject: data.get('subject'), min_wage: data.get('min_wage'),
    max_wage: data.get('max_wage'), gender: data.get('gender'), sort: data.get('sort'),
    verified_only: form.verified_only.checked ? '1' : '', page: page > 1 ? page : '',
  };
  setQueryParams(query);
  const search = new URLSearchParams(Object.entries(query).filter(([, v]) => v));
  fill(list, ...skeletons(6));
  try {
    const result = await api(`/tutors?${search}`, { redirectOn401: false });
    count.textContent = t('tutors.count', { n: result.total });
    if (!result.items.length) {
      fill(list, emptyState({ title: t('tutors.none'), text: t('tutors.none_text') }));
    } else {
      fill(list, ...result.items.map(card));
    }
    renderPagination(pager, result, (p) => {
      page = p;
      load();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  } catch (err) {
    fill(list, emptyState({ title: errorMessage(err) }));
  }
}

const reload = debounce(() => {
  page = 1;
  load();
}, 300);
form.addEventListener('input', reload);
form.addEventListener('change', reload);
form.addEventListener('reset', () => setTimeout(reload, 0));
form.addEventListener('submit', (e) => e.preventDefault());

load();
