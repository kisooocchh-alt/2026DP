// js/pages/profile-edit.js - edit your own profile, picture and tutor certificate.
import { api } from '../core/api.js';
import { setCurrentUser } from '../core/auth.js';
import { CONFIG } from '../core/config.js';
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import {
  el, errorMessage, setLoading, showFieldErrors, showFormError, toast,
} from '../core/ui.js';
import { getSubjects, subjectOptions } from '../core/utils.js';
import { validateWage } from '../core/validators.js';
import { createImageUploader } from '../components/image-uploader.js';
import { createSubjectPicker } from '../components/subject-picker.js';

let me = await initPage({ requireLogin: true });
const form = document.getElementById('profile-form');
const submit = form.querySelector('button[type="submit"]');
const resultsRows = document.getElementById('results-rows');
const subjects = await getSubjects();

document.getElementById('view-profile').href = `/profile?u=${encodeURIComponent(me.username)}`;
document.getElementById('subjects-label').textContent = me.role === 'tutor'
  ? t('register.teaching_subjects') : t('profile.subjects');

// ---------------------------------------------------------------- fill the form
form.display_name.value = me.display_name || '';
form.gender.value = me.gender || '';
form.bio.value = me.bio || '';
form.contact.value = me.contact || '';
const bioCount = document.getElementById('bio-count');
const updateCount = () => { bioCount.textContent = `${form.bio.value.length} / ${CONFIG.BIO_MAX}`; };
form.bio.addEventListener('input', updateCount);
updateCount();

const picker = await createSubjectPicker(document.getElementById('subject-picker'), {
  selected: me.subjects, name: 'subjects',
});

if (me.role === 'student' && me.student) {
  document.getElementById('student-section').hidden = false;
  form.school.value = me.student.school || '';
  form.exam_year.value = me.student.exam_year || '';
  form.dse_goal.value = me.student.dse_goal || '';
}

function addResultRow(subject = '', grade = '') {
  const subjectSelect = el('select', { 'aria-label': t('register.result_subject', { n: resultsRows.children.length + 1 }) },
    el('option', { value: '' }, t('common.choose_subject')), subjectOptions(subjects, subject));
  const gradeSelect = el('select', { 'aria-label': t('register.grade') },
    el('option', { value: '' }, t('register.grade')),
    CONFIG.DSE_GRADES.map((g) => el('option', { value: g, selected: g === grade }, g)));
  const row = el('div', { class: 'result-row' }, subjectSelect, gradeSelect,
    el('button', { type: 'button', class: 'btn btn-ghost btn-sm', onclick: () => row.remove() }, t('common.remove')));
  resultsRows.append(row);
}

if (me.role === 'tutor' && me.tutor) {
  document.getElementById('tutor-section').hidden = false;
  document.getElementById('certificate-card').hidden = false;
  form.hourly_wage.value = me.tutor.hourly_wage || '';
  form.short_description.value = me.tutor.short_description || '';
  (me.tutor.dse_results.length ? me.tutor.dse_results : [{}]).forEach((r) => addResultRow(r.subject, r.grade));
  document.getElementById('add-result').addEventListener('click', () => addResultRow());
  document.getElementById('certificate-status').textContent = t(`profile_edit.cert_${me.tutor.certificate_status}`);
}

// ---------------------------------------------------------------- save
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  showFormError(form, '');
  const body = {
    display_name: form.display_name.value.trim(),
    gender: form.gender.value || null,
    bio: form.bio.value,
    contact: form.contact.value.trim(),
    subjects: picker.getValue(),
  };
  if (me.role === 'student') {
    body.student = {
      school: form.school.value.trim(),
      dse_goal: form.dse_goal.value.trim(),
      exam_year: form.exam_year.value ? Number(form.exam_year.value) : null,
    };
  } else {
    const wageProblem = validateWage(form.hourly_wage.value);
    if (wageProblem) {
      showFieldErrors(form, { hourly_wage: wageProblem });
      return;
    }
    body.tutor = {
      hourly_wage: form.hourly_wage.value ? Number(form.hourly_wage.value) : null,
      short_description: form.short_description.value.trim(),
      dse_results: [...resultsRows.querySelectorAll('.result-row')].map((row) => {
        const [s, g] = row.querySelectorAll('select');
        return { subject: s.value, grade: g.value };
      }).filter((r) => r.subject && r.grade),
    };
  }
  setLoading(submit, true);
  try {
    const { user } = await api('/profile', { method: 'PUT', body });
    me = user;
    setCurrentUser(user);
    toast(t('common.saved'), 'success');
  } catch (err) {
    if (err.fields) showFieldErrors(form, err.fields);
    showFormError(form, errorMessage(err));
  } finally {
    setLoading(submit, false);
  }
});

// ---------------------------------------------------------------- avatar
const avatarImgEl = document.getElementById('avatar-current');
const avatarSave = document.getElementById('avatar-save');
avatarImgEl.src = me.avatar_url;
const uploader = createImageUploader({
  input: document.getElementById('avatar-input'),
  preview: avatarImgEl,
  maxSide: 800,
  onChange: (file) => { avatarSave.hidden = !file; },
  onError: (code) => toast(t(`errors.${code}`), 'error'),
});
avatarSave.addEventListener('click', async () => {
  setLoading(avatarSave, true);
  try {
    const { avatar_url: url } = await uploader.upload('/profile/avatar', 'avatar');
    avatarImgEl.src = url;
    avatarSave.hidden = true;
    toast(t('profile_edit.avatar_saved'), 'success');
  } catch (err) {
    toast(errorMessage(err), 'error');
  } finally {
    setLoading(avatarSave, false);
  }
});
document.getElementById('avatar-remove').addEventListener('click', async () => {
  const { avatar_url: url } = await api('/profile/avatar', { method: 'DELETE' });
  uploader.clear();
  avatarImgEl.hidden = false;
  avatarImgEl.src = url;
});

// ---------------------------------------------------------------- certificate
document.getElementById('certificate-upload')?.addEventListener('click', async (e) => {
  const input = document.getElementById('certificate-input');
  if (!input.files[0]) {
    toast(t('errors.file_missing'), 'error');
    return;
  }
  const data = new FormData();
  data.append('certificate', input.files[0]);
  setLoading(e.target, true);
  try {
    const { certificate_status: status } = await api('/profile/certificate', { method: 'POST', form: data });
    document.getElementById('certificate-status').textContent = t(`profile_edit.cert_${status}`);
    input.value = '';
    toast(t('profile_edit.certificate_sent'), 'success');
  } catch (err) {
    toast(errorMessage(err), 'error');
  } finally {
    setLoading(e.target, false);
  }
});
