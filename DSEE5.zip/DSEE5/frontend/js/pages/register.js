// js/pages/register.js - sign-up for students and tutors.
import { api, resetCsrfToken } from '../core/api.js';
import { CONFIG } from '../core/config.js';
import { initPage } from '../core/page.js';
import { currentLanguage, t } from '../core/i18n.js';
import { el, errorMessage, fill, setLoading, showFieldErrors, showFormError } from '../core/ui.js';
import { getSubjects, subjectOptions } from '../core/utils.js';
import {
  ageFromBirthYear, passwordStrength, validateBirthYear, validateEmail, validateUsername,
} from '../core/validators.js';
import { renderCaptcha } from '../components/captcha.js';
import { createSubjectPicker } from '../components/subject-picker.js';

await initPage({ guestOnly: true });

const form = document.getElementById('register-form');
const submit = form.querySelector('button[type="submit"]');
const studentFields = document.getElementById('student-fields');
const tutorFields = document.getElementById('tutor-fields');
const minorNotice = document.getElementById('minor-notice');
const meter = document.getElementById('password-meter');
const resultsRows = document.getElementById('results-rows');
const subjects = await getSubjects();

// Birth year limits follow the server rule (10 to 90 years old), so they never go stale.
const thisYear = new Date().getFullYear();
form.birth_year.min = String(thisYear - 90);
form.birth_year.max = String(thisYear - 10);

// DSE year choices: this year and the next five.
fill(form.exam_year, ...Array.from({ length: 6 }, (_, i) => {
  const option = el('option', { value: thisYear + i }, String(thisYear + i));
  if (i === 1) option.selected = true;
  return option;
}));

const electives = await createSubjectPicker(document.getElementById('student-subjects'), {
  name: 'subjects', label: t('register.subjects'),
});
const teaching = await createSubjectPicker(document.getElementById('tutor-subjects'), {
  name: 'teaching_subjects', label: t('register.teaching_subjects'),
});
const captcha = await renderCaptcha(document.getElementById('captcha-box'));

// ---------------------------------------------------------------- role switch
function currentRole() {
  return form.role.value;
}

function updateRole() {
  const tutor = currentRole() === 'tutor';
  tutorFields.hidden = !tutor;
  studentFields.hidden = tutor;
  form.school.required = !tutor;
  form.dse_goal.required = !tutor;
  if (tutor && !resultsRows.children.length) addResultRow();
}
form.querySelectorAll('input[name="role"]').forEach((r) => r.addEventListener('change', updateRole));

// ---------------------------------------------------------------- DSE results rows
function addResultRow(subject = '', grade = '') {
  const index = resultsRows.children.length;
  const subjectSelect = el('select', { 'aria-label': t('register.result_subject', { n: index + 1 }) },
    el('option', { value: '' }, t('common.choose_subject')), subjectOptions(subjects, subject));
  const gradeSelect = el('select', { 'aria-label': t('register.result_grade', { n: index + 1 }) },
    el('option', { value: '' }, t('register.grade')),
    CONFIG.DSE_GRADES.map((g) => el('option', { value: g, selected: g === grade }, g)));
  const row = el('div', { class: 'result-row' }, subjectSelect, gradeSelect,
    el('button', { type: 'button', class: 'btn btn-ghost btn-sm', onclick: () => row.remove() },
      t('common.remove')));
  resultsRows.append(row);
}
document.getElementById('add-result').addEventListener('click', () => addResultRow());

function readResults() {
  return [...resultsRows.querySelectorAll('.result-row')]
    .map((row) => {
      const [subject, grade] = row.querySelectorAll('select');
      return { subject: subject.value, grade: grade.value };
    })
    .filter((r) => r.subject && r.grade);
}

// ---------------------------------------------------------------- live checks
document.getElementById('toggle-password').addEventListener('click', (e) => {
  const show = form.password.type === 'password';
  form.password.type = show ? 'text' : 'password';
  e.target.textContent = t(show ? 'common.hide' : 'common.show');
});

form.password.addEventListener('input', () => {
  meter.dataset.score = String(passwordStrength(form.password.value, form.username.value).score);
});

form.birth_year.addEventListener('input', () => {
  const age = ageFromBirthYear(form.birth_year.value);
  minorNotice.hidden = !(age !== null && age < CONFIG.MINOR_AGE && age >= 10);
});

// ---------------------------------------------------------------- submit
function localErrors() {
  const errors = {};
  const usernameProblem = validateUsername(form.username.value.trim());
  if (usernameProblem) errors.username = usernameProblem;
  const pw = passwordStrength(form.password.value, form.username.value);
  if (pw.code) errors.password = pw.code;
  if (form.password.value !== form.password2.value) errors.password2 = 'passwords_differ';
  const yearProblem = validateBirthYear(form.birth_year.value);
  if (yearProblem) errors.birth_year = yearProblem;
  const emailProblem = validateEmail(form.guardian_email.value.trim());
  if (emailProblem) errors.guardian_email = emailProblem;
  if (!form.accept_terms.checked) errors.accept_terms = 'terms_required';
  if (currentRole() === 'student') {
    if (!form.school.value.trim()) errors.school = 'school_required';
    if (!form.dse_goal.value.trim()) errors.dse_goal = 'dse_goal_required';
  } else {
    if (!teaching.getValue().length) errors.teaching_subjects = 'subjects_required';
    if (!readResults().length) errors.dse_results = 'dse_results_required';
  }
  return errors;
}

function placeErrors(errors) {
  // pickers and result rows have no single input, so show their errors next to the group
  form.querySelectorAll('[data-field] + .field-error, [data-field] > .field-error').forEach((n) => n.remove());
  for (const name of ['teaching_subjects', 'dse_results']) {
    if (!errors[name]) continue;
    const box = form.querySelector(`[data-field="${name}"]`);
    box.after(el('p', { class: 'field-error', dataset: { generated: '1' } }, t(`errors.${errors[name]}`)));
  }
  return showFieldErrors(form, errors);
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  showFormError(form, '');
  const problems = localErrors();
  if (Object.keys(problems).length) {
    placeErrors(problems);
    showFormError(form, t('errors.validation_failed'));
    return;
  }
  const role = currentRole();
  const body = {
    role,
    username: form.username.value.trim(),
    password: form.password.value,
    birth_year: Number(form.birth_year.value),
    gender: form.gender.value || null,
    guardian_email: form.guardian_email.value.trim() || null,
    accept_terms: form.accept_terms.checked,
    captcha_token: captcha.getToken(),
    language: currentLanguage(),
  };
  if (role === 'student') {
    Object.assign(body, {
      school: form.school.value.trim(),
      dse_goal: form.dse_goal.value.trim(),
      exam_year: Number(form.exam_year.value),
      subjects: electives.getValue(),
    });
  } else {
    Object.assign(body, { teaching_subjects: teaching.getValue(), dse_results: readResults() });
  }
  if (captcha.enabled && !body.captcha_token) {
    showFormError(form, t('errors.captcha_failed'));
    return;
  }
  setLoading(submit, true);
  try {
    await api('/auth/register', { method: 'POST', body, redirectOn401: false });
    resetCsrfToken();
    location.href = '/dashboard?welcome=1';
  } catch (err) {
    if (err.fields && Object.keys(err.fields).length) placeErrors(err.fields);
    showFormError(form, errorMessage(err));
    captcha.reset();
    setLoading(submit, false);
  }
});

updateRole();
