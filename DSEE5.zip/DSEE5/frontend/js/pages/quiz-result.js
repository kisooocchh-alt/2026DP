// js/pages/quiz-result.js - score, points, a topic-by-topic breakdown and a full review.
import { api } from '../core/api.js';
import { updateCachedScore } from '../core/auth.js';
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import { el, emptyState, errorMessage, fill } from '../core/ui.js';
import { getQueryParam, joinParts, subjectName } from '../core/utils.js';

await initPage({ requireLogin: true });
const root = document.getElementById('result-root');
const attemptId = Number(getQueryParam('attempt'));
const LETTERS = 'ABCDEF';

function duration(seconds) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return t('quiz.duration', { m, s });
}

/* One series (percent correct per topic), one hue, values written next to each bar,
   and the same numbers in plain text for screen readers. */
function topicBars(topics) {
  return el('div', { class: 'topic-bars', role: 'table', 'aria-label': t('quiz.by_topic') },
    topics.map((topic) => {
      const pct = topic.total ? Math.round((100 * topic.correct) / topic.total) : 0;
      const bar = el('span', { class: 'topic-fill' });
      // A small stub keeps a low score visible; zero stays empty so it is not mistaken for 2%.
      bar.style.width = `${pct ? Math.max(pct, 2) : 0}%`;
      return el('div', { class: 'topic-row', role: 'row', title: `${topic.topic}: ${topic.correct} / ${topic.total}` },
        el('span', { class: 'topic-name', role: 'rowheader' }, topic.topic),
        el('span', { class: 'topic-track', role: 'cell', 'aria-hidden': 'true' }, bar),
        el('span', { class: 'topic-value num', role: 'cell' }, `${topic.correct} / ${topic.total}`));
    }));
}

function review(q, i) {
  const status = q.answer ? (q.is_correct ? 'correct' : 'wrong') : 'blank';
  const body = [];
  if (q.type === 'mcq') {
    body.push(el('ul', { class: 'review-options', role: 'list' }, q.options.map((o, j) => {
      const isCorrect = o.id === q.correct_answer;
      const isMine = o.id === q.answer;
      return el('li', { class: `review-option ${isCorrect ? 'is-correct' : ''} ${isMine && !isCorrect ? 'is-wrong' : ''}` },
        el('span', { class: `bubble ${isMine ? 'is-filled' : ''}`, 'aria-hidden': 'true' }, LETTERS[j]),
        el('span', {}, o.text),
        isCorrect && el('span', { class: 'badge badge-ok' }, t('quiz.correct_answer')),
        isMine && el('span', { class: 'badge' }, t('quiz.your_choice')));
    })));
  } else {
    body.push(el('p', {}, el('strong', {}, `${t('quiz.your_answer')}: `), q.answer || t('quiz.no_answer')),
      el('p', {}, el('strong', {}, `${t('quiz.correct_answer')}: `), q.correct_answer));
  }
  if (q.explanation) body.push(el('p', { class: 'explanation' }, el('strong', {}, `${t('quiz.explanation')}: `), q.explanation));
  return el('details', { class: `review-item is-${status}`, open: status !== 'correct' },
    el('summary', {},
      el('span', { class: 'review-mark' }, status === 'correct' ? '✓' : status === 'wrong' ? '✗' : '–'),
      el('span', { class: 'review-title' }, `${i + 1}. `, q.prompt)),
    q.image_url && el('img', { class: 'question-image', src: q.image_url, alt: t('quiz.question_image') }),
    body);
}

try {
  const { result: r } = await api(`/attempts/${attemptId}/result`);
  document.title = `${r.title} - ${t('page.quiz_result')}`;
  const me = await api('/score').catch(() => null);
  if (me) updateCachedScore(me.score);
  const pointsText = r.points_awarded
    ? t('quiz.points_earned', { n: r.points_awarded })
    : t(`quiz.no_points.${r.points_reason}`);
  fill(root,
    getQueryParam('timeup') && el('p', { class: 'notice notice-warn mb-4' }, t('quiz.timeup_notice')),
    el('header', { class: 'result-head' },
      el('div', {},
        el('p', { class: 'text-sm text-muted' }, joinParts(subjectName(r.subject), t(`quiz.kinds.${r.kind}`))),
        el('h1', {}, r.title)),
      el('div', { class: 'result-score' },
        el('span', { class: 'result-percent num' }, `${r.percent}%`),
        el('span', { class: 'text-sm' }, t('quiz.raw', { raw: r.raw_score, max: r.max_score })))),
    el('div', { class: 'result-facts' },
      el('p', { class: `score-pill ${r.points_awarded ? '' : 'is-zero'}` }, `★ ${pointsText}`),
      el('p', { class: 'text-sm' }, t('quiz.time_used', { time: duration(r.time_used_sec), limit: r.time_limit_min }))),
    el('section', { class: 'card mt-6' }, el('h2', { class: 'mb-4' }, t('quiz.by_topic')), topicBars(r.topics)),
    el('section', { class: 'mt-6' }, el('h2', { class: 'mb-4' }, t('quiz.review_title')),
      el('div', { class: 'stack-sm' }, r.questions.map(review))),
    el('div', { class: 'form-actions mt-8' },
      el('a', { class: 'btn btn-primary', href: `/quizzes?subject=${r.subject}` }, t('quiz.try_another')),
      el('a', { class: 'btn', href: '/dashboard' }, t('nav.dashboard'))));
} catch (err) {
  fill(root, emptyState({ title: errorMessage(err), actionLabel: t('quiz.back'), actionHref: '/quizzes' }));
}
