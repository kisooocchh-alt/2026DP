// js/pages/settings.js - password, two-step login, devices, privacy, notifications,
// language, and your data (export / close account).
import { api } from '../core/api.js';
import { setCurrentUser } from '../core/auth.js';
import { CONFIG } from '../core/config.js';
import { initPage } from '../core/page.js';
import { currentLanguage, setLanguage, t } from '../core/i18n.js';
import {
  confirmDialog,
  el,
  errorMessage,
  fill,
  openModal,
  setLoading,
  showFieldErrors,
  showFormError,
  toast,
} from '../core/ui.js';
import { formatRelative, joinParts } from '../core/utils.js';
import { createSubjectPicker } from '../components/subject-picker.js';

let me = await initPage({ requireLogin: true });
document.getElementById('settings-username').textContent = `@${me.username}`;

// ---------------------------------------------------------------- password
const pwForm = document.getElementById('password-form');
pwForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  showFormError(pwForm, '');
  const button = pwForm.querySelector('button[type="submit"]');
  setLoading(button, true);
  try {
    await api('/auth/password', {
      method: 'POST',
      body: { old_password: pwForm.old_password.value, new_password: pwForm.new_password.value },
    });
    pwForm.reset();
    toast(t('settings.password_changed'), 'success');
    loadSessions();
  } catch (err) {
    if (err.fields) showFieldErrors(pwForm, err.fields);
    showFormError(pwForm, errorMessage(err));
  } finally {
    setLoading(button, false);
  }
});

document.querySelectorAll('[data-lang]').forEach((button) => {
  button.classList.toggle('btn-primary', button.dataset.lang === currentLanguage());
  button.addEventListener('click', async () => {
    await api('/profile/language', { method: 'PUT', body: { language: button.dataset.lang } }).catch(() => {});
    setLanguage(button.dataset.lang);
  });
});

// ---------------------------------------------------------------- two-step login
const status = document.getElementById('twofa-status');
const actions = document.getElementById('twofa-actions');
const setupBox = document.getElementById('twofa-setup');
const recoveryBox = document.getElementById('recovery-box');

function showRecoveryCodes(codes) {
  recoveryBox.hidden = false;
  fill(document.getElementById('recovery-codes'), ...codes.map((c) => el('li', {}, el('code', {}, c))));
  document.getElementById('copy-codes').onclick = () => {
    navigator.clipboard?.writeText(codes.join('\n')).then(() => toast(t('common.copied'), 'success'));
  };
}

/** A small modal form. Resolves to { name: value } or null if cancelled. */
function askFields(title, fields) {
  return new Promise((resolve) => {
    const inputs = fields.map((f) => el('input', {
      id: `ask-${f.name}`, name: f.name, type: f.type || 'text', required: true,
      autocomplete: f.autocomplete || 'off', inputmode: f.inputmode || null,
    }));
    const form = el('form', { method: 'dialog', class: 'modal-body' },
      el('h2', {}, title),
      fields.map((f, i) => el('div', { class: 'field' }, el('label', { for: `ask-${f.name}` }, f.label), inputs[i])),
      el('div', { class: 'form-actions' },
        el('button', { class: 'btn btn-primary', value: 'ok' }, t('common.confirm')),
        el('button', { class: 'btn', value: 'cancel', formnovalidate: true }, t('common.cancel'))));
    openModal(form, {
      onClose: (value) => resolve(value === 'ok'
        ? Object.fromEntries(inputs.map((input) => [input.name, input.value.trim()])) : null),
    });
    inputs[0].focus();
  });
}

const CODE_FIELD = { name: 'code', label: t('settings.ask_code'), inputmode: 'numeric', autocomplete: 'one-time-code' };

function renderTwoFactor() {
  setupBox.hidden = true;
  if (me.has_2fa) {
    status.textContent = t('settings.twofa_on', { n: me.recovery_codes_left });
    fill(actions,
      el('button', {
        class: 'btn btn-sm', type: 'button',
        onclick: async () => {
          const answer = await askFields(t('settings.new_codes'), [CODE_FIELD]);
          if (!answer) return;
          try {
            const { recovery_codes: codes } = await api('/auth/2fa/recovery-codes', { method: 'POST', body: answer });
            showRecoveryCodes(codes);
          } catch (err) {
            toast(errorMessage(err), 'error');
          }
        },
      }, t('settings.new_codes')),
      el('button', {
        class: 'btn btn-sm btn-danger', type: 'button',
        onclick: async () => {
          const answer = await askFields(t('settings.twofa_turn_off'), [
            { name: 'password', label: t('settings.ask_password'), type: 'password', autocomplete: 'current-password' },
            CODE_FIELD]);
          if (!answer) return;
          try {
            await api('/auth/2fa/disable', { method: 'POST', body: answer });
            me = { ...me, has_2fa: false };
            toast(t('settings.twofa_turned_off'), 'success');
            renderTwoFactor();
          } catch (err) {
            toast(errorMessage(err), 'error');
          }
        },
      }, t('settings.twofa_turn_off')));
  } else {
    status.textContent = t('settings.twofa_off');
    fill(actions, el('button', {
      class: 'btn btn-primary btn-sm', type: 'button',
      onclick: async (e) => {
        setLoading(e.currentTarget, true);
        try {
          const data = await api('/auth/2fa/setup', { method: 'POST' });
          document.getElementById('twofa-qr').src = data.qr_data_uri;
          document.getElementById('twofa-secret').textContent = data.secret;
          setupBox.hidden = false;
          document.getElementById('twofa-code').focus();
        } catch (err) {
          toast(errorMessage(err), 'error');
        } finally {
          setLoading(e.currentTarget, false);
        }
      },
    }, t('settings.twofa_set_up')));
  }
}

document.getElementById('twofa-enable-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const code = document.getElementById('twofa-code').value.trim();
  try {
    const { recovery_codes: codes } = await api('/auth/2fa/enable', { method: 'POST', body: { code } });
    me = { ...me, has_2fa: true, recovery_codes_left: codes.length };
    renderTwoFactor();
    showRecoveryCodes(codes);
    toast(t('settings.twofa_turned_on'), 'success');
  } catch (err) {
    toast(errorMessage(err), 'error');
  }
});
renderTwoFactor();

// ---------------------------------------------------------------- devices
async function loadSessions() {
  const list = document.getElementById('sessions-list');
  const { sessions } = await api('/auth/sessions');
  fill(list, ...sessions.map((s) => el('li', {},
    el('div', { class: 'row-main' },
      el('p', { class: 'row-title truncate' }, describeAgent(s.user_agent)),
      el('p', { class: 'row-meta' }, joinParts(s.ip, `${t('settings.last_active')} ${formatRelative(s.last_seen_at)}`))),
    s.current
      ? el('span', { class: 'badge badge-ok' }, t('settings.this_device'))
      : el('button', {
        class: 'btn btn-sm', type: 'button',
        onclick: async () => {
          await api(`/auth/sessions/${s.id}`, { method: 'DELETE' });
          loadSessions();
        },
      }, t('settings.log_out')))));
}

function describeAgent(agent) {
  const browser = /Edg\//.test(agent) ? 'Edge' : /Chrome\//.test(agent) ? 'Chrome'
    : /Firefox\//.test(agent) ? 'Firefox' : /Safari\//.test(agent) ? 'Safari' : t('settings.browser');
  const os = /Windows/.test(agent) ? 'Windows' : /iPhone|iPad/.test(agent) ? 'iOS'
    : /Android/.test(agent) ? 'Android' : /Mac OS/.test(agent) ? 'macOS' : /Linux/.test(agent) ? 'Linux' : '';
  return joinParts(browser, os);
}

document.getElementById('logout-others').addEventListener('click', async () => {
  const { ended } = await api('/auth/sessions/revoke-others', { method: 'POST' });
  toast(t('settings.logged_out_others', { n: ended }), 'success');
  loadSessions();
});
loadSessions();

// ---------------------------------------------------------------- privacy
const privacyForm = document.getElementById('privacy-form');
for (const [name, value] of [['show_age', me.privacy.age], ['show_school', me.privacy.school],
  ['show_contact', me.privacy.contact]]) {
  fill(privacyForm[name], ...CONFIG.VISIBILITY.map((v) => el('option', {
    value: v, selected: v === value,
    disabled: me.is_minor && v === 'everyone' && name !== 'show_school',
  }, t(`settings.visibility.${v}`))));
}
if (me.role === 'tutor') privacyForm.show_school.closest('.field').hidden = true;
document.getElementById('minor-privacy').hidden = !me.is_minor;
document.getElementById('guardian-field').hidden = !me.is_minor;
privacyForm.guardian_email.value = me.guardian_email || '';

privacyForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  showFormError(privacyForm, '');
  const body = {
    show_age: privacyForm.show_age.value,
    show_school: privacyForm.show_school.value,
    show_contact: privacyForm.show_contact.value,
  };
  if (me.is_minor) body.guardian_email = privacyForm.guardian_email.value.trim() || null;
  try {
    const { user } = await api('/profile/privacy', { method: 'PUT', body });
    me = user;
    setCurrentUser(user);
    toast(t('common.saved'), 'success');
  } catch (err) {
    if (err.fields) showFieldErrors(privacyForm, err.fields);
    showFormError(privacyForm, errorMessage(err));
  }
});

// ---------------------------------------------------------------- push notifications
const pushStatus = document.getElementById('push-status');
const pushToggle = document.getElementById('push-toggle');

function urlBase64ToUint8Array(base64) {
  const padding = '='.repeat((4 - (base64.length % 4)) % 4);
  const raw = atob((base64 + padding).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
}

async function setupPush() {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
    pushStatus.textContent = t('settings.push_unsupported');
    pushToggle.hidden = true;
    return;
  }
  const { enabled, key } = await api('/notifications/vapid-key');
  if (!enabled) {
    pushStatus.textContent = t('settings.push_server_off');
    pushToggle.hidden = true;
    return;
  }
  const registration = await navigator.serviceWorker.ready;
  let subscription = await registration.pushManager.getSubscription();
  const render = () => {
    pushStatus.textContent = subscription ? t('settings.push_is_on') : t('settings.push_is_off');
    pushToggle.textContent = subscription ? t('settings.push_off') : t('settings.push_on');
  };
  render();
  pushToggle.addEventListener('click', async () => {
    try {
      if (subscription) {
        await api('/notifications/subscribe', { method: 'DELETE', body: { endpoint: subscription.endpoint } });
        await subscription.unsubscribe();
        subscription = null;
      } else {
        const permission = await Notification.requestPermission();
        if (permission !== 'granted') {
          toast(t('settings.push_denied'), 'error');
          return;
        }
        subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true, applicationServerKey: urlBase64ToUint8Array(key),
        });
        await api('/notifications/subscribe', { method: 'POST', body: { subscription: subscription.toJSON() } });
      }
      render();
    } catch (err) {
      toast(errorMessage(err), 'error');
    }
  });
}
setupPush().catch(() => { pushStatus.textContent = t('settings.push_unsupported'); });

// ---------------------------------------------------------------- countdown subjects
const following = await api('/countdown/following').then((d) => d.subjects).catch(() => []);
const followPicker = await createSubjectPicker(document.getElementById('follow-picker'), {
  selected: following, name: 'follow', max: 30,
});
document.getElementById('follow-save').addEventListener('click', async (e) => {
  setLoading(e.target, true);
  try {
    await api('/countdown/following', { method: 'PUT', body: { subjects: followPicker.getValue() } });
    toast(t('common.saved'), 'success');
  } catch (err) {
    toast(errorMessage(err), 'error');
  } finally {
    setLoading(e.target, false);
  }
});

// ---------------------------------------------------------------- close account
const deleteForm = document.getElementById('delete-form');
deleteForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  showFormError(deleteForm, '');
  if (!deleteForm.password.value) {
    showFormError(deleteForm, t('errors.password_wrong'));
    return;
  }
  const sure = await confirmDialog(t('settings.delete_confirm'), { danger: true, okLabel: t('settings.delete_button') });
  if (!sure) return;
  try {
    await api('/profile/delete', { method: 'POST', body: { password: deleteForm.password.value } });
    location.href = '/';
  } catch (err) {
    showFormError(deleteForm, errorMessage(err));
  }
});
