// js/pages/material-view.js - read one material at /material?id=45.
// "Save offline" stores the file in the browser cache through the service worker.
import { api } from '../core/api.js';
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import {
  el, emptyState, errorMessage, fill, icon, safeUrl, setLoading, toast,
} from '../core/ui.js';
import { formatBytes, formatDate, getQueryParam, subjectName } from '../core/utils.js';

await initPage({ requireLogin: true });
const root = document.getElementById('material-root');
const id = Number(getQueryParam('id'));
const fileUrl = `/api/materials/${id}/file`;

async function isOffline() {
  if (!('caches' in window)) return false;
  const cache = await caches.open('dsee5-materials');
  return Boolean(await cache.match(fileUrl));
}

function viewer(m) {
  if (m.kind === 'pdf') {
    return el('iframe', { class: 'pdf-frame', src: fileUrl, title: m.title });
  }
  if (m.kind === 'image') {
    return el('img', { class: 'material-image', src: fileUrl, alt: m.title });
  }
  if (m.kind === 'video_link') {
    return el('div', { class: 'video-box' },
      icon('video', 'video-icon'),
      el('p', {}, t('materials.video_text')),
      el('a', { class: 'btn btn-primary', href: safeUrl(m.url), target: '_blank', rel: 'noopener noreferrer' },
        icon('external'), t('materials.open_video')));
  }
  return el('div', { class: 'note-body pre-wrap' }, m.body);
}

async function bookmarkButton(m) {
  const button = el('button', { class: 'btn', type: 'button', 'aria-pressed': String(Boolean(m.bookmark_id)) },
    icon('bookmark'), m.bookmark_id ? t('bookmarks.remove') : t('bookmarks.add'));
  button.addEventListener('click', async () => {
    try {
      if (m.bookmark_id) {
        await api(`/bookmarks/${m.bookmark_id}`, { method: 'DELETE' });
        m.bookmark_id = null;
      } else {
        m.bookmark_id = (await api('/bookmarks', { method: 'POST', body: { item_type: 'material', item_id: m.id } })).bookmark_id;
      }
      button.setAttribute('aria-pressed', String(Boolean(m.bookmark_id)));
      fill(button, icon('bookmark'), m.bookmark_id ? t('bookmarks.remove') : t('bookmarks.add'));
    } catch (err) {
      toast(errorMessage(err), 'error');
    }
  });
  return button;
}

async function offlineButton() {
  if (!('caches' in window)) return null;
  let saved = await isOffline();
  const button = el('button', { class: 'btn', type: 'button' });
  const render = () => fill(button, icon(saved ? 'trash' : 'offline'),
    saved ? t('materials.remove_offline') : t('materials.save_offline'));
  render();
  button.addEventListener('click', async () => {
    setLoading(button, true);
    try {
      const cache = await caches.open('dsee5-materials');
      if (saved) await cache.delete(fileUrl);
      else await cache.add(new Request(fileUrl, { credentials: 'same-origin' }));
      saved = !saved;
      toast(saved ? t('materials.saved_offline') : t('materials.removed_offline'), 'success');
    } catch {
      toast(t('errors.network_error'), 'error');
    } finally {
      setLoading(button, false);
      render();
    }
  });
  return button;
}

async function render(m) {
  document.title = `${m.title} - DSEE5`;
  const hasFile = m.kind === 'pdf' || m.kind === 'image';
  fill(root,
    el('header', { class: 'material-head' },
      el('p', { class: 'row-meta' }, [subjectName(m.subject), m.topic, t(`materials.kinds.${m.kind}`)].join(', ')),
      el('h1', {}, m.title),
      m.description && el('p', { class: 'text-muted' }, m.description),
      el('p', { class: 'text-xs text-muted' }, t('materials.updated', { date: formatDate(m.updated_at) }),
        m.file_size ? `, ${formatBytes(m.file_size)}` : '')),
    el('div', { class: 'cluster material-actions' },
      hasFile && m.allow_download && el('a', { class: 'btn btn-primary', href: `${fileUrl}?download=1` },
        icon('download'), t('materials.download')),
      hasFile && await offlineButton(),
      await bookmarkButton(m)),
    el('div', { class: 'viewer' }, viewer(m)));
}

try {
  if (!id) throw new Error('not_found');
  const { material } = await api(`/materials/${id}`);
  await render(material);
} catch (err) {
  fill(root, emptyState({ title: t('materials.not_found'), text: errorMessage(err),
    actionLabel: t('materials.back'), actionHref: '/materials' }));
}
