// js/pages/notifications.js - every notification, newest first.
import { api } from '../core/api.js';
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import { el, emptyState, errorMessage, fill, safeUrl, skeletons, toast } from '../core/ui.js';
import { formatDateTime, joinParts } from '../core/utils.js';

await initPage({ requireLogin: true });

const list = document.getElementById('notification-list');
const markAll = document.getElementById('mark-all');

function row(n) {
  const link = safeUrl(n.link || '/notifications');
  return el('li', { class: n.is_read ? '' : 'is-unread' },
    el('span', { class: 'notification-kind', 'aria-hidden': 'true' }),
    el('div', { class: 'row-main' },
      el('a', {
        class: 'row-title', href: link,
        onclick: async () => {
          if (!n.is_read) await api('/notifications/read', { method: 'POST', body: { ids: [n.id] } }).catch(() => {});
        },
      }, n.title),
      n.body && el('p', { class: 'text-sm' }, n.body),
      el('p', { class: 'row-meta' }, joinParts(t(`notifications.kinds.${n.kind}`), formatDateTime(n.created_at)))));
}

async function load() {
  fill(list, ...skeletons(3).map((s) => el('li', {}, s)));
  try {
    const { items, unread } = await api('/notifications');
    markAll.disabled = unread === 0;
    if (!items.length) {
      list.replaceWith(emptyState({ title: t('notifications.none'), text: t('notifications.none_text') }));
      return;
    }
    fill(list, ...items.map(row));
  } catch (err) {
    toast(errorMessage(err), 'error');
  }
}

markAll.addEventListener('click', async () => {
  await api('/notifications/read', { method: 'POST', body: {} });
  document.dispatchEvent(new CustomEvent('dsee5:notifications'));
  await load();
});

await load();
