// js/pages/login.js - login form: password, then a 2FA code or CAPTCHA if the server asks.
import { api, resetCsrfToken } from '../core/api.js';
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import { errorMessage, setLoading, showFormError } from '../core/ui.js';
import { getQueryParam, safeNextPath } from '../core/utils.js';
import { renderCaptcha } from '../components/captcha.js';

await initPage({ guestOnly: true });

const form = document.getElementById('login-form');
const submit = form.querySelector('button[type="submit"]');
const totpField = document.getElementById('totp-field');
const captchaBox = document.getElementById('captcha-box');
const password = document.getElementById('password');
let captcha = null;

document.getElementById('toggle-password').addEventListener('click', (e) => {
  const show = password.type === 'password';
  password.type = show ? 'text' : 'password';
  e.target.textContent = t(show ? 'common.hide' : 'common.show');
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  showFormError(form, '');
  const body = {
    username: form.username.value.trim(),
    password: form.password.value,
  };
  if (!body.username || !body.password) {
    showFormError(form, t('errors.fill_both'));
    return;
  }
  if (!totpField.hidden) body.totp_code = form.totp_code.value.trim();
  if (captcha?.enabled) body.captcha_token = captcha.getToken();

  setLoading(submit, true);
  try {
    await api('/auth/login', { method: 'POST', body, redirectOn401: false });
    resetCsrfToken();
    location.href = safeNextPath(getQueryParam('next')) || '/dashboard';
  } catch (err) {
    if (err.code === 'totp_required') {
      totpField.hidden = false;
      form.totp_code.focus();
      showFormError(form, t('errors.totp_required'));
    } else {
      showFormError(form, errorMessage(err));
    }
    if (err.data?.captcha_required && !captcha) {
      captcha = await renderCaptcha(captchaBox);
    } else {
      captcha?.reset();
    }
    setLoading(submit, false);
  }
});

form.username.focus();
