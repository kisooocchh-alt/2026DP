// js/pages/papers.js - browse past papers, grouped by year. Downloads are plain links
// so the browser handles the file; the server checks the login.
import { api } from '../core/api.js';
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import { el, emptyState, errorMessage, fill, icon, skeletons, toast } from '../core/ui.js';
import {
  formatBytes,
  getSubjects,
  joinParts,
  setQueryParams,
  subjectName,
  subjectOptions,
} from '../core/utils.js';

const user = await initPage();
const form = document.getElementById('paper-filters');
const root = document.getElementById('papers-root');
const params = new URLSearchParams(location.search);

fill(form.subject, ...subjectOptions(await getSubjects(), params.get('subject') || '', { includeAll: true }));
form.language.value = params.get('language') || '';
let selectedYear = params.get('year') || '';

async function toggleBookmark(paper, button) {
  if (!user) {
    location.href = '/login?next=/papers';
    return;
  }
  try {
    if (paper.bookmark_id) {
      await api(`/bookmarks/${paper.bookmark_id}`, { method: 'DELETE' });
      paper.bookmark_id = null;
    } else {
      paper.bookmark_id = (await api('/bookmarks', { method: 'POST', body: { item_type: 'paper', item_id: paper.id } })).bookmark_id;
    }
    button.setAttribute('aria-pressed', String(Boolean(paper.bookmark_id)));
    button.title = paper.bookmark_id ? t('bookmarks.remove') : t('bookmarks.add');
  } catch (err) {
    toast(errorMessage(err), 'error');
  }
}

function paperRow(p) {
  const download = (file) => (user
    ? `/api/papers/${p.id}/download${file === 'marking' ? '?file=marking' : ''}`
    : `/login?next=${encodeURIComponent(`/papers?subject=${p.subject}`)}`);
  const bookmark = el('button', {
    class: 'icon-btn bookmark-btn', type: 'button', 'aria-pressed': String(Boolean(p.bookmark_id)),
    'aria-label': t('bookmarks.add'), title: p.bookmark_id ? t('bookmarks.remove') : t('bookmarks.add'),
  }, icon('bookmark'));
  bookmark.addEventListener('click', () => toggleBookmark(p, bookmark));
  return el('li', {},
    el('span', { class: 'paper-code' }, p.subject),
    el('div', { class: 'row-main' },
      el('p', { class: 'row-title' }, joinParts(subjectName(p.subject), p.paper)),
      el('p', { class: 'row-meta' }, [t(`papers.lang_${p.language}`), formatBytes(p.file_size),
        t('papers.downloads', { n: p.downloads })].join(', '))),
    el('div', { class: 'cluster' },
      el('a', { class: 'btn btn-sm btn-primary', href: download('paper'), rel: 'nofollow' }, icon('download'), t('papers.download')),
      p.has_marking && el('a', { class: 'btn btn-sm', href: download('marking'), rel: 'nofollow' }, t('papers.marking')),
      bookmark));
}

async function load() {
  const query = { subject: form.subject.value, year: selectedYear, language: form.language.value };
  setQueryParams(query);
  fill(root, ...skeletons(3));
  try {
    const { papers, years } = await api(`/papers?${new URLSearchParams(Object.entries(query).filter(([, v]) => v))}`,
      { redirectOn401: false });
    fill(form.year, el('option', { value: '' }, t('papers.all_years')),
      years.map((y) => el('option', { value: y, selected: String(y) === selectedYear }, String(y))));
    if (!papers.length) {
      fill(root, emptyState({ title: t('papers.none'), text: t('papers.none_text') }));
      return;
    }
    const byYear = new Map();
    papers.forEach((p) => byYear.set(p.year, [...(byYear.get(p.year) || []), p]));
    fill(root, ...[...byYear.entries()].map(([year, items]) => el('section', { class: 'year-group' },
      el('h2', { class: 'year-heading' }, String(year)),
      el('ul', { class: 'row-list', role: 'list' }, items.map(paperRow)))));
  } catch (err) {
    fill(root, emptyState({ title: errorMessage(err) }));
  }
}

form.subject.addEventListener('change', () => {
  selectedYear = '';
  load();
});
form.year.addEventListener('change', () => {
  selectedYear = form.year.value;
  load();
});
form.language.addEventListener('change', load);
form.addEventListener('submit', (e) => e.preventDefault());
load();
