// js/pages/bookings.js - manage booking requests, and rate tutors after lessons.
import { api } from '../core/api.js';
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import {
  avatarImg, confirmDialog, el, emptyState, errorMessage, fill, openModal, toast,
} from '../core/ui.js';
import { formatDateTime, joinParts, subjectName } from '../core/utils.js';

const me = await initPage({ requireLogin: true });
const list = document.getElementById('booking-list');
const tabs = [...document.querySelectorAll('[role="tab"]')];
let data = { sent: [], received: [] };
let current = me.role === 'tutor' ? 'received' : 'sent';

const STATUS_CLASS = {
  pending: 'badge-warn', accepted: 'badge-ok', completed: 'badge-ok', declined: 'badge-danger', cancelled: '',
};

async function act(booking, action, confirmKey) {
  if (confirmKey && !(await confirmDialog(t(confirmKey)))) return;
  try {
    await api(`/bookings/${booking.id}`, { method: 'PATCH', body: { action } });
    toast(t(`bookings.done_${action}`), 'success');
    load();
  } catch (err) {
    toast(errorMessage(err), 'error');
  }
}

function rateDialog(booking) {
  const stars = el('fieldset', { class: 'star-input' },
    el('legend', { class: 'sr-only' }, t('bookings.stars')),
    [5, 4, 3, 2, 1].map((n) => [
      el('input', { type: 'radio', name: 'stars', id: `star-${n}`, value: n, required: true }),
      el('label', { for: `star-${n}`, title: t('tutors.stars_label', { n }) }, '★'),
    ]));
  const comment = el('textarea', { id: 'rate-comment', name: 'comment', rows: 3, maxlength: 500 });
  const error = el('p', { class: 'form-error', hidden: true });
  const form = el('form', { class: 'modal-body' },
    el('h2', {}, t('bookings.rate_title', { name: booking.tutor.display_name })),
    el('p', { class: 'label-like' }, t('bookings.stars')), stars,
    el('div', { class: 'field' }, el('label', { for: 'rate-comment' }, t('bookings.comment')), comment),
    error,
    el('div', { class: 'form-actions' },
      el('button', { class: 'btn btn-primary', type: 'submit' }, t('bookings.send_rating')),
      el('button', { class: 'btn', type: 'button', onclick: () => dialog.close() }, t('common.cancel'))));
  const dialog = openModal(form);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const chosen = form.querySelector('input[name="stars"]:checked');
    if (!chosen) {
      error.textContent = t('errors.stars_invalid');
      error.hidden = false;
      return;
    }
    try {
      await api(`/tutors/${booking.tutor.id}/ratings`, {
        method: 'POST', body: { booking_id: booking.id, stars: Number(chosen.value), comment: comment.value.trim() },
      });
      dialog.close();
      toast(t('bookings.rated'), 'success');
      load();
    } catch (err) {
      error.textContent = errorMessage(err);
      error.hidden = false;
    }
  });
}

function bookingCard(b) {
  const other = b.my_role === 'student' ? b.tutor : b.student;
  const buttons = [];
  if (b.my_role === 'tutor' && b.status === 'pending') {
    buttons.push(el('button', { class: 'btn btn-primary btn-sm', type: 'button', onclick: () => act(b, 'accept') }, t('bookings.accept')),
      el('button', { class: 'btn btn-sm', type: 'button', onclick: () => act(b, 'decline', 'bookings.confirm_decline') }, t('bookings.decline')));
  }
  if (b.my_role === 'student' && b.status === 'accepted') {
    buttons.push(el('button', { class: 'btn btn-primary btn-sm', type: 'button', onclick: () => act(b, 'complete', 'bookings.confirm_complete') }, t('bookings.complete')));
  }
  if (['pending', 'accepted'].includes(b.status)) {
    buttons.push(el('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: () => act(b, 'cancel', 'bookings.confirm_cancel') }, t('bookings.cancel')));
  }
  if (b.can_rate) {
    buttons.push(el('button', { class: 'btn btn-primary btn-sm', type: 'button', onclick: () => rateDialog(b) }, t('bookings.rate')));
  }
  return el('article', { class: 'card booking-card' },
    el('div', { class: 'booking-head' },
      avatarImg(other),
      el('div', { class: 'row-main' },
        el('p', { class: 'row-title' },
          other.username ? el('a', { href: `/profile?u=${encodeURIComponent(other.username)}` }, other.display_name) : t('common.deleted_user')),
        el('p', { class: 'row-meta' }, joinParts(subjectName(b.subject), formatDateTime(b.created_at)))),
      el('span', { class: `badge ${STATUS_CLASS[b.status] || ''}` }, t(`bookings.status.${b.status}`))),
    el('p', { class: 'pre-wrap' }, b.message),
    b.preferred_times && el('p', { class: 'text-sm' }, el('strong', {}, `${t('booking.times')}: `), b.preferred_times),
    b.other_contact !== null && el('p', { class: 'form-success' }, `${t('bookings.contact')}: `, b.other_contact || t('booking.no_contact')),
    b.rated && el('p', { class: 'text-xs text-muted' }, t('bookings.already_rated')),
    buttons.length > 0 && el('div', { class: 'form-actions' }, buttons));
}

function render() {
  tabs.forEach((tab) => tab.setAttribute('aria-selected', String(tab.dataset.tab === current)));
  const items = data[current];
  if (!items.length) {
    fill(list, emptyState(current === 'sent'
      ? { title: t('bookings.none_sent'), text: t('bookings.none_sent_text'), actionLabel: t('bookings.find_tutor'), actionHref: '/tutors' }
      : { title: t('bookings.none_received'), text: t('bookings.none_received_text') }));
    return;
  }
  fill(list, ...items.map(bookingCard));
}

async function load() {
  data = await api('/bookings');
  render();
}

tabs.forEach((tab) => tab.addEventListener('click', () => {
  current = tab.dataset.tab;
  render();
}));
if (me.role === 'student') document.getElementById('tab-received').hidden = true;
load();
