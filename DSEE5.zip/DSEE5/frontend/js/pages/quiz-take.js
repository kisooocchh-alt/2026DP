// js/pages/quiz-take.js - answer a timed assessment at /quiz-take?attempt=88.
// The server owns the deadline: the timer counts down to it, answers are auto-saved,
// and the attempt is submitted automatically when time is up.
import { api } from '../core/api.js';
import { CONFIG } from '../core/config.js';
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import { storage } from '../core/storage.js';
import { confirmDialog, el, errorMessage, fill, icon, setLoading, toast } from '../core/ui.js';
import { getQueryParam, joinParts, subjectName } from '../core/utils.js';
import { createQuizTimer } from '../components/quiz-timer.js';

await initPage({ requireLogin: true });

const attemptId = Number(getQueryParam('attempt'));
const area = document.getElementById('question-area');
const palette = document.getElementById('palette');
const saveStatus = document.getElementById('save-status');
const submitBtn = document.getElementById('submit-btn');
const flagBtn = document.getElementById('flag-btn');
const LETTERS = 'ABCDEF';

let attempt;
try {
  attempt = (await api(`/attempts/${attemptId}`)).attempt;
} catch (err) {
  toast(errorMessage(err), 'error');
  location.href = '/quizzes';
  await new Promise(() => {}); // stop here while the browser navigates
}
if (attempt.status !== 'in_progress') {
  location.href = `/quiz-result?attempt=${attemptId}`;
  await new Promise(() => {});
}

const questions = attempt.questions;
const answers = Object.fromEntries(questions.filter((q) => q.answer).map((q) => [q.id, q.answer]));
const dirty = new Set();
const flagKey = `flags:${attemptId}`;
const flagged = new Set(storage.get(flagKey, []));
let index = 0;
let submitting = false;

document.getElementById('quiz-title').textContent = attempt.title;
document.getElementById('quiz-subject').textContent =
  joinParts(subjectName(attempt.subject), t(`quiz.kinds.${attempt.kind}`));
document.title = `${attempt.title} - DSEE5`;

// ---------------------------------------------------------------- rendering
function renderPalette() {
  fill(palette, ...questions.map((q, i) => el('button', {
    type: 'button', role: 'listitem',
    class: ['palette-item', answers[q.id] ? 'is-answered' : '', flagged.has(q.id) ? 'is-flagged' : '',
      i === index ? 'is-current' : ''].join(' '),
    'aria-current': i === index ? 'step' : null,
    'aria-label': t('quiz.go_to', { n: i + 1 }),
    onclick: () => go(i),
  }, String(i + 1))));
}

function setAnswer(q, value) {
  if (value) answers[q.id] = value;
  else delete answers[q.id];
  dirty.add(q.id);
  saveStatus.textContent = t('quiz.unsaved');
  renderPalette();
}

function renderQuestion() {
  const q = questions[index];
  const header = el('div', { class: 'question-head' },
    el('span', { class: 'question-number' }, t('quiz.question_n', { n: index + 1, total: questions.length })),
    el('span', { class: 'text-xs text-muted' }, joinParts(q.topic, t('quiz.marks', { n: q.marks }))));
  const parts = [header, el('p', { class: 'question-prompt', id: 'q-prompt' }, q.prompt)];
  if (q.image_url) parts.push(el('img', { class: 'question-image', src: q.image_url, alt: t('quiz.question_image') }));

  if (q.type === 'mcq') {
    parts.push(el('div', { class: 'options', role: 'radiogroup', 'aria-labelledby': 'q-prompt' },
      q.options.map((o, i) => el('label', { class: 'option' },
        el('input', {
          type: 'radio', name: `q${q.id}`, value: o.id, checked: answers[q.id] === o.id,
          onchange: () => setAnswer(q, o.id),
        }),
        el('span', { class: 'bubble', 'aria-hidden': 'true' }, LETTERS[i]),
        el('span', { class: 'option-text' }, o.text)))));
  } else {
    const input = el('input', {
      type: 'text', id: 'short-answer', class: 'short-answer', maxlength: 300, autocomplete: 'off',
      value: answers[q.id] || '', placeholder: t('quiz.type_answer'),
    });
    input.addEventListener('input', () => setAnswer(q, input.value.trim()));
    parts.push(el('div', { class: 'field' },
      el('label', { for: 'short-answer' }, t('quiz.your_answer')), input,
      el('p', { class: 'field-hint' }, t('quiz.short_hint'))));
  }
  fill(area, ...parts);
  flagBtn.setAttribute('aria-pressed', String(flagged.has(q.id)));
  fill(flagBtn, icon('flag'), flagged.has(q.id) ? t('quiz.unflag') : t('quiz.flag'));
  document.getElementById('prev-btn').disabled = index === 0;
  const next = document.getElementById('next-btn');
  next.textContent = index === questions.length - 1 ? t('quiz.review') : t('quiz.next');
  renderPalette();
}

function go(i) {
  index = Math.max(0, Math.min(questions.length - 1, i));
  renderQuestion();
  area.focus({ preventScroll: true });
  save();
}

// ---------------------------------------------------------------- saving
async function save() {
  if (!dirty.size || submitting) return;
  const payload = {};
  for (const id of dirty) payload[id] = answers[id] ?? null;
  dirty.clear();
  saveStatus.textContent = t('quiz.saving');
  try {
    await api(`/attempts/${attemptId}/answers`, { method: 'PATCH', body: { answers: payload } });
    saveStatus.textContent = t('quiz.saved');
  } catch (err) {
    Object.keys(payload).forEach((id) => dirty.add(Number(id)));
    saveStatus.textContent = t('quiz.save_failed');
    if (err.code === 'time_up' || err.code === 'attempt_closed') submit(true);
  }
}
setInterval(save, CONFIG.QUIZ_AUTOSAVE_MS);

async function submit(auto = false) {
  if (submitting) return;
  if (!auto) {
    const unanswered = questions.filter((q) => !answers[q.id]).length;
    const message = unanswered ? t('quiz.confirm_unanswered', { n: unanswered }) : t('quiz.confirm_submit');
    if (!(await confirmDialog(message, { okLabel: t('quiz.submit') }))) return;
  }
  submitting = true;
  timer.stop();
  setLoading(submitBtn, true);
  try {
    await api(`/attempts/${attemptId}/submit`, { method: 'POST', body: { answers } });
  } catch (err) {
    if (err.code !== 'attempt_closed') toast(errorMessage(err), 'error');
  }
  storage.remove(flagKey);
  location.href = `/quiz-result?attempt=${attemptId}${auto ? '&timeup=1' : ''}`;
}

// ---------------------------------------------------------------- controls
const timer = createQuizTimer(document.getElementById('quiz-timer'), {
  expiresAt: attempt.expires_at,
  serverNow: attempt.server_now,
  onTimeUp: () => {
    toast(t('quiz.time_up'), 'error');
    submit(true);
  },
});

document.getElementById('prev-btn').addEventListener('click', () => go(index - 1));
document.getElementById('next-btn').addEventListener('click', () => {
  if (index === questions.length - 1) {
    const firstOpen = questions.findIndex((q) => !answers[q.id] || flagged.has(q.id));
    if (firstOpen >= 0 && firstOpen !== index) go(firstOpen);
    else submitBtn.focus();
  } else {
    go(index + 1);
  }
});
flagBtn.addEventListener('click', () => {
  const id = questions[index].id;
  if (flagged.has(id)) flagged.delete(id);
  else flagged.add(id);
  storage.set(flagKey, [...flagged]);
  renderQuestion();
});
submitBtn.addEventListener('click', () => submit(false));

document.addEventListener('keydown', (e) => {
  if (e.target.matches('input[type="text"], textarea') || e.ctrlKey || e.metaKey || e.altKey) return;
  if (document.querySelector('dialog[open]')) return;
  const q = questions[index];
  if (q.type === 'mcq' && /^[1-6]$/.test(e.key)) {
    const option = q.options[Number(e.key) - 1];
    if (option) {
      setAnswer(q, option.id);
      renderQuestion();
    }
  } else if (e.key === 'ArrowRight') go(index + 1);
  else if (e.key === 'ArrowLeft') go(index - 1);
});

window.addEventListener('beforeunload', (e) => {
  if (dirty.size && !submitting) {
    save();
    e.preventDefault();
  }
});
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden') save();
});

renderQuestion();
saveStatus.textContent = t('quiz.saved');
