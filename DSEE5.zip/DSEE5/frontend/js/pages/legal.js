// js/pages/legal.js - Terms and Privacy pages: show the version in the user's language.
import { initPage } from '../core/page.js';
import { currentLanguage } from '../core/i18n.js';

await initPage();
const lang = currentLanguage();
const blocks = [...document.querySelectorAll('[data-lang-block]')];
const match = blocks.some((b) => b.dataset.langBlock === lang) ? lang : 'en';
blocks.forEach((block) => { block.hidden = block.dataset.langBlock !== match; });
