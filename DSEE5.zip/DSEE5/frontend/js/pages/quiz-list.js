// js/pages/quiz-list.js - choose a quiz, test or mock exam, and see past attempts.
import { api } from '../core/api.js';
import { initPage } from '../core/page.js';
import { t } from '../core/i18n.js';
import {
  el, emptyState, errorMessage, fill, icon, openModal, setLoading, skeletons, toast,
} from '../core/ui.js';
import { formatDateTime, getSubjects, setQueryParams, subjectName, subjectOptions } from '../core/utils.js';

await initPage({ requireLogin: true });
const form = document.getElementById('quiz-filters');
const list = document.getElementById('quiz-list');
const params = new URLSearchParams(location.search);

fill(form.subject, ...subjectOptions(await getSubjects(), params.get('subject') || '', { includeAll: true }));
form.level.value = params.get('level') || '';
form.kind.value = params.get('kind') || '';

function confirmStart(a) {
  return new Promise((resolve) => {
    const body = el('form', { method: 'dialog', class: 'modal-body' },
      el('h2', {}, a.title),
      el('ul', { class: 'start-facts', role: 'list' },
        el('li', {}, icon('clock'), t('quiz.minutes', { n: a.time_limit_min })),
        el('li', {}, icon('note'), t('quiz.questions', { n: a.question_count })),
        el('li', {}, '★', ` ${t('quiz.points_range', { min: a.points_base, max: a.points_base + a.points_bonus_max })}`)),
      el('p', { class: 'notice notice-warn' }, t('quiz.start_warning')),
      el('div', { class: 'form-actions' },
        el('button', { class: 'btn btn-primary', value: 'ok' }, t('quiz.start_now')),
        el('button', { class: 'btn', value: 'cancel' }, t('common.cancel'))));
    openModal(body, { onClose: (v) => resolve(v === 'ok') });
  });
}

async function start(a, button) {
  if (!(await confirmStart(a))) return;
  setLoading(button, true);
  try {
    const { attempt } = await api(`/quizzes/${a.id}/start`, { method: 'POST' });
    location.href = `/quiz-take?attempt=${attempt.id}`;
  } catch (err) {
    if (err.code === 'attempt_in_progress') {
      toast(t('errors.attempt_in_progress'), 'error');
      location.href = `/quiz-take?attempt=${err.data.attempt_id}`;
      return;
    }
    toast(errorMessage(err), 'error');
    setLoading(button, false);
  }
}

function card(a) {
  const button = el('button', { class: 'btn btn-primary', type: 'button' }, t('quiz.start'));
  button.addEventListener('click', () => start(a, button));
  return el('article', { class: `quiz-card kind-${a.kind}` },
    el('div', { class: 'cluster' },
      el('span', { class: 'badge quiz-kind' }, t(`quiz.kinds.${a.kind}`)),
      el('span', { class: 'badge' }, t(`quiz.levels_short.${a.level}`))),
    el('h2', { class: 'quiz-title' }, a.title),
    el('p', { class: 'text-sm text-muted' }, subjectName(a.subject)),
    el('dl', { class: 'quiz-facts' },
      el('div', {}, el('dt', {}, t('quiz.questions_label')), el('dd', { class: 'num' }, String(a.question_count))),
      el('div', {}, el('dt', {}, t('quiz.time_label')), el('dd', { class: 'num' }, t('quiz.min', { n: a.time_limit_min }))),
      el('div', {}, el('dt', {}, t('quiz.points_label')), el('dd', { class: 'num' }, `+${a.points_base}–${a.points_base + a.points_bonus_max}`)),
      el('div', {}, el('dt', {}, t('quiz.best')), el('dd', { class: 'num' }, a.best_percent == null ? '-' : `${a.best_percent}%`))),
    button);
}

async function load() {
  const query = { subject: form.subject.value, level: form.level.value, kind: form.kind.value };
  setQueryParams(query);
  fill(list, ...skeletons(3));
  try {
    const { items, current_attempt: current } = await api(`/quizzes?${new URLSearchParams(Object.entries(query).filter(([, v]) => v))}`);
    const banner = document.getElementById('current-attempt');
    banner.hidden = !current;
    if (current) {
      fill(banner, el('span', {}, t('quiz.in_progress', { title: current.title })),
        el('a', { class: 'btn btn-sm btn-primary', href: `/quiz-take?attempt=${current.id}` }, t('dashboard.continue')));
    }
    fill(list, ...(items.length ? items.map(card)
      : [emptyState({ title: t('quiz.none'), text: t('quiz.none_text') })]));
  } catch (err) {
    fill(list, emptyState({ title: errorMessage(err) }));
  }
}

async function loadHistory() {
  const box = document.getElementById('history-list');
  const { items } = await api('/attempts/history');
  if (!items.length) {
    fill(box, el('p', { class: 'text-muted' }, t('quiz.no_history')));
    return;
  }
  fill(box, el('div', { class: 'table-wrap' }, el('table', {},
    el('thead', {}, el('tr', {},
      [t('quiz.col_title'), t('common.subject'), t('quiz.col_date'), t('quiz.col_score'), t('quiz.col_points')]
        .map((h) => el('th', { scope: 'col' }, h)))),
    el('tbody', {}, items.map((a) => el('tr', {},
      el('td', {}, el('a', { href: `/quiz-result?attempt=${a.id}` }, a.title)),
      el('td', {}, subjectName(a.subject)),
      el('td', {}, formatDateTime(a.submitted_at)),
      el('td', { class: 'num' }, `${a.raw_score} / ${a.max_score} (${a.percent}%)`),
      el('td', { class: 'num' }, `+${a.points_awarded}`)))))));
}

form.addEventListener('change', load);
form.addEventListener('submit', (e) => e.preventDefault());
load();
loadHistory().catch(() => {});
