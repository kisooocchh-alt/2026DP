// js/core/auth.js - knows who is logged in.
import { api, resetCsrfToken } from './api.js';

let userPromise = null;
let currentUser = null;

/** The logged-in user (cached for this page), or null when logged out. */
export function getCurrentUser() {
  if (!userPromise) {
    userPromise = api('/auth/me', { redirectOn401: false })
      .then((data) => {
        currentUser = data.user;
        return currentUser;
      })
      .catch(() => null);
  }
  return userPromise;
}

export function setCurrentUser(user) {
  currentUser = user;
  userPromise = Promise.resolve(user);
  if (user) updateCachedScore(user.score);
}

/** Tell every score badge on the page about a new balance. */
export function updateCachedScore(score) {
  if (typeof score !== 'number') return;
  if (currentUser) currentUser.score = score;
  document.dispatchEvent(new CustomEvent('dsee5:score', { detail: { score } }));
}

export async function logout() {
  try {
    await api('/auth/logout', { method: 'POST', redirectOn401: false });
  } finally {
    resetCsrfToken();
    // Remove offline copies so the next person on a shared computer cannot see them.
    if ('caches' in window) await caches.delete('dsee5-materials').catch(() => {});
    location.href = '/';
  }
}
