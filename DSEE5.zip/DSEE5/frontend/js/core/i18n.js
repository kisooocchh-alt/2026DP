// js/core/i18n.js - English / Traditional Chinese (Hong Kong) switching.
import { storage } from './storage.js';

const SUPPORTED = ['en', 'zh-HK'];
let dict = {};
let fallback = {};
let lang = 'en';

export const currentLanguage = () => lang;

function detect() {
  const saved = storage.get('lang');
  if (SUPPORTED.includes(saved)) return saved;
  return (navigator.language || '').toLowerCase().startsWith('zh') ? 'zh-HK' : 'en';
}

async function loadFile(code) {
  const res = await fetch(`/locales/${code}.json`, { credentials: 'same-origin' });
  if (!res.ok) throw new Error(`Missing locale ${code}`);
  return res.json();
}

export async function loadLanguage() {
  lang = detect();
  try {
    dict = await loadFile(lang);
    fallback = lang === 'en' ? dict : await loadFile('en');
  } catch {
    lang = 'en';
    dict = fallback = await loadFile('en').catch(() => ({}));
  }
  document.documentElement.lang = lang;
}

function lookup(source, key) {
  return key.split('.').reduce((obj, part) => (obj == null ? undefined : obj[part]), source);
}

/**
 * t('chat.cost', { cost: 2 }) -> "Costs 2 points". Missing keys fall back to English.
 * Singular: when vars.n is 1 and the current language has "<key>_one", that text is used
 * ("1 point" instead of "1 points"). Chinese has no plural forms, so it needs no _one keys.
 */
export function t(key, vars = {}) {
  let value = vars.n === 1 ? lookup(dict, `${key}_one`) : undefined;
  if (typeof value !== 'string') value = lookup(dict, key);
  if (typeof value !== 'string') value = lookup(fallback, key);
  const text = typeof value === 'string' ? value : key;
  return text.replace(/\{(\w+)\}/g, (_, name) => String(vars[name] ?? `{${name}}`));
}

/** True if a translation exists (used for optional error messages). */
export function has(key) {
  return typeof lookup(dict, key) === 'string' || typeof lookup(fallback, key) === 'string';
}

/** Fill every element that has data-i18n, data-i18n-placeholder, -aria or -title. */
export function applyTranslations(root = document) {
  root.querySelectorAll('[data-i18n]').forEach((node) => {
    node.textContent = t(node.dataset.i18n);
  });
  root.querySelectorAll('[data-i18n-placeholder]').forEach((node) => {
    node.placeholder = t(node.dataset.i18nPlaceholder);
  });
  root.querySelectorAll('[data-i18n-aria]').forEach((node) => {
    node.setAttribute('aria-label', t(node.dataset.i18nAria));
  });
  root.querySelectorAll('[data-i18n-title]').forEach((node) => {
    node.title = t(node.dataset.i18nTitle);
  });
}

export function setLanguage(newLang) {
  if (!SUPPORTED.includes(newLang)) return;
  storage.set('lang', newLang);
  location.reload();
}
