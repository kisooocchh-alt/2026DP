// js/core/utils.js - small helpers: dates in Hong Kong time, money, subjects, URLs.
import { api } from './api.js';
import { CONFIG } from './config.js';
import { currentLanguage, t } from './i18n.js';

const locale = () => (currentLanguage() === 'zh-HK' ? 'zh-HK' : 'en-GB');

export function formatDateTime(iso) {
  if (!iso) return '';
  return new Intl.DateTimeFormat(locale(), {
    timeZone: CONFIG.TIME_ZONE, day: 'numeric', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit',
  }).format(new Date(iso));
}

export function formatDate(iso, options = {}) {
  if (!iso) return '';
  return new Intl.DateTimeFormat(locale(), {
    timeZone: CONFIG.TIME_ZONE, day: 'numeric', month: 'short', year: 'numeric', ...options,
  }).format(new Date(iso));
}

export function formatTime(iso) {
  if (!iso) return '';
  return new Intl.DateTimeFormat(locale(), {
    timeZone: CONFIG.TIME_ZONE, hour: '2-digit', minute: '2-digit',
  }).format(new Date(iso));
}

/** "3 minutes ago", "yesterday" ... in the current language. */
export function formatRelative(iso) {
  if (!iso) return '';
  const seconds = Math.round((new Date(iso).getTime() - Date.now()) / 1000);
  const rtf = new Intl.RelativeTimeFormat(locale(), { numeric: 'auto' });
  const units = [['year', 31536000], ['month', 2592000], ['week', 604800], ['day', 86400],
    ['hour', 3600], ['minute', 60]];
  for (const [unit, size] of units) {
    if (Math.abs(seconds) >= size) return rtf.format(Math.round(seconds / size), unit);
  }
  return t('common.just_now');
}

/** "Mathematics, 2 hours ago" in English, "數學・2 小時前" in Chinese. Empty parts are skipped. */
export function joinParts(...parts) {
  return parts.filter((p) => p !== null && p !== undefined && p !== '').join(t('common.separator'));
}

export function formatHKD(amount) {
  if (amount == null) return '';
  return `HK$${Number(amount).toLocaleString('en-HK')}`;
}

export function formatBytes(bytes) {
  if (!bytes) return '';
  const units = ['B', 'KB', 'MB', 'GB'];
  let size = bytes;
  let i = 0;
  while (size >= 1024 && i < units.length - 1) {
    size /= 1024;
    i += 1;
  }
  return `${size.toFixed(i ? 1 : 0)} ${units[i]}`;
}

export function debounce(fn, ms = 300) {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), ms);
  };
}

export function getQueryParam(name) {
  return new URLSearchParams(location.search).get(name);
}

/** Update the address bar (so a search can be shared) without reloading. */
export function setQueryParams(params) {
  const url = new URL(location.href);
  for (const [key, value] of Object.entries(params)) {
    if (value === '' || value == null || value === false) url.searchParams.delete(key);
    else url.searchParams.set(key, value);
  }
  history.replaceState(null, '', url);
}

/** Only accept same-site paths for ?next=, so login cannot redirect to another site. */
export function safeNextPath(value) {
  if (typeof value !== 'string' || !value.startsWith('/') || value.startsWith('//')) return null;
  if (value.startsWith('/\\') || value.includes('://')) return null;
  return value;
}

// ---------------------------------------------------------------- subjects
let subjectsPromise = null;

export function getSubjects() {
  if (!subjectsPromise) {
    subjectsPromise = api('/subjects', { redirectOn401: false })
      .then((data) => data.subjects)
      .catch(() => []);
  }
  return subjectsPromise;
}

let subjectMap = new Map();

export async function loadSubjectNames() {
  const list = await getSubjects();
  subjectMap = new Map(list.map((s) => [s.code, s]));
  return list;
}

export function subjectName(code) {
  const s = subjectMap.get(code);
  if (!s) return code || '';
  return currentLanguage() === 'zh-HK' ? s.name_zh : s.name_en;
}

/** <option> elements for a subject <select>. */
export function subjectOptions(list, selected = '', { includeAll = false } = {}) {
  const options = [];
  if (includeAll) {
    const all = document.createElement('option');
    all.value = '';
    all.textContent = t('common.all_subjects');
    options.push(all);
  }
  for (const s of list) {
    const option = document.createElement('option');
    option.value = s.code;
    option.textContent = currentLanguage() === 'zh-HK' ? s.name_zh : s.name_en;
    option.selected = s.code === selected;
    options.push(option);
  }
  return options;
}
