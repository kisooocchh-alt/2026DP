// js/core/validators.js - instant feedback before sending a form.
// Each check returns null (fine) or an error code; the server checks everything again.
import { CONFIG } from './config.js';

export function validateUsername(value) {
  return CONFIG.USERNAME_PATTERN.test(value || '') ? null : 'username_invalid';
}

/** { score: 0-4, code: error code or null } */
export function passwordStrength(password, username = '') {
  const pw = password || '';
  if (pw.length < CONFIG.PASSWORD_MIN) return { score: pw ? 1 : 0, code: 'password_too_short' };
  if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return { score: 1, code: 'password_needs_letter_and_number' };
  if (username && username.length >= 3 && pw.toLowerCase().includes(username.toLowerCase())) {
    return { score: 1, code: 'password_too_common' };
  }
  let score = 2;
  if (pw.length >= 14) score += 1;
  if (/[^A-Za-z0-9]/.test(pw) && /[a-z]/.test(pw) && /[A-Z]/.test(pw)) score += 1;
  return { score: Math.min(score, 4), code: null };
}

export function validateBirthYear(value) {
  const year = Number(value);
  const now = new Date().getFullYear();
  return Number.isInteger(year) && year >= now - 90 && year <= now - 10 ? null : 'birth_year_invalid';
}

export function ageFromBirthYear(value) {
  const year = Number(value);
  return Number.isInteger(year) && year > 1900 ? new Date().getFullYear() - year : null;
}

export function validateWage(value) {
  if (value === '' || value == null) return null;
  const n = Number(value);
  return Number.isInteger(n) && n >= CONFIG.MIN_WAGE && n <= CONFIG.MAX_WAGE ? null : 'wage_invalid';
}

export function validateImageFile(file) {
  if (!file) return 'file_missing';
  if (!CONFIG.IMAGE_TYPES.includes(file.type)) return 'bad_file_type';
  if (file.size > CONFIG.MAX_IMAGE_MB * 1024 * 1024) return 'file_too_large';
  return null;
}

export function validateEmail(value) {
  if (!value) return null;
  return /^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$/.test(value) ? null : 'email_invalid';
}
