// js/core/api.js - the ONLY file that calls fetch() for the API.
// Adds the CSRF token, sends JSON or uploads, and turns errors into ApiError.

let csrfToken = null;

// Used when the answer is not JSON (for example nginx refusing a request before the app).
const STATUS_CODES = {
  401: 'login_required',
  403: 'forbidden',
  404: 'not_found',
  413: 'file_too_large',
  429: 'too_many_requests',
};

export class ApiError extends Error {
  constructor(status, data) {
    const code = data.error || STATUS_CODES[status] || 'server_error';
    super(code);
    this.status = status;
    this.code = code;
    this.fields = data.fields || {};
    this.data = data;
  }
}

async function getCsrfToken(force = false) {
  if (!csrfToken || force) {
    const res = await fetch('/api/auth/csrf', { credentials: 'same-origin' });
    csrfToken = (await res.json()).csrf_token;
  }
  return csrfToken;
}

/** Forget the cached token (after login/logout the server starts a new one). */
export function resetCsrfToken() {
  csrfToken = null;
}

/**
 * api('/papers?subject=MATH')
 * api('/score/daily', { method: 'POST' })
 * api('/chat/images', { method: 'POST', form: formData })
 */
export async function api(path, { method = 'GET', body, form, redirectOn401 = true, retry = true } = {}) {
  const headers = { Accept: 'application/json' };
  if (method !== 'GET') headers['X-CSRFToken'] = await getCsrfToken();

  let payload;
  if (form) {
    payload = form; // the browser sets the multipart Content-Type
  } else if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
    payload = JSON.stringify(body);
  }

  let res;
  try {
    res = await fetch(`/api${path}`, { method, headers, body: payload, credentials: 'same-origin' });
  } catch {
    throw new ApiError(0, { error: 'network_error' });
  }
  const data = await res.json().catch(() => ({}));

  if (res.status === 400 && data.error === 'csrf_failed' && retry) {
    await getCsrfToken(true); // the session changed: fetch a new token once and retry
    return api(path, { method, body, form, redirectOn401, retry: false });
  }
  if (res.status === 401 && redirectOn401) {
    const next = encodeURIComponent(location.pathname + location.search);
    location.href = `/login?next=${next}`;
  }
  if (!res.ok || data.ok === false) throw new ApiError(res.status, data);
  return data;
}
