// js/core/socket.js - connects to the real-time chat (Socket.IO, namespace /chat).
// Needs <script src="/js/vendor/socket.io.min.js"></script> before the page script.

export function connectChat() {
  if (typeof io !== 'function') throw new Error('Socket.IO client not loaded');
  return io('/chat', {
    withCredentials: true,
    transports: ['websocket', 'polling'],
    reconnectionDelayMax: 10_000,
  });
}

/** Emit an event and wait for the server's reply (with a timeout). */
export function emitWithAck(socket, event, data, timeoutMs = 10_000) {
  return new Promise((resolve, reject) => {
    socket.timeout(timeoutMs).emit(event, data, (err, reply) => {
      if (err) reject(new Error('timeout'));
      else resolve(reply);
    });
  });
}
