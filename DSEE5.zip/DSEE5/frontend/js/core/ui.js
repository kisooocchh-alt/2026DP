// js/core/ui.js - safe ways to build and update the page.
// User-provided text is ALWAYS inserted as text, never as HTML (XSS protection).
import { has, t } from './i18n.js';

/** el('p', { class: 'msg-text' }, message.text) */
export function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs || {})) {
    if (value == null || value === false) continue;
    if (key === 'class') node.className = value;
    else if (key === 'dataset') Object.assign(node.dataset, value);
    else if (key === 'text') node.textContent = value;
    else if (/^on[a-z]/i.test(key)) {
      // Only real functions: an onclick="..." string would be inline code (blocked by CSP).
      if (typeof value !== 'function') throw new Error(`${key} must be a function`);
      node.addEventListener(key.slice(2).toLowerCase(), value);
    } else if (key === 'href' || key === 'src') node.setAttribute(key, safeUrl(value));
    else if (key === 'style') throw new Error('Use CSS classes, not style (CSP)');
    else node.setAttribute(key, value === true ? '' : value);
  }
  append(node, children);
  return node;
}

/**
 * Replace every child of node. Unlike node.replaceChildren(), null, undefined and false
 * are skipped, so `cond && el(...)` can be passed safely (replaceChildren would print "null").
 */
export function fill(node, ...children) {
  node.replaceChildren();
  append(node, children);
  return node;
}

function append(node, children) {
  for (const child of children.flat(Infinity)) {
    if (child == null || child === false) continue;
    node.append(child instanceof Node ? child : String(child));
  }
}

/** Only allow https:// links, same-site paths, data:image and blob: (for previews). */
export function safeUrl(url) {
  if (typeof url !== 'string') return '#';
  if (url.startsWith('/') && !url.startsWith('//')) return url;
  if (url.startsWith('https://') || url.startsWith('#') || url.startsWith('mailto:')) return url;
  if (url.startsWith('data:image/') || url.startsWith('blob:')) return url;
  return '#';
}

// ---------------------------------------------------------------- icons
const ICONS = {
  bell: ['M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9', 'M10.3 21a1.94 1.94 0 0 0 3.4 0'],
  menu: ['M4 6h16', 'M4 12h16', 'M4 18h16'],
  close: ['M18 6 6 18', 'M6 6l12 12'],
  search: ['M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14z', 'm21 21-4.3-4.3'],
  image: ['M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z',
    'M9 11a2 2 0 1 0 0-4 2 2 0 0 0 0 4z', 'm21 15-5-5L5 21'],
  send: ['M22 2 11 13', 'M22 2 15 22l-4-9-9-4 20-7z'],
  flag: ['M4 22V4', 'M4 4h13l-2.5 4L17 12H4'],
  bookmark: ['M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z'],
  download: ['M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4', 'm7 10 5 5 5-5', 'M12 15V3'],
  clock: ['M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z', 'M12 7v5l3 2'],
  pin: ['M12 17v5', 'M9 3h6l-1 6 4 4H6l4-4z'],
  user: ['M20 21a8 8 0 0 0-16 0', 'M12 13a5 5 0 1 0 0-10 5 5 0 0 0 0 10z'],
  settings: ['M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
    'M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z'],
  logout: ['M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4', 'm16 17 5-5-5-5', 'M21 12H9'],
  calendar: ['M5 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z',
    'M16 2v4', 'M8 2v4', 'M3 10h18'],
  check: ['M20 6 9 17l-5-5'],
  file: ['M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z', 'M14 2v6h6'],
  video: ['m22 8-6 4 6 4V8z', 'M2 6h14v12H2z'],
  note: ['M4 4h16v16H4z', 'M8 9h8', 'M8 13h8', 'M8 17h5'],
  external: ['M15 3h6v6', 'M10 14 21 3', 'M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6'],
  moon: ['M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z'],
  sun: ['M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z', 'M12 2v2', 'M12 20v2', 'm4.9 4.9 1.4 1.4',
    'm17.7 17.7 1.4 1.4', 'M2 12h2', 'M20 12h2', 'm6.3 17.7-1.4 1.4', 'm19.1 4.9-1.4 1.4'],
  chevron: ['m9 18 6-6-6-6'],
  arrowUp: ['m18 15-6-6-6 6'],
  trash: ['M3 6h18', 'M8 6V4h8v2', 'M19 6l-1 14H6L5 6'],
  offline: ['M12 20h.01', 'M8.5 16.4a5 5 0 0 1 7 0', 'M5 12.9a10 10 0 0 1 5.2-2.8',
    'M19 12.9a10 10 0 0 0-2.3-1.6', 'M2 8.8a15 15 0 0 1 4.2-2.7', 'M22 8.8A15 15 0 0 0 11 5',
    'M2 2l20 20'],
};

export function icon(name, extraClass = '') {
  const ns = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(ns, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('class', `icon ${extraClass}`.trim());
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');
  for (const d of ICONS[name] || []) {
    const path = document.createElementNS(ns, 'path');
    path.setAttribute('d', d);
    svg.append(path);
  }
  return svg;
}

// ---------------------------------------------------------------- feedback
export function toast(message, type = 'info', ms = 3500) {
  const root = document.getElementById('toast-root');
  if (!root) return;
  const node = el('div', { class: `toast toast-${type}`, role: type === 'error' ? 'alert' : 'status' },
    message);
  root.append(node);
  setTimeout(() => node.remove(), type === 'error' ? Math.max(ms, 6000) : ms);
}

/** A readable, translated message for any error thrown by api(). */
export function errorMessage(err) {
  const code = err?.code || err?.message || 'server_error';
  return has(`errors.${code}`) ? t(`errors.${code}`) : t('errors.server_error');
}

export function setLoading(button, loading) {
  if (!button) return;
  button.disabled = loading;
  button.classList.toggle('is-loading', loading);
  button.setAttribute('aria-busy', loading ? 'true' : 'false');
}

export function clearFieldErrors(form) {
  form.querySelectorAll('.field-error[data-generated]').forEach((n) => n.remove());
  form.querySelectorAll('[aria-invalid="true"]').forEach((n) => n.removeAttribute('aria-invalid'));
}

/** Show server validation errors next to the right inputs. Returns how many were placed. */
export function showFieldErrors(form, fields = {}, aliases = {}) {
  clearFieldErrors(form);
  let placed = 0;
  for (const [name, code] of Object.entries(fields)) {
    const input = form.querySelector(`[name="${CSS.escape(aliases[name] || name)}"]`);
    if (!input) continue;
    input.setAttribute('aria-invalid', 'true');
    const message = el('p', { class: 'field-error', dataset: { generated: '1' }, id: `err-${name}` },
      has(`errors.${code}`) ? t(`errors.${code}`) : code);
    input.setAttribute('aria-describedby', `err-${name}`);
    (input.closest('.field') || input.parentElement).append(message);
    if (placed === 0) input.focus({ preventScroll: false });
    placed += 1;
  }
  return placed;
}

/** Put an error message in a form's [data-form-error] box. */
export function showFormError(form, message) {
  const box = form.querySelector('[data-form-error]');
  if (!box) return toast(message, 'error');
  box.textContent = message;
  box.hidden = !message;
  return undefined;
}

// ---------------------------------------------------------------- dialogs
export function openModal(content, { wide = false, image = false, onClose } = {}) {
  const dialog = el('dialog', { class: `modal ${wide ? 'modal-wide' : ''} ${image ? 'modal-image' : ''}` });
  dialog.append(content);
  dialog.addEventListener('close', () => {
    dialog.remove();
    if (onClose) onClose(dialog.returnValue);
  });
  dialog.addEventListener('click', (e) => {
    if (e.target === dialog) dialog.close('cancel');
  });
  document.body.append(dialog);
  dialog.showModal();
  return dialog;
}

/** await confirmDialog('Delete?') -> true / false */
export function confirmDialog(message, { okLabel, cancelLabel, danger = false } = {}) {
  return new Promise((resolve) => {
    const form = el('form', { method: 'dialog', class: 'modal-body' },
      el('p', {}, message),
      el('div', { class: 'form-actions' },
        el('button', { class: `btn ${danger ? 'btn-danger' : 'btn-primary'}`, value: 'ok' },
          okLabel || t('common.confirm')),
        el('button', { class: 'btn', value: 'cancel' }, cancelLabel || t('common.cancel'))));
    openModal(form, { onClose: (value) => resolve(value === 'ok') });
  });
}

export function emptyState({ title, text, actionLabel, actionHref }) {
  return el('div', { class: 'empty-state' },
    title && el('h3', {}, title),
    text && el('p', {}, text),
    actionLabel && el('a', { class: 'btn btn-primary', href: actionHref }, actionLabel));
}

export function skeletons(count = 3) {
  return Array.from({ length: count }, () => el('div', { class: 'skeleton', 'aria-hidden': 'true' }));
}

// ---------------------------------------------------------------- small views
export function avatarImg(user, size = '') {
  return el('img', {
    class: `avatar ${size ? `avatar-${size}` : ''}`,
    src: user?.avatar_url || '/assets/images/default-avatar.svg',
    alt: '',
    loading: 'lazy',
    width: size === 'lg' ? 96 : size === 'xl' ? 128 : size === 'sm' ? 32 : 40,
    height: size === 'lg' ? 96 : size === 'xl' ? 128 : size === 'sm' ? 32 : 40,
  });
}

export function userBadges(user) {
  const out = [];
  if (user?.role === 'tutor') out.push(el('span', { class: 'badge badge-tutor' }, t('roles.tutor')));
  if (user?.verified) {
    out.push(el('span', { class: 'badge badge-verified', title: t('tutors.verified_hint') },
      icon('check'), t('tutors.verified')));
  }
  return out;
}

export function gradeStamp(result, subjectLabel) {
  return el('span', { class: 'grade' }, el('b', {}, result.grade), subjectLabel);
}

export function starRating(value, outOf = 5) {
  const rounded = Math.round(value);
  return el('span', { class: 'stars', 'aria-label': t('tutors.stars_label', { n: value.toFixed(1) }) },
    Array.from({ length: outOf }, (_, i) => el('span', { class: i < rounded ? '' : 'off', 'aria-hidden': 'true' }, '★')));
}
