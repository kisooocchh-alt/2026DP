// js/core/page.js - every page script starts with:  const user = await initPage({...});
// Loads the language, checks the login, draws the header and footer, registers the
// service worker (offline support and push notifications).
import { getCurrentUser } from './auth.js';
import { applyTranslations, loadLanguage } from './i18n.js';
import { storage } from './storage.js';
import { loadSubjectNames } from './utils.js';
import { mountFooter } from '../components/footer.js';
import { mountNavbar } from '../components/navbar.js';

function applyTheme() {
  const theme = storage.get('theme');
  if (theme === 'light' || theme === 'dark') document.documentElement.dataset.theme = theme;
}

/**
 * @param {{ requireLogin?: boolean, roles?: string[], guestOnly?: boolean }} options
 * @returns {Promise<object|null>} the logged-in user, or null
 */
export async function initPage({ requireLogin = false, roles = [], guestOnly = false } = {}) {
  applyTheme();
  const [, user] = await Promise.all([loadLanguage(), getCurrentUser()]);

  if (requireLogin && !user) {
    location.href = `/login?next=${encodeURIComponent(location.pathname + location.search)}`;
    return new Promise(() => {}); // stop the page script here
  }
  if (roles.length && (!user || !roles.includes(user.role))) {
    location.href = '/dashboard';
    return new Promise(() => {});
  }
  if (guestOnly && user) {
    location.href = '/dashboard';
    return new Promise(() => {});
  }

  await loadSubjectNames();
  mountNavbar(document.getElementById('site-header'), user);
  mountFooter(document.getElementById('site-footer'));
  applyTranslations(document);
  document.body.classList.add('is-ready');

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/service-worker.js').catch(() => {});
  }
  return user;
}
