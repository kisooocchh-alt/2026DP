// js/core/storage.js - a safe wrapper around localStorage (it can throw in private
// browsing). Only for harmless preferences: language, theme, last chat room.
// Never store passwords, tokens or personal data here.

const PREFIX = 'dsee5:';

export const storage = {
  get(key, fallback = null) {
    try {
      const value = window.localStorage.getItem(PREFIX + key);
      return value === null ? fallback : JSON.parse(value);
    } catch {
      return fallback;
    }
  },
  set(key, value) {
    try {
      window.localStorage.setItem(PREFIX + key, JSON.stringify(value));
    } catch {
      /* storage unavailable: the preference simply is not remembered */
    }
  },
  remove(key) {
    try {
      window.localStorage.removeItem(PREFIX + key);
    } catch {
      /* ignore */
    }
  },
};
