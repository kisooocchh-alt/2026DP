// js/components/navbar.js - the site header: wordmark, main links, language and theme
// switches, and either Log in / Sign up or the score, notifications and account menu.
import { api } from '../core/api.js';
import { logout } from '../core/auth.js';
import { CONFIG } from '../core/config.js';
import { currentLanguage, setLanguage, t } from '../core/i18n.js';
import { storage } from '../core/storage.js';
import { avatarImg, el, fill, icon } from '../core/ui.js';
import { mountScoreBadge } from './score-badge.js';

const LINKS = [
  ['/papers', 'nav.papers'],
  ['/materials', 'nav.materials'],
  ['/quizzes', 'nav.quiz'],
  ['/chat', 'nav.chat'],
  ['/tutors', 'nav.tutors'],
];

function isCurrent(href) {
  const path = location.pathname;
  if (href === '/quizzes') return path.startsWith('/quiz');
  if (href === '/tutors') return path === '/tutors' || path === '/tutor';
  if (href === '/materials') return path.startsWith('/material');
  return path === href;
}

function navList(extraClass) {
  return el('ul', { class: extraClass, role: 'list' },
    LINKS.map(([href, key]) => el('li', {},
      el('a', { href, 'aria-current': isCurrent(href) ? 'page' : null }, t(key)))));
}

function wordmark() {
  return el('a', { class: 'wordmark', href: '/', 'aria-label': 'DSEE5 home' },
    'DSEE', el('span', { class: 'wordmark-bubble', 'aria-hidden': 'true' }, '5'));
}

function themeButton() {
  const current = () => document.documentElement.dataset.theme ||
    (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  const button = el('button', { class: 'icon-btn theme-switch', type: 'button' });
  const render = () => {
    const dark = current() === 'dark';
    fill(button, icon(dark ? 'sun' : 'moon'));
    button.setAttribute('aria-label', t(dark ? 'nav.theme_light' : 'nav.theme_dark'));
    button.title = button.getAttribute('aria-label');
  };
  button.addEventListener('click', () => {
    const next = current() === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    storage.set('theme', next);
    render();
  });
  render();
  return button;
}

function languageButton(user) {
  const isZh = currentLanguage() === 'zh-HK';
  return el('button', {
    class: 'btn btn-ghost btn-sm lang-switch', type: 'button', lang: isZh ? 'en' : 'zh-HK',
    'aria-label': t('nav.switch_language'),
    onclick: async () => {
      const next = isZh ? 'en' : 'zh-HK';
      if (user) await api('/profile/language', { method: 'PUT', body: { language: next } }).catch(() => {});
      setLanguage(next);
    },
  }, isZh ? 'EN' : '中文');
}

function bellButton() {
  const count = el('span', { class: 'dot-count', hidden: true });
  const link = el('a', { class: 'icon-btn', href: '/notifications', 'aria-label': t('nav.notifications') },
    icon('bell'), count);
  const refresh = async () => {
    try {
      const { unread } = await api('/notifications/unread', { redirectOn401: false });
      count.textContent = unread > 99 ? '99+' : String(unread);
      count.hidden = unread === 0;
      link.setAttribute('aria-label', unread ? t('nav.notifications_unread', { n: unread }) : t('nav.notifications'));
    } catch {
      /* offline: keep the last value */
    }
  };
  refresh();
  setInterval(() => !document.hidden && refresh(), CONFIG.UNREAD_POLL_MS);
  document.addEventListener('dsee5:notifications', refresh);
  return link;
}

function accountMenu(user) {
  const panel = el('div', { class: 'menu-panel', id: 'account-menu', hidden: true },
    el('p', { class: 'menu-head' }, user.display_name, ' (@', user.username, ')'),
    el('a', { href: '/dashboard' }, icon('calendar'), t('nav.dashboard')),
    el('a', { href: `/profile?u=${encodeURIComponent(user.username)}` }, icon('user'), t('nav.profile')),
    el('a', { href: '/bookings' }, icon('clock'), t('nav.bookings')),
    el('a', { href: '/settings' }, icon('settings'), t('nav.settings')),
    el('hr'),
    el('button', { type: 'button', onclick: () => logout() }, icon('logout'), t('nav.logout')));
  const toggle = el('button', {
    class: 'icon-btn', type: 'button', 'aria-haspopup': 'true', 'aria-expanded': 'false',
    'aria-controls': 'account-menu', 'aria-label': t('nav.account_menu'),
  }, avatarImg(user, 'sm'));
  const close = () => {
    panel.hidden = true;
    toggle.setAttribute('aria-expanded', 'false');
  };
  toggle.addEventListener('click', (e) => {
    e.stopPropagation();
    panel.hidden = !panel.hidden;
    toggle.setAttribute('aria-expanded', String(!panel.hidden));
  });
  document.addEventListener('click', (e) => {
    if (!panel.hidden && !panel.contains(e.target)) close();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !panel.hidden) {
      close();
      toggle.focus();
    }
  });
  return el('div', { class: 'menu' }, toggle, panel);
}

export function mountNavbar(container, user) {
  if (!container) return;
  // On phones the language and theme switches move from the header into this menu.
  const mobileNav = el('nav', { class: 'mobile-nav container', id: 'mobile-nav', hidden: true,
    'aria-label': t('nav.main') }, navList(''),
  el('div', { class: 'mobile-tools' }, languageButton(user), themeButton()));
  const toggle = el('button', {
    class: 'icon-btn nav-toggle', type: 'button', 'aria-expanded': 'false',
    'aria-controls': 'mobile-nav', 'aria-label': t('nav.open_menu'),
  }, icon('menu'));
  toggle.addEventListener('click', () => {
    mobileNav.hidden = !mobileNav.hidden;
    toggle.setAttribute('aria-expanded', String(!mobileNav.hidden));
    fill(toggle, icon(mobileNav.hidden ? 'menu' : 'close'));
  });

  const tools = el('div', { class: 'header-tools' }, languageButton(user), themeButton());
  if (user) {
    const score = el('a', { class: 'score-pill', href: '/dashboard' });
    mountScoreBadge(score, user.score);
    tools.append(score, bellButton(), accountMenu(user));
  } else {
    tools.append(
      el('a', { class: 'btn btn-ghost btn-sm', href: '/login' }, t('nav.login')),
      el('a', { class: 'btn btn-primary btn-sm', href: '/register' }, t('nav.register')));
  }
  tools.append(toggle);

  fill(container,
    el('div', { class: 'container header-inner' },
      wordmark(),
      el('nav', { class: 'main-nav', 'aria-label': t('nav.main') }, navList('')),
      tools),
    mobileNav);
}
