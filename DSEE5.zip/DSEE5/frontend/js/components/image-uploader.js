// js/components/image-uploader.js - choose (or drop) an image, check it, preview it,
// shrink big phone photos in the browser, then upload. The server re-encodes it again.
import { api } from '../core/api.js';
import { validateImageFile } from '../core/validators.js';

async function shrink(file, maxSide) {
  if (!maxSide || typeof createImageBitmap !== 'function') return file;
  try {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
    if (scale === 1 && file.size < 1.5 * 1024 * 1024) return file;
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(bitmap.width * scale);
    canvas.height = Math.round(bitmap.height * scale);
    canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.88));
    return blob ? new File([blob], 'image.jpg', { type: 'image/jpeg' }) : file;
  } catch {
    return file;
  }
}

/**
 * createImageUploader({ input, preview, dropZone, maxSide, onChange })
 * returns { file(), clear(), upload(path, field) }
 */
export function createImageUploader({ input, preview, dropZone, maxSide = 1600, onChange, onError }) {
  let chosen = null;
  let objectUrl = null;

  function clear() {
    chosen = null;
    if (objectUrl) URL.revokeObjectURL(objectUrl);
    objectUrl = null;
    if (input) input.value = '';
    if (preview) {
      preview.hidden = true;
      preview.removeAttribute('src');
    }
    onChange?.(null);
  }

  async function choose(file) {
    const problem = validateImageFile(file);
    if (problem) {
      clear();
      onError?.(problem);
      return;
    }
    chosen = await shrink(file, maxSide);
    if (objectUrl) URL.revokeObjectURL(objectUrl);
    objectUrl = URL.createObjectURL(chosen);
    if (preview) {
      preview.src = objectUrl;
      preview.hidden = false;
    }
    onChange?.(chosen);
  }

  input?.addEventListener('change', () => input.files[0] && choose(input.files[0]));
  if (dropZone) {
    dropZone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropZone.classList.add('is-dragging');
    });
    dropZone.addEventListener('dragleave', () => dropZone.classList.remove('is-dragging'));
    dropZone.addEventListener('drop', (e) => {
      e.preventDefault();
      dropZone.classList.remove('is-dragging');
      const file = e.dataTransfer?.files?.[0];
      if (file) choose(file);
    });
  }

  return {
    file: () => chosen,
    clear,
    choose,
    async upload(path, field = 'image') {
      if (!chosen) throw new Error('file_missing');
      const form = new FormData();
      form.append(field, chosen, chosen.name || 'image.jpg');
      return api(path, { method: 'POST', form });
    },
  };
}
