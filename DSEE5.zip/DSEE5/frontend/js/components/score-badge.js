// js/components/score-badge.js - shows the user's points and updates them live.
import { t } from '../core/i18n.js';

export function mountScoreBadge(element, score) {
  if (!element) return;
  let current = score ?? 0;
  const render = () => {
    element.textContent = `★ ${current}`;
    element.setAttribute('aria-label', t('score.points', { n: current }));
    element.title = t('score.points', { n: current });
  };
  render();
  document.addEventListener('dsee5:score', (e) => {
    const next = e.detail?.score;
    if (typeof next !== 'number' || next === current) return;
    current = next;
    render();
    element.classList.remove('is-bumped');
    void element.offsetWidth; // restart the animation
    element.classList.add('is-bumped');
  });
}
