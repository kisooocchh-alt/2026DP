// js/components/quiz-timer.js - the countdown inside a quiz.
// It counts down to the SERVER's deadline. If this computer's clock is wrong, the
// difference between the server time and local time is corrected.
import { t } from '../core/i18n.js';
import { toast } from '../core/ui.js';

const pad = (n) => String(n).padStart(2, '0');

export function createQuizTimer(element, { expiresAt, serverNow, onTimeUp }) {
  const offset = serverNow ? new Date(serverNow).getTime() - Date.now() : 0;
  const deadline = new Date(expiresAt).getTime();
  const warned = new Set();
  let finished = false;

  const remaining = () => Math.max(0, deadline - (Date.now() + offset));

  function render() {
    const ms = remaining();
    const total = Math.ceil(ms / 1000);
    const h = Math.floor(total / 3600);
    const m = Math.floor(total / 60) % 60;
    const s = total % 60;
    element.textContent = h ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
    element.dataset.state = ms <= 60_000 ? 'critical' : ms <= 300_000 ? 'warning' : 'ok';
    element.setAttribute('aria-label', t('quiz.time_left', { time: element.textContent }));
    for (const [limit, key] of [[300_000, 'quiz.five_minutes'], [60_000, 'quiz.one_minute']]) {
      if (ms <= limit && ms > 0 && !warned.has(limit)) {
        warned.add(limit);
        toast(t(key), 'error');
      }
    }
    if (ms <= 0 && !finished) {
      finished = true;
      clearInterval(timer);
      onTimeUp?.();
    }
  }

  const timer = setInterval(render, 500);
  render();
  return {
    remaining,
    stop: () => {
      finished = true;
      clearInterval(timer);
    },
  };
}
