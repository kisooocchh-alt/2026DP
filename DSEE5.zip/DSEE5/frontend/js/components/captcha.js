// js/components/captcha.js - Cloudflare Turnstile anti-robot check.
// const captcha = await renderCaptcha(container); ... captcha.getToken(); captcha.reset();
import { api } from '../core/api.js';
import { currentLanguage } from '../core/i18n.js';

const SCRIPT = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
let scriptPromise = null;
let keyPromise = null;

function loadScript() {
  if (!scriptPromise) {
    scriptPromise = new Promise((resolve, reject) => {
      if (window.turnstile) return resolve();
      const s = document.createElement('script');
      s.src = SCRIPT;
      s.async = true;
      s.onload = () => resolve();
      s.onerror = () => reject(new Error('captcha_unavailable'));
      document.head.append(s);
      return undefined;
    });
  }
  return scriptPromise;
}

export function captchaConfig() {
  if (!keyPromise) {
    keyPromise = api('/auth/captcha-key', { redirectOn401: false })
      .catch(() => ({ enabled: false, site_key: '' }));
  }
  return keyPromise;
}

/** Draw the widget. Returns { enabled, getToken(), reset() }. */
export async function renderCaptcha(container) {
  const config = await captchaConfig();
  if (!config.enabled || !container) {
    return { enabled: false, getToken: () => '', reset: () => {} };
  }
  container.hidden = false;
  let token = '';
  let widgetId = null;
  try {
    await loadScript();
    widgetId = turnstile.render(container, {
      sitekey: config.site_key,
      language: currentLanguage() === 'zh-HK' ? 'zh-tw' : 'en',
      callback: (value) => { token = value; },
      'expired-callback': () => { token = ''; },
      'error-callback': () => { token = ''; },
    });
  } catch {
    container.textContent = '';
  }
  return {
    enabled: true,
    getToken: () => token || (widgetId !== null && window.turnstile ? turnstile.getResponse(widgetId) || '' : ''),
    reset: () => {
      token = '';
      if (widgetId !== null && window.turnstile) turnstile.reset(widgetId);
    },
  };
}
