// js/components/countdown.js - the DSE countdown timer.
// Markup inside `root`: [data-cd-d] [data-cd-h] [data-cd-m] [data-cd-s] [data-cd-label]
// [data-cd-date], and optionally a list [data-cd-list] for the next few dates.
import { api } from '../core/api.js';
import { currentLanguage, t } from '../core/i18n.js';
import { el, fill } from '../core/ui.js';
import { formatDate, subjectName } from '../core/utils.js';

const pad = (n) => String(n).padStart(2, '0');
const titleOf = (e) => (currentLanguage() === 'zh-HK' ? e.title_zh : e.title_en);

/**
 * @param {HTMLElement} root
 * @param {{ subjects?: string[], listSize?: number }} options  only count down to these
 *        subjects' dates (general dates such as results day are always included)
 */
export async function mountCountdown(root, { subjects = null, listSize = 0 } = {}) {
  if (!root) return null;
  let events = [];
  let offset = 0; // server time minus this computer's time
  try {
    const data = await api('/countdown/events', { redirectOn401: false });
    events = data.events;
    offset = new Date(data.server_now).getTime() - Date.now();
  } catch {
    /* offline: show the empty state below */
  }
  if (subjects && subjects.length) {
    events = events.filter((e) => !e.subject || subjects.includes(e.subject));
  }
  const parts = {
    d: root.querySelector('[data-cd-d]'),
    h: root.querySelector('[data-cd-h]'),
    m: root.querySelector('[data-cd-m]'),
    s: root.querySelector('[data-cd-s]'),
  };
  const label = root.querySelector('[data-cd-label]');
  const date = root.querySelector('[data-cd-date]');
  const list = root.querySelector('[data-cd-list]');
  let index = 0;
  let timer = null;

  function renderList() {
    if (!list || !listSize) return;
    fill(list, ...events.slice(index, index + listSize).map((e) => el('li', {},
      el('span', { class: 'cd-list-date' }, formatDate(e.starts_at, { weekday: 'short', year: undefined })),
      el('span', { class: 'cd-list-title' }, e.subject ? subjectName(e.subject) : titleOf(e)))));
  }

  function show() {
    const event = events[index];
    if (!event) {
      if (label) label.textContent = t('countdown.none');
      if (date) date.textContent = '';
      Object.values(parts).forEach((p) => p && (p.textContent = '--'));
      root.classList.add('is-empty');
      return false;
    }
    if (label) label.textContent = titleOf(event);
    if (date) date.textContent = formatDate(event.starts_at, { weekday: 'long' });
    renderList();
    return true;
  }

  function tick() {
    const event = events[index];
    if (!event) return;
    const diff = new Date(event.starts_at).getTime() - (Date.now() + offset);
    if (diff <= 0) {
      index += 1; // this date has started: move on to the next one
      if (!show()) clearInterval(timer);
      return;
    }
    if (parts.d) parts.d.textContent = Math.floor(diff / 86_400_000);
    if (parts.h) parts.h.textContent = pad(Math.floor(diff / 3_600_000) % 24);
    if (parts.m) parts.m.textContent = pad(Math.floor(diff / 60_000) % 60);
    if (parts.s) parts.s.textContent = pad(Math.floor(diff / 1000) % 60);
  }

  if (show()) {
    tick();
    timer = setInterval(tick, 1000);
  }
  return { events, next: events[index] || null };
}
