// js/components/report-button.js - the Report button for messages and profiles.
import { api } from '../core/api.js';
import { CONFIG } from '../core/config.js';
import { t } from '../core/i18n.js';
import { el, errorMessage, icon, openModal, toast } from '../core/ui.js';

export function openReportDialog(targetType, targetId, onDone) {
  const reasons = el('fieldset', { class: 'stack-sm' },
    el('legend', {}, t('report.why')),
    CONFIG.REPORT_REASONS.map((reason, i) => el('label', { class: 'check-row' },
      el('input', { type: 'radio', name: 'reason', value: reason, required: true, checked: i === 0 }),
      t(`report.reasons.${reason}`))));
  const details = el('textarea', { name: 'details', rows: 3, maxlength: CONFIG.REPORT_DETAILS_MAX,
    id: 'report-details' });
  const error = el('p', { class: 'form-error', hidden: true, 'data-form-error': '' });
  const submit = el('button', { class: 'btn btn-danger', type: 'submit' }, t('report.send'));
  const form = el('form', { class: 'modal-body' },
    el('h2', {}, targetType === 'message' ? t('report.title_message') : t('report.title_user')),
    el('p', { class: 'text-muted text-sm' }, t('report.explain')),
    reasons,
    el('div', { class: 'field' }, el('label', { for: 'report-details' }, t('report.details')), details),
    error,
    el('div', { class: 'form-actions' }, submit,
      el('button', { class: 'btn', type: 'button', onclick: () => dialog.close() }, t('common.cancel'))));
  const dialog = openModal(form);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    submit.disabled = true;
    try {
      await api('/reports', {
        method: 'POST',
        body: { target_type: targetType, target_id: targetId,
          reason: form.reason.value, details: details.value.trim() },
      });
      dialog.close();
      toast(t('report.thanks'), 'success');
      onDone?.();
    } catch (err) {
      error.textContent = errorMessage(err);
      error.hidden = false;
      submit.disabled = false;
    }
  });
}

/** A small Report button. */
export function reportButton(targetType, targetId, { compact = false } = {}) {
  const button = el('button', {
    class: compact ? 'icon-btn report-btn' : 'btn btn-ghost btn-sm', type: 'button',
    'aria-label': t('report.button'), title: t('report.button'),
  }, icon('flag'), compact ? null : t('report.button'));
  button.addEventListener('click', () => openReportDialog(targetType, targetId, () => {
    button.disabled = true;
  }));
  return button;
}
