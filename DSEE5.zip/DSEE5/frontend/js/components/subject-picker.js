// js/components/subject-picker.js - a searchable multi-select for HKDSE subjects.
// const picker = await createSubjectPicker(container, { selected: ['MATH'], name: 'subjects' });
// picker.getValue() -> ['MATH', ...]
import { currentLanguage, t } from '../core/i18n.js';
import { el, fill } from '../core/ui.js';
import { getSubjects } from '../core/utils.js';

let pickerCount = 0;

export async function createSubjectPicker(container, { selected = [], name = 'subjects', max = 12,
  label = '', onChange } = {}) {
  const subjects = await getSubjects();
  const nameOf = (s) => (currentLanguage() === 'zh-HK' ? s.name_zh : s.name_en);
  const chosen = new Set(selected);
  const id = `subject-picker-${(pickerCount += 1)}`;

  const chips = el('ul', { class: 'chip-list', role: 'list', 'aria-live': 'polite' });
  const search = el('input', { type: 'search', id: `${id}-search`, autocomplete: 'off',
    placeholder: t('subjects.search'), 'aria-controls': `${id}-list` });
  const list = el('div', { class: 'picker-list', id: `${id}-list`, role: 'group',
    'aria-label': label || t('subjects.choose') });
  const hidden = el('input', { type: 'hidden', name });

  function renderChips() {
    fill(chips, ...subjects.filter((s) => chosen.has(s.code)).map((s) =>
      el('li', { class: 'chip' }, nameOf(s),
        el('button', { type: 'button', 'aria-label': t('subjects.remove', { name: nameOf(s) }),
          onclick: () => toggle(s.code, false) }, '×'))));
    hidden.value = JSON.stringify([...chosen]);
  }

  function renderList() {
    const q = search.value.trim().toLowerCase();
    fill(list, ...subjects
      .filter((s) => !q || s.code.toLowerCase().includes(q) || s.name_en.toLowerCase().includes(q) ||
        s.name_zh.includes(q))
      .map((s) => el('label', { class: 'picker-option' },
        el('input', { type: 'checkbox', value: s.code, checked: chosen.has(s.code),
          onchange: (e) => toggle(s.code, e.target.checked) }),
        el('span', {}, nameOf(s)), el('span', { class: 'text-muted text-xs' }, s.code))));
  }

  function toggle(code, on) {
    if (on && chosen.size >= max) {
      renderList();
      return;
    }
    if (on) chosen.add(code);
    else chosen.delete(code);
    renderChips();
    renderList();
    onChange?.([...chosen]);
  }

  search.addEventListener('input', renderList);
  fill(container, el('div', { class: 'subject-picker' },
    chips, el('label', { class: 'sr-only', for: `${id}-search` }, t('subjects.search')), search, list, hidden));
  renderChips();
  renderList();

  return {
    getValue: () => [...chosen],
    setValue(codes) {
      chosen.clear();
      codes.forEach((c) => chosen.add(c));
      renderChips();
      renderList();
    },
    focus: () => search.focus(),
    input: hidden,
  };
}
