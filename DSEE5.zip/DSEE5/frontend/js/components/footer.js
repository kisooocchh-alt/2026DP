// js/components/footer.js - links to the terms and privacy policy, and a disclaimer.
import { t } from '../core/i18n.js';
import { el, fill } from '../core/ui.js';

export function mountFooter(container) {
  if (!container) return;
  const year = new Date().getFullYear();
  fill(container,
    el('div', { class: 'container footer-inner' },
      el('div', {},
        el('p', {}, `© ${year} DSEE5. `, t('footer.disclaimer')),
        el('p', {}, t('footer.made_for'))),
      el('ul', { class: 'footer-links', role: 'list' },
        el('li', {}, el('a', { href: '/terms' }, t('footer.terms'))),
        el('li', {}, el('a', { href: '/privacy' }, t('footer.privacy'))),
        el('li', {}, el('a', { href: 'mailto:support@dsee5.example' }, t('footer.contact'))))));
}
