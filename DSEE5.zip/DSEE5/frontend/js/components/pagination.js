// js/components/pagination.js - Previous / Next for long lists.
import { t } from '../core/i18n.js';
import { el, fill } from '../core/ui.js';

export function renderPagination(container, { page, pages }, onChange) {
  if (!container) return;
  if (!pages || pages <= 1) {
    container.replaceChildren();
    return;
  }
  fill(container, el('nav', { class: 'pagination', 'aria-label': t('pagination.label') },
    el('button', { class: 'btn btn-sm', type: 'button', disabled: page <= 1,
      onclick: () => onChange(page - 1) }, t('pagination.previous')),
    el('span', { class: 'current' }, t('pagination.page_of', { page, pages })),
    el('button', { class: 'btn btn-sm', type: 'button', disabled: page >= pages,
      onclick: () => onChange(page + 1) }, t('pagination.next'))));
}
