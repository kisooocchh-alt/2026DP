// frontend/service-worker.js - offline support + push notifications.
// Change VERSION whenever cached files change, so browsers fetch the new versions.
const VERSION = 'dsee5-v1';
const OFFLINE_MATERIALS = 'dsee5-materials';
const SHELL = [
  '/',
  '/pages/404.html',
  '/css/reset.css',
  '/css/variables.css',
  '/css/base.css',
  '/css/layout.css',
  '/css/components.css',
  '/css/utilities.css',
  '/js/core/api.js',
  '/js/core/auth.js',
  '/js/core/config.js',
  '/js/core/i18n.js',
  '/js/core/page.js',
  '/js/core/storage.js',
  '/js/core/ui.js',
  '/js/core/utils.js',
  '/js/components/navbar.js',
  '/js/components/footer.js',
  '/js/components/score-badge.js',
  '/locales/en.json',
  '/locales/zh-HK.json',
  '/assets/images/logo.svg',
  '/assets/images/default-avatar.svg',
  '/assets/fonts/archivo-var-latin.woff',
  '/assets/fonts/atkinson-next-var-latin.woff',
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(VERSION).then((cache) => cache.addAll(SHELL)));
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.filter((k) => k !== VERSION && k !== OFFLINE_MATERIALS).map((k) => caches.delete(k)),
        ),
      ),
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== self.location.origin) return;

  // Materials the user saved offline: cache first.
  if (/^\/api\/materials\/\d+\/file$/.test(url.pathname) && !url.search) {
    event.respondWith(
      caches.open(OFFLINE_MATERIALS).then((cache) =>
        cache.match(event.request).then((hit) => hit || fetch(event.request)),
      ),
    );
    return;
  }
  // API calls and chat always go to the network.
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/socket.io/')) return;

  // Pages and static files: network first, cache as a fallback when offline.
  event.respondWith(
    fetch(event.request)
      .then((res) => {
        const noStore = (res.headers.get('Cache-Control') || '').includes('no-store');
        if (res.ok && res.type === 'basic' && !noStore) {
          const copy = res.clone();
          caches.open(VERSION).then((cache) => cache.put(event.request, copy));
        }
        return res;
      })
      .catch(() =>
        caches.match(event.request).then((hit) => hit || caches.match('/pages/404.html')),
      ),
  );
});

self.addEventListener('push', (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch {
    data = { title: 'DSEE5', body: event.data ? event.data.text() : '' };
  }
  event.waitUntil(
    self.registration.showNotification(data.title || 'DSEE5', {
      body: data.body || '',
      icon: '/assets/icons/icon-192.png',
      badge: '/assets/icons/icon-192.png',
      data: { link: data.link || '/dashboard' },
    }),
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const link = event.notification.data?.link || '/dashboard';
  const target = new URL(link, self.location.origin);
  if (target.origin !== self.location.origin) return;
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((wins) => {
      const open = wins.find((w) => new URL(w.url).pathname === target.pathname);
      return open ? open.focus() : self.clients.openWindow(target.href);
    }),
  );
});
